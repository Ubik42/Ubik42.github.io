# 庭院展示关卡

独立关卡：`/Game/CourtyardPolish/L_CourtyardPresentation`。

保留原实验的拱门、侧廊、铺地和实例布局，补充可查看的美术与材质实现。原来的计时关卡仍在 `/Game/Lab`；网站历史性能数字对应原实验。

## 本轮实现

- **倒角石块**：Blender 生成标准尺寸网格，三段倒角与加权法线。UE 保留原实例变换和分组，替换展示副本的基础立方体。
- **石材表面**：固定种子生成可平铺的高度、粗糙度与变化场。材质按世界坐标和法线权重做三向投射，跨不同尺寸墙块保持纹理尺度；从高度的屏幕导数重建微表面法线。
- **雕塑与花池**：原创三环雕塑、曲面草叶丛，保留中心展台和八个花池位置。草叶使用双面植被着色和空间颜色变化。
- **照明与环境**：调整太阳角度，指定环境Cubemap补充环境反射，加入原创远景起伏地形，改善场景边缘与暗部层次。
- **展示**：全景、石材近景、雕塑近景；旧场景与新场景使用同一全景机位，展示可见变化。

## 源码与制作顺序

1. Blender 后台运行 `Scripts/make_courtyard_assets.py` 和 `make_courtyard_foliage.py`，输出 FBX。只操作临时新场景。
2. Python 运行 `Scripts/make_courtyard_texture.py`，生成原创石材图。
3. UE Editor 运行 `Scripts/build_courtyard_presentation.py`，从旧关卡保存独立副本并替换展示资产。已有展示关卡时停止。
4. UE 运行 `Scripts/dress_courtyard_presentation.py`，加入植被、远景和雕塑位置调整；该步骤为一次性场景制作。
5. UE 运行 `Scripts/finish_courtyard_presentation.py` 完成最终相机、太阳与地形朝向调整，再由 `Scripts/capture_courtyard_presentation.py`，保存三张展示图和同机位旧场景。运行 `finish_courtyard_distance_material.py` 为远景使用独立低频材质，避免密集细节混叠。实际图像与机位清单见 `Evidence/courtyard-polish/capture-v4`。

`repair_courtyard_materials.py` 保留本轮开发修复入口：材质节点的输入名从宿主API读取，修复早期ComponentMask连线缺失。正式建图脚本已包含此修正。

## 使用与范围

打开随附工程即可加载最终关卡。雕塑、草叶、地形、纹理与脚本均为本轮制作；藤蔓来自本人此前PCG工具。引擎基础资源以引擎路径引用。截图来自 UE 原生视口，没有使用生成图替代运行画面。

三向投射、微表面法线和新增几何会增加展示成本。本轮用于改善场景与说明材质实现；没有沿用旧场景的性能收益。移动端发布和新场景性能测量须另立批次。
