"""Build a presentation copy; retain the measured courtyard maps and materials."""
from pathlib import Path
import unreal,json,traceback
root=Path(unreal.Paths.project_dir());F='/Game/CourtyardPolish'
a=unreal.EditorAssetLibrary;ml=unreal.MaterialEditingLibrary;tools=unreal.AssetToolsHelpers.get_asset_tools()
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem);levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if a.does_asset_exist(F+'/L_CourtyardPresentation'):raise RuntimeError('Presentation exists; inspect before editing')
def imported(name,ext):
    if a.does_asset_exist(F+'/'+name):return a.load_asset(F+'/'+name)
    task=unreal.AssetImportTask()
    for k,v in dict(filename=str(root/'ContentSource/CourtyardPolish'/(name+ext)),destination_path=F,destination_name=name,automated=True,replace_existing=False,save=True).items():task.set_editor_property(k,v)
    if ext=='.fbx':
        options=unreal.FbxImportUI();options.set_editor_property('import_materials',False);options.set_editor_property('import_textures',False);options.set_editor_property('import_as_skeletal',False)
        options.static_mesh_import_data.set_editor_property('combine_meshes',True)
        task.set_editor_property('options',options)
    tools.import_asset_tasks([task]);asset=a.load_asset(F+'/'+name)
    if not asset:raise RuntimeError('Missing import '+name)
    return asset
stoneMesh=imported('SM_BeveledStone','.fbx');sculpture=imported('SM_Armillary','.fbx');tex=imported('T_StoneField','.png')
tex.set_editor_property('srgb',False);tex.set_editor_property('compression_settings',unreal.TextureCompressionSettings.TC_MASKS);a.save_loaded_asset(tex)
def custom_input(name):
    entry=unreal.CustomInput();entry.set_editor_property('input_name',name);return entry
def node(mat,cls,**kwargs):
    x=ml.create_material_expression(mat,cls)
    for k,v in kwargs.items():x.set_editor_property(k,v)
    return x
def surface(name,color,metal=0,rough=.8,stone=True):
    m=tools.create_asset(name,F,unreal.Material,unreal.MaterialFactoryNew())
    c=node(m,unreal.MaterialExpressionConstant3Vector,constant=unreal.LinearColor(*color,1))
    if stone:
        p=node(m,unreal.MaterialExpressionWorldPosition)
        n=node(m,unreal.MaterialExpressionVertexNormalWS)
        t=node(m,unreal.MaterialExpressionTextureObject,texture=tex)
        code='float3 w=pow(abs(N),4); w/=max(w.x+w.y+w.z,0.0001); return Texture2DSample(T,TSampler,P.yz*0.009).rgb*w.x+Texture2DSample(T,TSampler,P.xz*0.009).rgb*w.y+Texture2DSample(T,TSampler,P.xy*0.009).rgb*w.z;'
        custom=node(m,unreal.MaterialExpressionCustom,code=code,output_type=unreal.CustomMaterialOutputType.CMOT_FLOAT3)
        custom.set_editor_property('inputs',[custom_input(v) for v in ['P','N','T']])
        for x,pin in [(p,'P'),(n,'N'),(t,'T')]:assert ml.connect_material_expressions(x,'',custom,pin)
        mask=node(m,unreal.MaterialExpressionComponentMask,r=True,g=False,b=False,a=False);ml.connect_material_expressions(custom,'',mask,ml.get_material_expression_input_names(mask)[0])
        remap=node(m,unreal.MaterialExpressionMultiply,const_b=.65);ml.connect_material_expressions(mask,'',remap,'A')
        bias=node(m,unreal.MaterialExpressionAdd,const_b=.58);ml.connect_material_expressions(remap,'',bias,'A')
        mul=node(m,unreal.MaterialExpressionMultiply);ml.connect_material_expressions(c,'',mul,'A');ml.connect_material_expressions(bias,'',mul,'B');ml.connect_material_property(mul,'',unreal.MaterialProperty.MP_BASE_COLOR)
        rm=node(m,unreal.MaterialExpressionComponentMask,r=False,g=True,b=False,a=False);ml.connect_material_expressions(custom,'',rm,ml.get_material_expression_input_names(rm)[0]);ml.connect_material_property(rm,'',unreal.MaterialProperty.MP_ROUGHNESS)
        bump=node(m,unreal.MaterialExpressionCustom,code='float3 q0=ddx(P),q1=ddy(P); float3 a=cross(q1,N),b=cross(N,q0);float d=dot(q0,a);return normalize(abs(d)*N-sign(d)*(ddx(H)*a+ddy(H)*b)*0.65);',output_type=unreal.CustomMaterialOutputType.CMOT_FLOAT3)
        bump.set_editor_property('inputs',[custom_input(v) for v in ['P','N','H']])
        for x,pin in [(p,'P'),(n,'N'),(mask,'H')]:ml.connect_material_expressions(x,'',bump,pin)
        m.set_editor_property('tangent_space_normal',False);ml.connect_material_property(bump,'',unreal.MaterialProperty.MP_NORMAL)
    else:
        ml.connect_material_property(c,'',unreal.MaterialProperty.MP_BASE_COLOR)
        r=node(m,unreal.MaterialExpressionConstant,r=rough);ml.connect_material_property(r,'',unreal.MaterialProperty.MP_ROUGHNESS)
    metalnode=node(m,unreal.MaterialExpressionConstant,r=metal);ml.connect_material_property(metalnode,'',unreal.MaterialProperty.MP_METALLIC)
    ml.set_material_usage(m,unreal.MaterialUsage.MATUSAGE_INSTANCED_STATIC_MESHES)
    ml.layout_material_expressions(m);ml.recompile_material(m);a.save_loaded_asset(m);return m
mats={}
for i in range(5):mats['stone'+str(i)]=surface('M_Limestone'+str(i),(.28+i*.025,.245+i*.021,.19+i*.017))
mats['dark']=surface('M_DarkStone',(.07,.10,.12));mats['ground']=surface('M_Ground',(.09,.085,.07));mats['moss']=surface('M_Moss',(.07,.10,.03));mats['bronze']=surface('M_Bronze',(.55,.29,.09),.82,.28,False)
leaf=surface('M_Leaves',(.065,.12,.025),0,.65,False);leaf.set_editor_property('two_sided',True);ml.recompile_material(leaf);a.save_loaded_asset(leaf)
assert levels.load_level('/Game/Lab/L_Courtyard_Instanced')
world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
assert unreal.EditorLoadingAndSavingUtils.save_map(world,F+'/L_CourtyardPresentation')
assert levels.load_level(F+'/L_CourtyardPresentation')
changed=[]
for actor in actors.get_all_level_actors():
    for comp in actor.get_components_by_class(unreal.StaticMeshComponent):
        mesh=comp.get_editor_property('static_mesh')
        if mesh and mesh.get_path_name().startswith('/Engine/BasicShapes/Cube'):
            comp.set_static_mesh(stoneMesh)
        for idx in range(comp.get_num_materials()):
            mat=comp.get_material(idx)
            if not mat:continue
            name=mat.get_name();replacement=None
            if name.startswith('M_Stone'):replacement=mats.get('stone'+name[-1])
            elif name=='M_Dark':replacement=mats['dark']
            elif name=='M_Ground':replacement=mats['ground']
            elif name=='M_Moss':replacement=mats['moss']
            elif name=='M_Bronze':replacement=mats['bronze']
            elif name=='M_Leaves':replacement=leaf
            if replacement:comp.set_material(idx,replacement);changed.append([actor.get_actor_label(),name,replacement.get_name()])
        if mesh and mesh.get_path_name().startswith('/Engine/BasicShapes/Sphere'):
            comp.set_static_mesh(sculpture)
    if isinstance(actor,unreal.DirectionalLight):
        actor.set_actor_rotation(unreal.Rotator(pitch=-24,yaw=112,roll=0),False);actor.light_component.set_editor_property('intensity',4.5);actor.light_component.set_editor_property('light_color',unreal.Color(255,224,180,255))
    if isinstance(actor,unreal.SkyLight):
        c=actor.light_component;c.set_editor_property('real_time_capture',False);c.set_editor_property('source_type',unreal.SkyLightSourceType.SLS_SPECIFIED_CUBEMAP);c.set_editor_property('cubemap',a.load_asset('/Engine/EngineResources/DefaultTextureCube'));c.set_editor_property('intensity',1.25);c.recapture_sky()
    if isinstance(actor,unreal.ExponentialHeightFog):actor.component.set_editor_property('fog_density',.008)
    if isinstance(actor,unreal.CameraActor):
        pos=unreal.Vector(950,-2450,680);rot=unreal.MathLibrary.find_look_at_rotation(pos,unreal.Vector(0,450,310));actor.set_actor_location(pos,False,False);actor.set_actor_rotation(rot,False);actor.camera_component.set_editor_property('field_of_view',58.)
actors.set_selected_level_actors([]);levels.save_current_level()
(root/'Evidence/courtyard-polish/build.json').write_text(json.dumps({'map':F+'/L_CourtyardPresentation','materialReplacements':changed,'geometry':'Beveled normalized cube and authored armillary; existing instance transforms retained','measuredMapsUnchanged':True},ensure_ascii=False,indent=2),encoding='utf-8')
unreal.log('COURTYARD_POLISH_BUILD_OK')
unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
