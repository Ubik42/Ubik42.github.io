"""Three presentation views and the original scene with the same overview camera."""
import unreal,json,traceback
from pathlib import Path
root=Path(unreal.Paths.project_dir());out=root/'Evidence/courtyard-polish/capture-v4';out.mkdir(parents=True,exist_ok=True)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem);actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
key=unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
shots=[('overview','/Game/CourtyardPolish/L_CourtyardPresentation',(1100,-2900,1000),(0,450,300),58),('stone-detail','/Game/CourtyardPolish/L_CourtyardPresentation',(440,50,360),(120,550,370),58),('sculpture','/Game/CourtyardPolish/L_CourtyardPresentation',(700,-1700,650),(0,-600,380),58),('original','/Game/Lab/L_Courtyard_Instanced',(1100,-2900,1000),(0,450,300),58)]
state={'i':0,'ticks':0,'handle':None,'done':False};manifest={'engine':unreal.SystemLibrary.get_engine_version(),'resolution':[1600,900],'purpose':'Presentation scene; separate from historical performance measurements','shots':[]}
def prepare():
    name,path,pos,target,fov=shots[state['i']]
    assert levels.load_level(path)
    levels.set_level_viewport_camera_info(unreal.Vector(*pos),unreal.MathLibrary.find_look_at_rotation(unreal.Vector(*pos),unreal.Vector(*target)),key)
    levels.set_level_viewport_fov(fov,key);levels.editor_set_game_view(True,key);actors.set_selected_level_actors([])
    w=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    for cmd in ['ShowFlag.Grid 0','ShowFlag.Selection 0','r.VSync 0','t.MaxFPS 60','r.ScreenPercentage 100']:
        unreal.SystemLibrary.execute_console_command(w,cmd)
    state['ticks']=0

def finish(error=None):
    state['done']=True
    if error:manifest['error']=error
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.unregister_slate_post_tick_callback(state['handle'])
    unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
def tick(dt):
    if state['done']:return
    try:
        state['ticks']+=1
        if state['ticks']==240:
            name,path,pos,target,fov=shots[state['i']]
            unreal.SystemLibrary.execute_console_command(unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world(),'HighResShot 1600x900 filename="'+(out/(name+'.png')).as_posix()+'"')
            manifest['shots'].append(dict(name=name,map=path,position=pos,target=target,fov=fov))
        if state['ticks']==300:
            state['i']+=1
            if state['i']==len(shots):finish()
            else:prepare()
    except Exception:finish(traceback.format_exc())
prepare();unreal.EditorPythonScripting.set_keep_python_script_alive(True);state['handle']=unreal.register_slate_post_tick_callback(tick)

