import unreal,json
from pathlib import Path
root=Path(unreal.Paths.project_dir());F='/Game/CourtyardPolish';a=unreal.EditorAssetLibrary
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem);levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem);tools=unreal.AssetToolsHelpers.get_asset_tools();ml=unreal.MaterialEditingLibrary
for name in ['SM_HerbPatch','SM_BackgroundTerrain']:
    if a.does_asset_exist(F+'/'+name):continue
    task=unreal.AssetImportTask()
    for k,v in dict(filename=str(root/'ContentSource/CourtyardPolish'/(name+'.fbx')),destination_path=F,destination_name=name,automated=True,replace_existing=False,save=True).items():task.set_editor_property(k,v)
    options=unreal.FbxImportUI();options.set_editor_property('import_materials',False);options.set_editor_property('import_textures',False);options.set_editor_property('import_as_skeletal',False);options.static_mesh_import_data.set_editor_property('combine_meshes',True);task.set_editor_property('options',options)
    tools.import_asset_tasks([task])
assert levels.load_level(F+'/L_CourtyardPresentation')
for actor in actors.get_all_level_actors():
    for c in actor.get_components_by_class(unreal.StaticMeshComponent):
        mesh=c.get_editor_property('static_mesh')
        if mesh and mesh.get_name()=='SM_Armillary':
            c.set_relative_location(unreal.Vector(0,0,145),False,False)
leaf=a.load_asset(F+'/M_Leaves');ml.delete_all_material_expressions(leaf)
p=ml.create_material_expression(leaf,unreal.MaterialExpressionWorldPosition)
custom=ml.create_material_expression(leaf,unreal.MaterialExpressionCustom)
entry=unreal.CustomInput();entry.set_editor_property('input_name','P');custom.set_editor_property('inputs',[entry]);custom.set_editor_property('output_type',unreal.CustomMaterialOutputType.CMOT_FLOAT3)
custom.set_editor_property('code','float v=0.5+0.5*sin(P.x*0.021+sin(P.z*0.04))*cos(P.y*0.032);return lerp(float3(0.045,0.075,0.012),float3(0.13,0.20,0.035),v);')
ml.connect_material_expressions(p,'',custom,'P');ml.connect_material_property(custom,'',unreal.MaterialProperty.MP_BASE_COLOR)
leaf.set_editor_property('shading_model',unreal.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE);leaf.set_editor_property('two_sided',True)
sub=ml.create_material_expression(leaf,unreal.MaterialExpressionConstant3Vector);sub.set_editor_property('constant',unreal.LinearColor(.11,.18,.035,1));ml.connect_material_property(sub,'',unreal.MaterialProperty.MP_SUBSURFACE_COLOR)
rough=ml.create_material_expression(leaf,unreal.MaterialExpressionConstant);rough.set_editor_property('r',.75);ml.connect_material_property(rough,'',unreal.MaterialProperty.MP_ROUGHNESS);ml.recompile_material(leaf);a.save_loaded_asset(leaf)
for side in [-1,1]:
 for y in [-1500,-500,500,1500]:
    actor=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector(side*1040,y,74))
    actor.set_actor_label('展示草叶丛');actor.static_mesh_component.set_static_mesh(a.load_asset(F+'/SM_HerbPatch'));actor.static_mesh_component.set_material(0,leaf)
actor=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector());actor.set_actor_label('展示远景地形');actor.static_mesh_component.set_static_mesh(a.load_asset(F+'/SM_BackgroundTerrain'));actor.static_mesh_component.set_material(0,a.load_asset(F+'/M_Ground'))
actors.set_selected_level_actors([]);levels.save_current_level();unreal.log('COURTYARD_DRESSING_OK');unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
