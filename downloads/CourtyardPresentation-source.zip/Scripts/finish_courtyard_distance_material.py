import unreal
from pathlib import Path
r=Path(unreal.Paths.project_dir());F='/Game/CourtyardPolish';a=unreal.EditorAssetLibrary;ml=unreal.MaterialEditingLibrary;levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem);actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
m=unreal.AssetToolsHelpers.get_asset_tools().create_asset('M_DistantGround',F,unreal.Material,unreal.MaterialFactoryNew())
c=ml.create_material_expression(m,unreal.MaterialExpressionConstant3Vector);c.set_editor_property('constant',unreal.LinearColor(.115,.12,.085,1));ml.connect_material_property(c,'',unreal.MaterialProperty.MP_BASE_COLOR)
n=ml.create_material_expression(m,unreal.MaterialExpressionConstant);n.set_editor_property('r',.95);ml.connect_material_property(n,'',unreal.MaterialProperty.MP_ROUGHNESS);ml.recompile_material(m);a.save_loaded_asset(m)
assert levels.load_level(F+'/L_CourtyardPresentation')
for actor in actors.get_all_level_actors():
    if actor.get_actor_label()=='展示远景地形':actor.static_mesh_component.set_material(0,m)
levels.save_current_level()
exec((r/'Scripts/capture_courtyard_presentation.py').read_text(encoding='utf-8'))
