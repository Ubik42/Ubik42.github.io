import unreal
from pathlib import Path
root=Path(unreal.Paths.project_dir());levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem);actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
assert levels.load_level('/Game/CourtyardPolish/L_CourtyardPresentation')
for actor in actors.get_all_level_actors():
    if actor.get_actor_label()=='展示远景地形':actor.set_actor_rotation(unreal.Rotator(pitch=0,yaw=180,roll=0),False)
    if isinstance(actor,unreal.SkyLight):actor.light_component.set_editor_property('intensity',.85)
    if isinstance(actor,unreal.DirectionalLight):actor.set_actor_rotation(unreal.Rotator(pitch=-32,yaw=145,roll=0),False)
    if isinstance(actor,unreal.CameraActor):
        p=unreal.Vector(1100,-2900,1000);actor.set_actor_location(p,False,False);actor.set_actor_rotation(unreal.MathLibrary.find_look_at_rotation(p,unreal.Vector(0,450,300)),False)
levels.save_current_level()
exec((root/'Scripts/capture_courtyard_presentation.py').read_text(encoding='utf-8-sig'))
