from pathlib import Path
import bpy,math
from mathutils import Euler
root=Path(__file__).resolve().parents[1]/'ContentSource/CourtyardPolish'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.mesh.primitive_cube_add(size=1)
o=bpy.context.object;o.name='SM_BeveledStone'
b=o.modifiers.new('Stone edge','BEVEL');b.width=.012;b.segments=3
bpy.ops.object.modifier_apply(modifier=b.name)
for p in o.data.polygons:p.use_smooth=True
n=o.modifiers.new('Face normals','WEIGHTED_NORMAL');n.keep_sharp=True
bpy.ops.object.modifier_apply(modifier=n.name)
bpy.ops.export_scene.fbx(filepath=str(root/'SM_BeveledStone.fbx'),use_selection=True,add_leaf_bones=False)
bpy.ops.object.delete(use_global=False)
parts=[]
for i,(angle,r) in enumerate([(0,1.0),(58,.86),(-52,.7)]):
    bpy.ops.mesh.primitive_torus_add(major_segments=96,minor_segments=12,major_radius=r,minor_radius=.038,rotation=(math.pi/2,0,math.radians(angle)))
    o=bpy.context.object;parts.append(o)
    for p in o.data.polygons:p.use_smooth=True
bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=20,radius=.29);parts.append(bpy.context.object)
for p in bpy.context.object.data.polygons:p.use_smooth=True
bpy.ops.object.select_all(action='SELECT');bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();bpy.context.object.name='SM_Armillary'
bpy.ops.export_scene.fbx(filepath=str(root/'SM_Armillary.fbx'),use_selection=True,add_leaf_bones=False)
bpy.ops.wm.save_as_mainfile(filepath=str(root/'courtyard-assets.blend'))
