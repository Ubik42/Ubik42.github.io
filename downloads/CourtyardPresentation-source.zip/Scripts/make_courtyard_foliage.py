from pathlib import Path
import bpy,math,random
from mathutils import Vector
r=Path(__file__).resolve().parents[1]/'ContentSource/CourtyardPolish'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
rng=random.Random(4201);verts=[];faces=[]
for ix in range(3):
 for iy in range(3):
  cx=(ix-1)*.85;cy=(iy-1)*.85
  for leaf in range(11):
   angle=rng.random()*math.tau;length=rng.uniform(.4,.85);width=rng.uniform(.035,.07);base=len(verts)
   for j in range(9):
    t=j/8;dist=length*t*.72;z=length*(1.9*t-1.2*t*t)
    w=width*math.sin(math.pi*t)**.7
    for side in [-1,0,1]:
     verts.append((cx+math.cos(angle)*dist-math.sin(angle)*w*side,cy+math.sin(angle)*dist+math.cos(angle)*w*side,z+(.014*math.sin(math.pi*t) if side==0 else 0)))
   for j in range(8):
    for k in range(2):a=base+j*3+k;faces.append((a,a+1,a+4,a+3))
mesh=bpy.data.meshes.new('HerbPatch');mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new('SM_HerbPatch',mesh);bpy.context.collection.objects.link(ob);ob.select_set(True);bpy.context.view_layer.objects.active=ob
for p in mesh.polygons:p.use_smooth=True
bpy.ops.export_scene.fbx(filepath=str(r/'SM_HerbPatch.fbx'),use_selection=True,add_leaf_bones=False)
bpy.ops.object.delete(use_global=False)
v=[];f=[];n=65
for iy in range(n):
 y=-100+iy/(n-1)*280
 for ix in range(n):
  x=-120+ix/(n-1)*240
  fade=max(0,min(1,(y-35)/35));z=-.6+fade*(7+4*math.sin(x*.04)+3*math.cos(y*.055)+1.6*math.sin((x+y)*.09))
  v.append((x,y,z))
for iy in range(n-1):
 for ix in range(n-1):a=iy*n+ix;f.append((a,a+1,a+1+n,a+n))
mesh=bpy.data.meshes.new('Terrain');mesh.from_pydata(v,[],f);mesh.update();ob=bpy.data.objects.new('SM_BackgroundTerrain',mesh);bpy.context.collection.objects.link(ob);ob.select_set(True);bpy.context.view_layer.objects.active=ob
for p in mesh.polygons:p.use_smooth=True
bpy.ops.export_scene.fbx(filepath=str(r/'SM_BackgroundTerrain.fbx'),use_selection=True,add_leaf_bones=False)
