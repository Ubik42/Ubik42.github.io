"""Create an original seamless packed stone field, seed 42171101."""
from pathlib import Path
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[1]/'ContentSource/CourtyardPolish';root.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(42171101);n=1024
f=np.fft.fftfreq(n);yy,xx=np.meshgrid(f,f);rad=np.sqrt(xx*xx+yy*yy);rad[0,0]=1
spectrum=np.fft.fft2(rng.normal(size=(n,n)))*np.power(rad,-1.35);spectrum[0,0]=0
h=np.fft.ifft2(spectrum).real;h=(h-np.percentile(h,1))/(np.percentile(h,99)-np.percentile(h,1));h=np.clip(h,0,1)
fine=rng.random((n,n));pores=np.maximum(0,(fine-.986)/.014)
height=np.clip(h*.72+fine*.09-pores*.16+.1,0,1);rough=np.clip(.72+.23*h+.04*fine,0,1)
Image.fromarray(np.uint8(np.stack([height,rough,h],2)*255)).save(root/'T_StoneField.png')
