# 材质继承整理与对照

UE 5.8.1。打开 MaterialLineageLab.uproject，默认载入已完成的泵体测试场景。详情见 Docs/材质继承整理与对照.md。包含实际参数和四张原生截图。
