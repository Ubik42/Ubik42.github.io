"""Create an isolated material family, collect effective values, flatten a duplicate only."""
import hashlib,json
from pathlib import Path
import unreal

ROOT=Path(unreal.Paths.project_dir())
FOLDER='/Game/MaterialLineageLab'
ml=unreal.MaterialEditingLibrary
assets=unreal.EditorAssetLibrary
tools=unreal.AssetToolsHelpers.get_asset_tools()

def asset(name,cls,factory):
    path=FOLDER+'/'+name
    if assets.does_asset_exist(path):
        raise RuntimeError('Fixture already exists; preserve it and inspect before rebuilding: '+path)
    result=tools.create_asset(name,FOLDER,cls,factory)
    if not result:raise RuntimeError('Create failed: '+path)
    return result

def effective(mi):
    def rgba(c):return [round(v,7) for v in (c.r,c.g,c.b,c.a)]
    return {
        'scalar':{str(n):round(ml.get_material_instance_scalar_parameter_value(mi,n),7) for n in sorted(ml.get_scalar_parameter_names(mi),key=str)},
        'vector':{str(n):rgba(ml.get_material_instance_vector_parameter_value(mi,n)) for n in sorted(ml.get_vector_parameter_names(mi),key=str)},
        'texture':{str(n):(ml.get_material_instance_texture_parameter_value(mi,n).get_path_name() if ml.get_material_instance_texture_parameter_value(mi,n) else None) for n in sorted(ml.get_texture_parameter_names(mi),key=str)},
        'staticSwitch':{str(n):ml.get_material_instance_static_switch_parameter_value(mi,n) for n in sorted(ml.get_static_switch_parameter_names(mi),key=str)},
    }

def snapshot(mi):
    chain=[];current=mi
    while isinstance(current,unreal.MaterialInstanceConstant):
        current=current.get_editor_property('parent');chain.append(current.get_path_name())
        if len(chain)>32:raise RuntimeError('Unexpected parent cycle')
    values=effective(mi)
    signature=hashlib.sha256(json.dumps({'base':current.get_path_name(),'values':values},sort_keys=True).encode()).hexdigest()
    return {'asset':mi.get_path_name(),'parentChain':chain,'depth':len(chain),'base':current.get_path_name(),'effective':values,'supportedParameterSignature':signature}

def instance(name,parent,scalar=None,vector=None,switch=None):
    mi=asset(name,unreal.MaterialInstanceConstant,unreal.MaterialInstanceConstantFactoryNew())
    # UE 5.8 setters return false even after writing; validate by read-back below.
    ml.set_material_instance_parent(mi,parent)
    for key,value in (scalar or {}).items():ml.set_material_instance_scalar_parameter_value(mi,key,value)
    for key,value in (vector or {}).items():ml.set_material_instance_vector_parameter_value(mi,key,unreal.LinearColor(*value))
    for key,value in (switch or {}).items():ml.set_material_instance_static_switch_parameter_value(mi,key,value)
    ml.update_material_instance(mi)
    actual=effective(mi)
    for key,value in (scalar or {}).items():assert abs(actual['scalar'][key]-value)<1e-6
    for key,value in (vector or {}).items():assert all(abs(a-b)<1e-6 for a,b in zip(actual['vector'][key],value))
    for key,value in (switch or {}).items():assert actual['staticSwitch'][key]==value
    assets.save_loaded_asset(mi)
    return mi

try:
    assets.make_directory(FOLDER)
    base_path=FOLDER+'/M_CoatedMetal'
    if assets.does_asset_exist(base_path):
        base=assets.load_asset(base_path)
        assert set(map(str,ml.get_scalar_parameter_names(base)))=={'Roughness','Metallic'}
        assert set(map(str,ml.get_vector_parameter_names(base)))=={'Tint'}
    else:
        base=asset('M_CoatedMetal',unreal.Material,unreal.MaterialFactoryNew())
        tint=ml.create_material_expression(base,unreal.MaterialExpressionVectorParameter)
        tint.set_editor_property('parameter_name','Tint');tint.set_editor_property('default_value',unreal.LinearColor(.06,.25,.32,1))
        rough=ml.create_material_expression(base,unreal.MaterialExpressionScalarParameter)
        rough.set_editor_property('parameter_name','Roughness');rough.set_editor_property('default_value',.6)
        metal=ml.create_material_expression(base,unreal.MaterialExpressionScalarParameter)
        metal.set_editor_property('parameter_name','Metallic');metal.set_editor_property('default_value',.5)
        tex=ml.create_material_expression(base,unreal.MaterialExpressionTextureSampleParameter2D)
        tex.set_editor_property('parameter_name','Albedo');tex.set_editor_property('texture',assets.load_asset('/Engine/EngineResources/WhiteSquareTexture'))
        switch=ml.create_material_expression(base,unreal.MaterialExpressionStaticSwitchParameter)
        switch.set_editor_property('parameter_name','UseTint');switch.set_editor_property('default_value',True)
        assert ml.connect_material_expressions(tint,'RGB',switch,'True')
        assert ml.connect_material_expressions(tex,'RGB',switch,'False')
        assert ml.connect_material_property(switch,'',unreal.MaterialProperty.MP_BASE_COLOR)
        assert ml.connect_material_property(rough,'',unreal.MaterialProperty.MP_ROUGHNESS)
        assert ml.connect_material_property(metal,'',unreal.MaterialProperty.MP_METALLIC)
        ml.layout_material_expressions(base);ml.recompile_material(base);assets.save_loaded_asset(base)
    red=(.5,.045,.018,1)
    parent=instance('MI_RedFamily',base,vector={'Tint':red})
    branch=instance('MI_RedPolished',parent,scalar={'Roughness':.22})
    leaf=instance('MI_RedProp',branch)
    same=instance('MI_RedEquivalent',base,scalar={'Roughness':.22},vector={'Tint':red})
    rougher=instance('MI_RoughControl',branch,scalar={'Roughness':.85})
    static=instance('MI_StaticSwitchControl',branch,switch={'UseTint':False})
    originals=[parent,branch,leaf,same,rougher,static]
    before=[snapshot(mi) for mi in originals]
    leaf_before=snapshot(leaf)
    clone=tools.duplicate_asset('MI_RedProp_Flattened',FOLDER,leaf)
    if not clone:raise RuntimeError('Duplicate failed')
    # Changes are restricted to the newly authored duplicate in this isolated folder.
    ml.set_material_instance_parent(clone,base)
    for n,v in leaf_before['effective']['scalar'].items():ml.set_material_instance_scalar_parameter_value(clone,n,v)
    for n,v in leaf_before['effective']['vector'].items():ml.set_material_instance_vector_parameter_value(clone,n,unreal.LinearColor(*v))
    for n,v in leaf_before['effective']['texture'].items():ml.set_material_instance_texture_parameter_value(clone,n,assets.load_asset(v))
    for n,v in leaf_before['effective']['staticSwitch'].items():ml.set_material_instance_static_switch_parameter_value(clone,n,v)
    ml.update_material_instance(clone);assets.save_loaded_asset(clone)
    flattened=snapshot(clone)
    after=[snapshot(mi) for mi in originals]
    assert before==after,'Source snapshots changed'
    assert leaf_before['effective']==flattened['effective'],'Effective parameters changed'
    assert leaf_before['depth']==3 and flattened['depth']==1
    groups={}
    for row in before:groups.setdefault(row['supportedParameterSignature'],[]).append(row['asset'])
    report={'date':'2026-11-01','engine':unreal.SystemLibrary.get_engine_version(),'scope':'Authored single-layer fixture with global scalar/vector/texture/static-switch parameters. Signature is a candidate filter, not visual equivalence or a shader permutation count. No production assets are edited.','originals':before,'candidateGroups':[v for v in groups.values() if len(v)>1],'changeSet':{'operation':'duplicate_then_reparent','source':leaf_before,'result':flattened,'sourceSnapshotsUnchanged':before==after,'effectiveParametersPreserved':leaf_before['effective']==flattened['effective']},'notCovered':['material layers and non-global parameter associations','base-property overrides','runtime material parameter collections','visual comparison','shader permutation counts or GPU performance']}
    dest=ROOT/'Evidence/material-lineage';dest.mkdir(parents=True,exist_ok=True)
    (dest/'effective-parameters.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    unreal.log('MATERIAL_LINEAGE_OK depth 3 -> 1; original snapshots unchanged')
finally:
    unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
