"""Render the same authored pump with four material assignments and a fixed camera."""
import json, math, traceback
from pathlib import Path
import unreal
root=Path(unreal.Paths.project_dir()); folder='/Game/MaterialLineageLab'
a=unreal.EditorAssetLibrary; ml=unreal.MaterialEditingLibrary
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
tools=unreal.AssetToolsHelpers.get_asset_tools()
out=root/'Evidence/material-lineage/render-v2';out.mkdir(parents=True,exist_ok=True)
if (out/'manifest.json').exists():raise RuntimeError('Capture already exists')
level=folder+'/L_MaterialLineage'
assert levels.load_level(level)
original=a.load_asset(folder+'/MI_RedProp')
painted=[]
for actor in actors.get_all_level_actors():
    if isinstance(actor,unreal.StaticMeshActor):
        if actor.static_mesh_component.get_material(0)==original:painted.append(actor.static_mesh_component)
        if actor.get_actor_label()=='展示地面':actor.set_actor_scale3d(unreal.Vector(100,100,.2))
    if isinstance(actor,unreal.SkyLight):
        c=actor.light_component
        c.set_editor_property('real_time_capture',False)
        c.set_editor_property('source_type',unreal.SkyLightSourceType.SLS_SPECIFIED_CUBEMAP)
        c.set_editor_property('cubemap',a.load_asset('/Engine/EngineResources/DefaultTextureCube'))
        c.set_editor_property('intensity',1.5);c.recapture_sky()
cam=next(x for x in actors.get_all_level_actors() if x.get_actor_label()=='固定材质对照相机')
pos=cam.get_actor_location();rot=cam.get_actor_rotation()
levels.save_current_level()
key=unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
levels.set_level_viewport_camera_info(pos,rot,key);levels.set_level_viewport_fov(38.,key);levels.editor_set_game_view(True,key)
world=unreal.EditorLevelLibrary.get_editor_world()
for cmd in ['ShowFlag.Grid 0','ShowFlag.Selection 0','r.VSync 0','t.MaxFPS 60','r.ScreenPercentage 100','r.AntiAliasingMethod 0','r.SetRes 1600x900w']:
    unreal.SystemLibrary.execute_console_command(world,cmd)
variants=[('original','MI_RedProp'),('flattened','MI_RedProp_Flattened'),('roughness-control','MI_RoughControl'),('switch-control','MI_StaticSwitchControl')]
state={'i':0,'ticks':0,'handle':None,'finished':False}
manifest={'engine':unreal.SystemLibrary.get_engine_version(),'resolution':[1600,900],'camera':{'position':[480,-650,360],'target':[0,0,100],'fov':38},'scene':level,'paintedComponents':len(painted),'aa':'None for stable fixed-image comparison','captures':[]}
def finish():
    state['finished']=True
    for comp in painted:comp.set_material(0,original)
    levels.save_current_level()
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.unregister_slate_post_tick_callback(state['handle'])
    unreal.log('MATERIAL_LINEAGE_RENDER_DONE');unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
def tick(dt):
    if state['finished']:return
    try:
        state['ticks']+=1
        if state['ticks']==1:
            material=a.load_asset(folder+'/'+variants[state['i']][1])
            for comp in painted:comp.set_material(0,material)
        if state['ticks']==240:
            name,material=variants[state['i']];path=out/(name+'.png')
            unreal.SystemLibrary.execute_console_command(world,'HighResShot 1600x900 filename="'+path.as_posix()+'"')
            manifest['captures'].append({'name':name,'material':folder+'/'+material,'image':path.name,'warmupTicks':240})
        if state['ticks']==290:
            state['i']+=1;state['ticks']=0
            if state['i']==len(variants):finish()
    except Exception:
        manifest['error']=traceback.format_exc();unreal.log_error(manifest['error']);finish()
unreal.EditorPythonScripting.set_keep_python_script_alive(True)
state['handle']=unreal.register_slate_post_tick_callback(tick)
