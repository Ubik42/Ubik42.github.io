"""Render the same authored pump with four material assignments and a fixed camera."""
import json, math, traceback
from pathlib import Path
import unreal
root=Path(unreal.Paths.project_dir()); folder='/Game/MaterialLineageLab'
a=unreal.EditorAssetLibrary; ml=unreal.MaterialEditingLibrary
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
tools=unreal.AssetToolsHelpers.get_asset_tools()
out=root/'Evidence/material-lineage/render';out.mkdir(parents=True,exist_ok=True)
if (out/'manifest.json').exists():raise RuntimeError('Capture already exists; preserve original evidence')
level=folder+'/L_MaterialLineage'
if a.does_asset_exist(level):raise RuntimeError('Scene already exists; inspect before changing')
assert levels.new_level(level)

def neutral(name,color,rough,metal):
    m=tools.create_asset(name,folder,unreal.Material,unreal.MaterialFactoryNew())
    n=ml.create_material_expression(m,unreal.MaterialExpressionConstant3Vector)
    n.set_editor_property('constant',unreal.LinearColor(*color,1));ml.connect_material_property(n,'',unreal.MaterialProperty.MP_BASE_COLOR)
    for prop,value in [(unreal.MaterialProperty.MP_ROUGHNESS,rough),(unreal.MaterialProperty.MP_METALLIC,metal)]:
        n=ml.create_material_expression(m,unreal.MaterialExpressionConstant);n.set_editor_property('r',value);ml.connect_material_property(n,'',prop)
    ml.recompile_material(m);a.save_loaded_asset(m);return m
steel=neutral('M_FixtureSteel',(.18,.22,.25),.26,.8)
floor=neutral('M_FixtureFloor',(.07,.09,.105),.72,.0)
rubber=neutral('M_FixtureRubber',(.018,.023,.026),.7,.0)
original=a.load_asset(folder+'/MI_RedProp');painted=[]
def shape(label,mesh,loc,scale,mat,rotation=(0,0,0),paint=False):
    actor=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector(*loc),unreal.Rotator(pitch=rotation[0],yaw=rotation[1],roll=rotation[2]))
    actor.set_actor_label(label);actor.static_mesh_component.set_static_mesh(a.load_asset('/Engine/BasicShapes/'+mesh))
    actor.static_mesh_component.set_material(0,mat);actor.set_actor_scale3d(unreal.Vector(*scale))
    if paint:painted.append(actor.static_mesh_component)
    return actor
shape('展示地面','Cube',(0,0,-12),(16,16,.2),floor)
shape('支承底座','Cube',(0,0,10),(2.8,1.8,.2),original,paint=True)
for x in [-75,75]:
    shape('支架','Cube',(x,0,42),(.28,1.35,.5),original,paint=True)
    for y in [-65,65]:shape('固定螺栓','Cylinder',(x,y,24),(.12,.12,.12),steel)
shape('泵体','Cylinder',(0,0,105),(1.25,1.25,2.15),original,(0,0,90),True)
for y in [-105,105]:
    shape('端盖','Cylinder',(0,y,105),(1.4,1.4,.12),original,(0,0,90),True)
    shape('轴承','Cylinder',(0,y*1.1,105),(.48,.48,.22),steel,(0,0,90))
    for i in range(8):
        t=math.tau*i/8
        shape('端盖螺栓','Cylinder',(55*math.sin(t),y*1.09,105+55*math.cos(t)),(.1,.1,.1),steel,(0,0,90))
for y in range(-70,71,28):shape('散热环','Cylinder',(0,y,105),(1.32,1.32,.055),original,(0,0,90),True)
shape('顶部接头','Cylinder',(0,-30,183),(.38,.38,.5),steel)
shape('管口','Cylinder',(0,-30,212),(.55,.55,.1),rubber)
shape('接线盒','Cube',(72,28,123),(.36,.72,.65),original,paint=True)
shape('铭牌底板','Cube',(92,28,123),(.025,.5,.35),steel)
sun=actors.spawn_actor_from_class(unreal.DirectionalLight,unreal.Vector(0,0,500),unreal.Rotator(pitch=-42,yaw=-35,roll=0))
sun.light_component.set_mobility(unreal.ComponentMobility.MOVABLE);sun.light_component.set_editor_property('intensity',5.)
sky=actors.spawn_actor_from_class(unreal.SkyLight,unreal.Vector(0,0,400));sky.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
sky.light_component.set_editor_property('real_time_capture',True);sky.light_component.set_editor_property('intensity',1.)
actors.spawn_actor_from_class(unreal.SkyAtmosphere,unreal.Vector())
post=actors.spawn_actor_from_class(unreal.PostProcessVolume,unreal.Vector());post.set_editor_property('unbound',True)
settings=unreal.PostProcessSettings()
for k,v in [('override_auto_exposure_method',True),('auto_exposure_method',unreal.AutoExposureMethod.AEM_MANUAL),('override_auto_exposure_apply_physical_camera_exposure',True),('auto_exposure_apply_physical_camera_exposure',False),('override_auto_exposure_bias',True),('auto_exposure_bias',1.),('override_vignette_intensity',True),('vignette_intensity',0.)]:settings.set_editor_property(k,v)
post.set_editor_property('settings',settings)
pos=unreal.Vector(480,-650,360);rot=unreal.MathLibrary.find_look_at_rotation(pos,unreal.Vector(0,0,100))
cam=actors.spawn_actor_from_class(unreal.CameraActor,pos,rot);cam.set_actor_label('固定材质对照相机');cam.camera_component.set_editor_property('field_of_view',38.)
actors.set_selected_level_actors([]);levels.save_current_level()
key=unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
levels.set_level_viewport_camera_info(pos,rot,key);levels.set_level_viewport_fov(38.,key);levels.editor_set_game_view(True,key)
world=unreal.EditorLevelLibrary.get_editor_world()
for cmd in ['ShowFlag.Grid 0','ShowFlag.Selection 0','r.VSync 0','t.MaxFPS 60','r.ScreenPercentage 100','r.AntiAliasingMethod 0','r.SetRes 1600x900w']:
    unreal.SystemLibrary.execute_console_command(world,cmd)
variants=[('original','MI_RedProp'),('flattened','MI_RedProp_Flattened'),('roughness-control','MI_RoughControl'),('switch-control','MI_StaticSwitchControl')]
state={'i':0,'ticks':0,'handle':None,'finished':False}
manifest={'engine':unreal.SystemLibrary.get_engine_version(),'resolution':[1600,900],'camera':{'position':[480,-650,360],'target':[0,0,100],'fov':38},'scene':level,'paintedComponents':len(painted),'aa':'None for stable fixed-image comparison','captures':[]}
def finish():
    state['finished']=True
    for comp in painted:comp.set_material(0,original)
    levels.save_current_level()
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.unregister_slate_post_tick_callback(state['handle'])
    unreal.log('MATERIAL_LINEAGE_RENDER_DONE');unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
def tick(dt):
    if state['finished']:return
    try:
        state['ticks']+=1
        if state['ticks']==1:
            material=a.load_asset(folder+'/'+variants[state['i']][1])
            for comp in painted:comp.set_material(0,material)
        if state['ticks']==240:
            name,material=variants[state['i']];path=out/(name+'.png')
            unreal.SystemLibrary.execute_console_command(world,'HighResShot 1600x900 filename="'+path.as_posix()+'"')
            manifest['captures'].append({'name':name,'material':folder+'/'+material,'image':path.name,'warmupTicks':240})
        if state['ticks']==290:
            state['i']+=1;state['ticks']=0
            if state['i']==len(variants):finish()
    except Exception:
        manifest['error']=traceback.format_exc();unreal.log_error(manifest['error']);finish()
unreal.EditorPythonScripting.set_keep_python_script_alive(True)
state['handle']=unreal.register_slate_post_tick_callback(tick)
