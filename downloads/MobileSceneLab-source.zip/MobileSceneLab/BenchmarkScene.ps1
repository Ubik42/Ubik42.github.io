param([ValidateSet('Individual','Instanced')][string]$Variant='Instanced',[string]$Label='pilot',[ValidateSet('Desktop','MobilePreview')][string]$Renderer='Desktop',[switch]$MobileMap,[ValidateSet('Default','FullRange','CourtyardBudget','DistanceOnly','ResolutionOnly','CascadesOnly')][string]$ShadowProfile='Default',[string]$MapPath='',[int]$CaptureFrames=900,[int]$SampleStart=300,[int]$SampleEnd=780,[ValidateRange(320,8192)][int]$Width=1600,[ValidateRange(180,8192)][int]$Height=900,[switch]$DumpShaders)
$ErrorActionPreference='Stop'
if($SampleStart -lt 0 -or $SampleEnd -le $SampleStart -or $SampleEnd -ge ($CaptureFrames-50)){throw 'Invalid sampling interval'}
$output=Join-Path $PSScriptRoot ('Saved/Experiments/runtime-'+$Label+'-'+$Variant+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $output -Force | Out-Null
$image=(Join-Path $output 'runtime.png').Replace('\','/')
$commands='100:r.SetRes '+$Width+'x'+$Height+'w,'+($CaptureFrames-50).ToString()+':HighResShot 1 filename='+$image
$argsList=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('/Game/Lab/L_Courtyard_'+$Variant),'-game','-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding','-windowed','-ResX=1600','-ResY=900','-csvCaptureFrames=900','-csvCompression=0','-ExecCmds="r.VSync 0,t.MaxFPS 0,r.GPUCsvStatsEnabled 1,CsvProfile EXITONCOMPLETION"',('-csvExecCmds="'+$commands+'"'),('-abslog="'+$output+'\runtime.log"'))
if($MobileMap){$argsList[1]='/Game/Lab/L_Courtyard_Mobile'+$Variant}
if($MapPath){if(!$MapPath.StartsWith('/Game/') -or $MapPath.Contains('..')){throw 'MapPath must be a project asset path'};$argsList[1]=$MapPath}
for($i=0;$i -lt $argsList.Count;$i++){
    if($argsList[$i].StartsWith('-csvCaptureFrames=')){$argsList[$i]='-csvCaptureFrames='+$CaptureFrames}
    if($argsList[$i].StartsWith('-ResX=')){$argsList[$i]='-ResX='+$Width}
    if($argsList[$i].StartsWith('-ResY=')){$argsList[$i]='-ResY='+$Height}
}
$argsList+='-ForceRes'
if($DumpShaders){$argsList+='-ini:Engine:[ConsoleVariables]:r.DumpShaderDebugInfo=1'}
$mapFile=Join-Path $PSScriptRoot ('Content/'+$argsList[1].Substring(6)+'.umap')
if(!(Test-Path -LiteralPath $mapFile)){throw "Map not built: $mapFile"}
if($Renderer -eq 'MobilePreview'){$argsList+=@('-featureleveles31','-dx11')}
$shadowCommands=@{
    Default=''
    FullRange='r.Shadow.MaxCSMResolution 2048,r.Shadow.CSM.MaxCascades 4,r.Shadow.DistanceScale 1'
    CourtyardBudget='r.Shadow.MaxCSMResolution 1024,r.Shadow.CSM.MaxCascades 2,r.Shadow.DistanceScale 0.3'
    DistanceOnly='r.Shadow.MaxCSMResolution 2048,r.Shadow.CSM.MaxCascades 4,r.Shadow.DistanceScale 0.3'
    ResolutionOnly='r.Shadow.MaxCSMResolution 1024,r.Shadow.CSM.MaxCascades 4,r.Shadow.DistanceScale 1'
    CascadesOnly='r.Shadow.MaxCSMResolution 2048,r.Shadow.CSM.MaxCascades 2,r.Shadow.DistanceScale 1'
}[$ShadowProfile]
if($shadowCommands){
    for($i=0;$i -lt $argsList.Count;$i++){if($argsList[$i].StartsWith('-ExecCmds=')){$argsList[$i]=$argsList[$i].TrimEnd('"')+','+$shadowCommands+'"'}}
}
$process=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $argsList -WindowStyle Hidden -PassThru
@{pid=$process.Id;variant=$Variant;map=$argsList[1];requested_resolution=@($Width,$Height);sample_rows=@($SampleStart,$SampleEnd);capture_frames=$CaptureFrames;output=$output;arguments=$argsList;renderer=$Renderer;shadowProfile=$ShadowProfile;shadowCommands=$shadowCommands;platform=$(if($Renderer -eq 'MobilePreview'){'Windows D3D11 ES3_1 mobile preview on desktop GPU'}else{'Windows D3D12 SM5 standalone -game'})} | ConvertTo-Json -Depth 4 | Set-Content "$output/run.json" -Encoding utf8
Write-Output "Runtime PID $($process.Id): $output"
$process.WaitForExit()
$match=Select-String -LiteralPath "$output/runtime.log" -Pattern 'Writing CSV to file : (.+)' | Select-Object -Last 1
if(!$match){throw "No completed CSV in $output/runtime.log"}
$csvPath=$match.Matches[0].Groups[1].Value.Trim()
if(![IO.Path]::IsPathRooted($csvPath)){$csvPath=[IO.Path]::GetFullPath((Join-Path 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64' $csvPath))}
Copy-Item -LiteralPath $csvPath -Destination "$output/profile.csv"
python "$PSScriptRoot/Scripts/resolution_metadata.py" "$output"
if($LASTEXITCODE -ne 0){throw 'Runtime resolution did not match requested configuration'}
Write-Output $output
