﻿param([string]$EngineRoot='C:\Program Files\Epic Games\UE_5.8')
$ErrorActionPreference='Stop'
& "$PSScriptRoot/CheckAndroid.ps1" -EngineRoot $EngineRoot
$sdk='D:\3D\_tools\mini-effect-sdk\build\android-sdk'
$saved=@{}
foreach($key in @('JAVA_HOME','ANDROID_HOME','NDKROOT')){$saved[$key]=[Environment]::GetEnvironmentVariable($key,'Process')}
try {
    $env:JAVA_HOME='D:\3D\_tools\mini-effect-sdk\build\tools\jdk17\jdk-17.0.20.1+1'
    $env:ANDROID_HOME=$sdk
    $env:NDKROOT="$sdk/ndk/27.2.12479018"
    & "$EngineRoot/Engine/Build/BatchFiles/RunUAT.bat" BuildCookRun "-project=$PSScriptRoot/MobileSceneLab.uproject" -noP4 -unattended -utf8output -platform=Android -cookflavor=ASTC -clientconfig=Development -build -cook -stage -pak -package -archive "-archivedirectory=$PSScriptRoot/Saved/AndroidPackage" -map=/Game/Lab/L_Courtyard_Android -iterate -SkipCookingEditorContent
    $buildExit=$LASTEXITCODE
    $uatFolder=($EngineRoot -replace ':','' -replace '[\\/]','+')
    $uatLog=Join-Path $env:APPDATA "Unreal Engine/AutomationTool/Logs/$uatFolder/Log.txt"
    if(Test-Path -LiteralPath $uatLog){Copy-Item -LiteralPath $uatLog -Destination "$PSScriptRoot/Saved/android-package.log"}
    if($buildExit -ne 0){throw "Android packaging failed ($buildExit); see AutomationTool log and Saved/android-package.log"}
} finally {
    foreach($key in $saved.Keys){[Environment]::SetEnvironmentVariable($key,$saved[$key],'Process')}
}
