$ErrorActionPreference='Stop'
$coverageArgs=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('-ExecutePythonScript="'+$PSScriptRoot+'\Scripts\build_coverage.py"'),'-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding',('-abslog="'+$PSScriptRoot+'\Saved\coverage-build.log"'))
$coverageProcess=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $coverageArgs -WindowStyle Hidden -PassThru
Write-Output "Coverage build PID $($coverageProcess.Id)"
$coverageProcess.WaitForExit()
if(!(Select-String -LiteralPath "$PSScriptRoot/Saved/coverage-build.log" -Pattern 'COVERAGE_BUILD_OK' -Quiet)){throw 'Coverage generation failed; see Saved/coverage-build.log'}
