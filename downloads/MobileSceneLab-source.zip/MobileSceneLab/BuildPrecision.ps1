$ErrorActionPreference='Stop'
$precisionArgs=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('-ExecutePythonScript="'+$PSScriptRoot+'\Scripts\build_precision.py"'),'-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding',('-abslog="'+$PSScriptRoot+'\Saved\precision-build.log"'))
$precisionProcess=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $precisionArgs -WindowStyle Hidden -PassThru
Write-Output "Precision build PID $($precisionProcess.Id)"
$precisionProcess.WaitForExit()
if(!(Select-String -LiteralPath "$PSScriptRoot/Saved/precision-build.log" -Pattern 'PRECISION_BUILD_OK' -Quiet)){throw 'Precision generation failed; see Saved/precision-build.log'}
