$ErrorActionPreference='Stop'
python "$PSScriptRoot/Scripts/make_sampling_textures.py"
if($LASTEXITCODE -ne 0){throw 'Source texture generation failed'}
$samplingArgs=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('-ExecutePythonScript="'+$PSScriptRoot+'\Scripts\build_sampling.py"'),'-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding',('-abslog="'+$PSScriptRoot+'\Saved\sampling-build.log"'))
$samplingProcess=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $samplingArgs -WindowStyle Hidden -PassThru
Write-Output "Sampling build PID $($samplingProcess.Id)"
$samplingProcess.WaitForExit()
if(!(Select-String -LiteralPath "$PSScriptRoot/Saved/sampling-build.log" -Pattern 'SAMPLING_BUILD_OK' -Quiet)){throw 'Sampling generation failed; see Saved/sampling-build.log'}
