$ErrorActionPreference='Stop'
$argsList=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('-ExecutePythonScript="'+$PSScriptRoot+'\Scripts\capture_courtyard.py"'),'-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding')
$process=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $argsList -WindowStyle Hidden -PassThru
$process.Id | Set-Content -LiteralPath "$PSScriptRoot/Saved/capture-process.txt"
Write-Output "UE capture PID: $($process.Id)"
