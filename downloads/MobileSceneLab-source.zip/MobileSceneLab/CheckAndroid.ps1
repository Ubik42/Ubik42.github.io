param(
    [string]$EngineRoot='C:\Program Files\Epic Games\UE_5.8',
    [string]$SdkRoot='D:\3D\_tools\mini-effect-sdk\build\android-sdk',
    [string]$JavaRoot='D:\3D\_tools\mini-effect-sdk\build\tools\jdk17\jdk-17.0.20.1+1'
)
$ErrorActionPreference='Stop'
$requirements=Get-Content -LiteralPath "$EngineRoot/Engine/Config/Android/Android_SDK.json" -Raw | ConvertFrom-Json
$checks=@(
    @{name='UE Android game target';path="$EngineRoot/Engine/Binaries/Android/UnrealGame.target"},
    @{name='Required NDK';path="$SdkRoot/ndk/$($requirements.ndk)/source.properties"},
    @{name='Required Android platform';path="$SdkRoot/platforms/$($requirements.platforms)/android.jar"},
    @{name='Required build tools';path="$SdkRoot/build-tools/$($requirements.'build-tools')/aapt2.exe"},
    @{name='Java compiler';path="$JavaRoot/bin/javac.exe"}
)
$rows=@($checks | ForEach-Object {[pscustomobject]@{name=$_.name;path=$_.path;exists=(Test-Path -LiteralPath $_.path)}})
$report=[pscustomobject]@{checked_at=(Get-Date -Format o);engine=$EngineRoot;required_ndk=$requirements.ndk;checks=$rows;ready_for_sdk_verification=(@($rows | Where-Object {!$_.exists}).Count -eq 0);scope='File prerequisites only; successful packaging and emulator launch require separate evidence.'}
New-Item -ItemType Directory -Path "$PSScriptRoot/Saved/Experiments" -Force | Out-Null
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$PSScriptRoot/Saved/Experiments/android-prerequisites.json" -Encoding utf8
$rows | Format-Table name,exists,path -AutoSize
if(!$report.ready_for_sdk_verification){throw 'Android prerequisites incomplete. Install the missing UE platform component through Epic Games Launcher; see Saved/Experiments/android-prerequisites.json.'}
Write-Output 'Prerequisite files are present. Continue with Turnkey VerifySdk and packaging.'
