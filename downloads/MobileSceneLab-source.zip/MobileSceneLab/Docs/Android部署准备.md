# UE Android构建与运行

## 构建环境

UE5.8 Android平台组件、NDK27.2.12479018、android-34、build-tools35.0.1与JDK17。SDK版本按本机引擎Android_SDK.json配置，保留原生Vulkan工程使用的其他版本。环境变量只在构建进程中设置，结束后恢复。

Turnkey能识别SDK r27c，但因没有安装Android Studio而标记HostPrerequisites无效。本工程用独立SDK/JDK完成实际C++编译、Shader Cook、Gradle打包与模拟器启动，运行结果见Evidence/Android。

## 复现入口

1. `CheckAndroid.ps1`检查UE运行库、NDK、平台、构建工具和Java。
2. 在编辑器执行`Scripts/build_android_scene.py`，生成专属Android展示地图。生成器明确加载副本后修改，避免保存副本后仍在原地图操作。
3. `BuildAndroid.ps1`构建Android ASTC、x86_64 Development APK，输出至`Saved/AndroidPackage`；完整构建日志保存为`Saved/android-package.log`。
4. `python Scripts/verify_android.py --serial emulator-5568 --apk Saved/AndroidPackage/MobileSceneLab-x64.apk`安装指定包、启动、核对地图和Vulkan ES3.1日志，保存截图、APK哈希与设备信息。截图需人工检查。

Android配置关闭默认虚拟摇杆；独立天空网格使用双面Unlit材质。原移动预览地图保留，Android地图只承担部署展示，不参与已有桌面对照统计。

## 运行范围

Android15 x86_64模拟器、宿主RTX4080。运行日志确认Vulkan_ES31和L_Courtyard_Android，实际画面展示庭院、植被、反射与阴影。该记录验证UE Android构建、安装和渲染路径；性能对照仍来自各案例注明的Windows/D3D11 ES3.1预览。手机GPU、温度与功耗需要真实设备测量。

APK包含UE运行库，约174MB，保留在本地。公开源码包含项目配置、场景生成器、构建入口与运行证据；不包含SDK、调试密钥或引擎运行库。
