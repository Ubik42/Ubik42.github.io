# UE 庭院场景渲染与优化实验

UE 5.8 独立实验工程，已实现固定场景的组件组织对照、ES3.1 移动预览阴影预算、两档像素负载的透明覆盖对照及同轨迹视频。材质精度实验仍待扩展。

## 场景

脚本生成双拱门、石墙、侧廊、铺地、花池与青铜展台，复用本人 PCGWorkbench 生成并烘焙的藤蔓。两张关卡使用同一份几何布局及随机种子：Individual 为独立 StaticMeshActor，Instanced 按网格与材质组织 ISM。

自动实例化保留引擎默认行为，当前没有通过关闭它放大手工 ISM 收益。相同布局散列用于核对变体输入；还需检查截图及真实运行成本，组件数量变化本身不能证明帧率收益。

## 使用

直接打开 `Exhibit/index.html` 可查看阴影分屏、阶段数据与12秒真实移动预览录像。当前已有桌面提交成本对照和ES3.1阴影预算对照；详见 `Docs/第一次场景对照.md`、`Docs/阴影预算对照.md`、`Docs/运动镜头验证.md`。

- `Scripts/setup_mobile.py`：在UE编辑器中执行，生成固定环境贴图的移动关卡。
- `RunShadowComparison.ps1`：在桌面GPU的ES3.1路径交错运行六轮阴影预算配置。
- `RunShadowAblation.ps1`：基准与距离、分辨率、级联上限三个单变量配置各运行三次；`Scripts/report_shadow_ablation.py` 输出逐批范围和展示页数据。
- `Scripts/build_camera_sequence.py`：生成独立相机序列地图；`RecordRuntimeCamera.ps1` 固定时间步采集运动镜头。

- `BuildScene.ps1`：在独立后台编辑器生成两张实验关卡。只替换本工程 `/Game/Lab` 的生成场景。
- `CaptureScene.ps1`：固定相机、曝光与分辨率，保存两张关卡的真实 UE 截图。
- `RunComparison.ps1`：两种场景交错独立运行六次。每次捕获 900 帧 CSV，汇总第 300–779 行；第 850 帧截图放在计时样本之外。`BenchmarkScene.ps1` 可单独运行一个变体。
- 运行记录在 `Saved/Experiments`，日志在 `Saved/Logs`。

## 透明覆盖案例

`BuildCoverage.ps1` 生成相同布局的矩形卡片与贴边网格，`RunCoverageComparison.ps1` 进行长窗口六轮对照。`Exhibit/coverage.html` 展示几何面积、图像差分与阶段成本。888×500 案例透明阶段 0.0870→0.0543 ms，整帧没有改善；3840×2160 案例整帧 GPU 1.5002→1.3896 ms。完整条件见 `Docs/柔边叶片覆盖优化.md`，旧批次尺寸校正见 `Docs/分辨率校正.md`。它使用固定源颜色的受控半透明材质，保留多色实例混合顺序问题的排查过程。

当前构建配置为 Windows/D3D12 SM5，关闭 Lumen 与 VSM，保留移动 HDR/Forward 配置目标。桌面截图不等于移动预览；Android 部署和手机 GPU 性能尚未验证。截图的 60 fps 上限只用于减少后台资源占用，性能实验另设无上限配置。

## 材质精度案例

材质精度案例位于 `Exhibit/precision.html`。`BuildPrecision.ps1` 生成 Full/Half/局部坐标三张关卡，`RunPrecisionComparison.ps1` 采集真实移动预览图片；当前 Full 与 Half 图像一致，binary16 数值参考单独列出。详见 `Docs/材质精度与坐标范围.md`。此案例不提供FP16性能结论。

## 素材来源

`Content/Vines/Baked/SM_Vine3.uasset` 与 `Content/Showcase/Materials` 从本人本地 PCGWorkbench 复制，保留原资产路径以解析材质引用。源工程未改。场景布局参考本人已有庭院生成逻辑并重写为变体生成器。立方体和球体引用本机 UE BasicShapes，不随源码分发。

本项目不包含鸣潮或终末地提取素材。跨项目调研和长期开发记录位于 `D:\work\_tools\ue-client-portfolio-lab`。

## 已发现并处理的实际问题

- UE Python 的 Rotator 位置参数顺序与脚本最初假定不同，曾导致灯光朝上、画面全黑。旋转统一改成 pitch/yaw/roll 命名参数；相机使用 look-at 结果。黑帧记录保留并排除。
- 编辑器可以自动推断 ISM 材质用途，独立运行会对缺失 usage 的材质使用默认材质。生成器显式设置并保存复制过来的树皮/叶片材质 usage；旧的 fallback 采样不进入正式对照。
- UE 启动阶段 CSV 可以输出至引擎用户目录，采样脚本从当前日志提取实际文件路径再归档；退出和计时开关通过启动 ExecCmds 设置。
