$ErrorActionPreference='Stop'
$map=Join-Path $PSScriptRoot 'Content/Lab/L_Courtyard_MobileCamera.umap'
if(!(Test-Path -LiteralPath $map)){throw 'Build camera sequence first'}
$output=Join-Path $PSScriptRoot ('Saved/Experiments/runtime-camera-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
foreach($profile in @('FullRange','CourtyardBudget')){
    $folder=Join-Path $output $profile
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $events=for($index=0;$index -lt 60;$index++){
        $image=(Join-Path $folder ('frame-{0:d4}.png' -f $index)).Replace('\','/')
        ('{0}:HighResShot 960x540 filename={1}' -f (300+$index*2),$image)
    }
    $shadow=if($profile -eq 'FullRange'){'r.Shadow.MaxCSMResolution 2048,r.Shadow.CSM.MaxCascades 4,r.Shadow.DistanceScale 1'}else{'r.Shadow.MaxCSMResolution 1024,r.Shadow.CSM.MaxCascades 2,r.Shadow.DistanceScale 0.3'}
    $argsList=@(('"'+$PSScriptRoot+'/MobileSceneLab.uproject"'),'/Game/Lab/L_Courtyard_MobileCamera','-game','-unattended','-RenderOffscreen','-NoSound','-NoLiveCoding','-featureleveles31','-dx11','-UseFixedTimeStep','-FPS=20','-ResX=960','-ResY=540','-csvCaptureFrames=440','-csvCompression=0',('-ExecCmds="r.VSync 0,t.MaxFPS 0,CsvProfile EXITONCOMPLETION,'+$shadow+'"'),('-csvExecCmds="'+($events -join ',')+'"'),('-abslog="'+$folder+'/runtime.log"'))
    $p=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $argsList -WindowStyle Hidden -PassThru
    @{pid=$p.Id;profile=$profile;arguments=$argsList;measurement=$false;playbackFps=10;simulationFps=20;platform='D3D11 ES3_1 -game on RTX4080'} | ConvertTo-Json -Depth 4 | Set-Content "$folder/run.json" -Encoding utf8
    Write-Output "Camera runtime $($p.Id): $folder"
    $p.WaitForExit()
    if(@(Get-ChildItem $folder -Filter 'frame-*.png').Count -ne 60){throw "Incomplete camera capture: $folder"}
    & ffmpeg -hide_banner -loglevel error -framerate 10 -i "$folder/frame-%04d.png" -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart "$output/$profile.mp4"
    if($LASTEXITCODE -ne 0){throw 'Video encoding failed'}
}
Write-Output $output
