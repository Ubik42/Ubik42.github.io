$ErrorActionPreference='Stop'
$sequence=@('Individual','Instanced','Instanced','Individual','Individual','Instanced')
$tag=Get-Date -Format 'yyyyMMdd-HHmmss'
for($index=0;$index -lt $sequence.Count;$index++) {
    & "$PSScriptRoot/BenchmarkScene.ps1" -Variant $sequence[$index] -Label ($tag+'-'+($index+1))
}
$runs=@(Get-ChildItem "$PSScriptRoot/Saved/Experiments" -Directory -Filter ('runtime-'+$tag+'-*') | Sort-Object Name | Select-Object -ExpandProperty FullName)
python "$PSScriptRoot/Scripts/summarize_runtime.py" @runs --output "$PSScriptRoot/Saved/Experiments/comparison-$tag.json"
if($LASTEXITCODE -ne 0){throw 'Runtime comparison summary failed'}
