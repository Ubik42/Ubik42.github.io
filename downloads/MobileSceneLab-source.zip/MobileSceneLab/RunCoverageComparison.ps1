$ErrorActionPreference='Stop'
$tag='coverage-'+(Get-Date -Format 'yyyyMMdd-HHmmss')
$order=@('Quad','Trimmed','Trimmed','Quad','Quad','Trimmed')
for($index=0;$index -lt $order.Count;$index++) {
    & "$PSScriptRoot/BenchmarkScene.ps1" -Label ($tag+'-'+($index+1)+'-'+$order[$index]) -Renderer MobilePreview -MapPath ('/Game/Coverage/L_Coverage_'+$order[$index]) -CaptureFrames 6000 -SampleStart 3500 -SampleEnd 5500
}
$runs=@(Get-ChildItem "$PSScriptRoot/Saved/Experiments" -Directory -Filter ('runtime-'+$tag+'-*') | Sort-Object Name | Select-Object -ExpandProperty FullName)
python "$PSScriptRoot/Scripts/summarize_runtime.py" @runs --output "$PSScriptRoot/Saved/Experiments/comparison-$tag.json"
if($LASTEXITCODE -ne 0){throw 'Coverage summary failed'}
