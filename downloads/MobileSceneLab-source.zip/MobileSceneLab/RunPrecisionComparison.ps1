$ErrorActionPreference='Stop'
$precisionTag='precision-'+(Get-Date -Format 'yyyyMMdd-HHmmss')
foreach($precisionVariant in @('Full','Half','Local')) {
    & "$PSScriptRoot/BenchmarkScene.ps1" -Renderer MobilePreview -MapPath ('/Game/Precision/L_Precision_'+$precisionVariant) -Label ($precisionTag+'-'+$precisionVariant) -Width 1600 -Height 900 -DumpShaders
}
Write-Output "Precision batch: $precisionTag"
