param([int]$Width=3840,[int]$Height=2160)
$ErrorActionPreference='Stop'
$tag='sampling-'+(Get-Date -Format 'yyyyMMdd-HHmmss')
$order=@('Separate','Packed','Packed','Separate','Separate','Packed')
for($index=0;$index -lt $order.Count;$index++) {
    & "$PSScriptRoot/BenchmarkScene.ps1" -Label ($tag+'-'+($index+1)+'-'+$order[$index]) -Renderer MobilePreview -MapPath ('/Game/Sampling/L_Sampling_'+$order[$index]) -CaptureFrames 6000 -SampleStart 3500 -SampleEnd 5500 -Width $Width -Height $Height
}
$runs=@(Get-ChildItem "$PSScriptRoot/Saved/Experiments" -Directory -Filter ('runtime-'+$tag+'-*') | Sort-Object Name | Select-Object -ExpandProperty FullName)
python "$PSScriptRoot/Scripts/summarize_runtime.py" @runs --output "$PSScriptRoot/Saved/Experiments/comparison-$tag.json"
if($LASTEXITCODE -ne 0){throw 'Sampling summary failed'}
