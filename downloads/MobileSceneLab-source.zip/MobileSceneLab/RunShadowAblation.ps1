$ErrorActionPreference='Stop'
$tag='shadow-ablation-'+(Get-Date -Format 'yyyyMMdd-HHmmss')
# Balanced forward/reverse blocks: each setting runs three times.
$order=@('FullRange','DistanceOnly','ResolutionOnly','CascadesOnly',
         'CascadesOnly','ResolutionOnly','DistanceOnly','FullRange',
         'ResolutionOnly','FullRange','CascadesOnly','DistanceOnly')
for($index=0;$index -lt $order.Count;$index++) {
    & "$PSScriptRoot/BenchmarkScene.ps1" -Variant Instanced -Label ($tag+'-'+('{0:D2}' -f ($index+1))) -Renderer MobilePreview -MobileMap -ShadowProfile $order[$index]
}
$runs=@(Get-ChildItem "$PSScriptRoot/Saved/Experiments" -Directory -Filter ('runtime-'+$tag+'-*') | Sort-Object Name | Select-Object -ExpandProperty FullName)
python "$PSScriptRoot/Scripts/summarize_runtime.py" @runs --output "$PSScriptRoot/Saved/Experiments/comparison-$tag.json"
if($LASTEXITCODE -ne 0){throw 'Shadow ablation summary failed'}
