"""Read-only bounds and lighting audit for the fixed courtyard camera."""
import json,math,unreal
from pathlib import Path
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
assert levels.load_level('/Game/Lab/L_Courtyard_MobileInstanced')
scene=actors.get_all_level_actors()
camera=next(a for a in scene if isinstance(a,unreal.CameraActor))
position=camera.get_actor_location();direction=camera.get_actor_forward_vector()
records=[]
for actor in scene:
    if not actor.get_components_by_class(unreal.StaticMeshComponent):continue
    center,extent=actor.get_actor_bounds(False)
    delta=center-position
    depth=delta.x*direction.x+delta.y*direction.y+delta.z*direction.z
    depth_radius=abs(direction.x)*extent.x+abs(direction.y)*extent.y+abs(direction.z)*extent.z
    records.append({'label':actor.get_actor_label(),'bounds_center_cm':[center.x,center.y,center.z],
        'bounds_extent_cm':[extent.x,extent.y,extent.z],'max_camera_depth_cm':depth+depth_radius})
light=next(a.light_component for a in scene if isinstance(a,unreal.DirectionalLight))
properties={name:light.get_editor_property(name) for name in ['dynamic_shadow_distance_movable_light','dynamic_shadow_cascades','cascade_distribution_exponent','cascade_transition_fraction']}
max_depth=max(r['max_camera_depth_cm'] for r in records)
result={'map':'L_Courtyard_MobileInstanced','camera_location_cm':[position.x,position.y,position.z],
    'light':properties,'bounds':records,'max_camera_depth_cm':max_depth,
    'conservative_fixed_view_distance_cm':math.ceil(max_depth*1.25/100)*100,
    'scope':'Conservative actor bounds for this fixed camera; excludes movement and off-camera casters outside this scene. Not an automatic quality guarantee.'}
path=Path(unreal.Paths.project_dir())/'Saved/Experiments/shadow-scene-audit.json'
path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
unreal.log('SHADOW_SCENE_AUDIT_OK '+str(path))
unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
