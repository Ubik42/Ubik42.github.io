"""Android display map with explicit sky geometry; measured preview maps stay intact."""
import unreal
a=unreal.EditorAssetLibrary
l=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
s=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
m=unreal.MaterialEditingLibrary
try:
    assert l.load_level('/Game/Lab/L_Courtyard_MobileInstanced')
    assert unreal.EditorLoadingAndSavingUtils.save_map(unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world(),'/Game/Lab/L_Courtyard_Android')
    assert l.load_level('/Game/Lab/L_Courtyard_Android')
    for actor in s.get_all_level_actors():
        if isinstance(actor,unreal.SkyAtmosphere):s.destroy_actor(actor)
    path='/Game/Lab/Materials/M_AndroidSky'
    mat=a.load_asset(path) if a.does_asset_exist(path) else unreal.AssetToolsHelpers.get_asset_tools().create_asset('M_AndroidSky','/Game/Lab/Materials',unreal.Material,unreal.MaterialFactoryNew())
    mat.set_editor_property('shading_model',unreal.MaterialShadingModel.MSM_UNLIT)
    mat.set_editor_property('two_sided',True);mat.set_editor_property('is_sky',True)
    m.delete_all_material_expressions(mat)
    color=m.create_material_expression(mat,unreal.MaterialExpressionConstant3Vector)
    color.set_editor_property('constant',unreal.LinearColor(.08,.15,.25,1.))
    assert m.connect_material_property(color,'',unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    m.recompile_material(mat);a.save_loaded_asset(mat)
    sky=s.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector())
    sky.set_actor_label('Android explicit unlit sky')
    sky.static_mesh_component.set_static_mesh(a.load_asset('/Engine/BasicShapes/Sphere'))
    sky.static_mesh_component.set_material(0,mat)
    sky.static_mesh_component.set_editor_property('cast_shadow',False)
    sky.set_actor_enable_collision(False);sky.set_actor_scale3d(unreal.Vector(500,500,500))
    s.set_selected_level_actors([]);assert l.save_current_level()
    unreal.log('ANDROID_SCENE_OK')
finally:unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')

