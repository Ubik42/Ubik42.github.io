"""Build an autoplay camera sequence in a separate map for mobile -game capture."""
import math,unreal
assets=unreal.EditorAssetLibrary
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
destination='/Game/Lab/L_Courtyard_MobileCamera'
if not assets.does_asset_exist(destination):
    assert levels.load_level('/Game/Lab/L_Courtyard_MobileInstanced')
    world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    assert unreal.EditorLoadingAndSavingUtils.save_map(world,destination)
assert levels.load_level(destination)
for previous in actors.get_all_level_actors():
    if isinstance(previous,unreal.LevelSequenceActor) and previous.get_actor_label()=='同轨迹阴影镜头':actors.destroy_actor(previous)
camera=next(a for a in actors.get_all_level_actors() if isinstance(a,unreal.CameraActor))
tools=unreal.AssetToolsHelpers.get_asset_tools()
path='/Game/Lab/Sequences/LS_CourtyardCamera'
sequence=assets.load_asset(path) if assets.does_asset_exist(path) else None
if not sequence:sequence=tools.create_asset('LS_CourtyardCamera','/Game/Lab/Sequences',unreal.LevelSequence,unreal.LevelSequenceFactoryNew())
for binding in sequence.get_bindings():binding.remove()
for track in sequence.get_tracks():sequence.remove_track(track)
sequence.set_display_rate(unreal.FrameRate(20,1));sequence.set_playback_start(0);sequence.set_playback_end(120)
binding=sequence.add_possessable(camera)
track=binding.add_track(unreal.MovieScene3DTransformTrack);section=track.add_section();section.set_range(0,120)
channels=section.get_all_channels()
for frame in range(121):
    phase=frame/120*math.pi*2
    position=unreal.Vector(650+1250*math.sin(phase),-2600+450*math.sin(phase),1000+120*math.sin(phase))
    rotation=unreal.MathLibrary.find_look_at_rotation(position,unreal.Vector(0,350,270))
    values=[position.x,position.y,position.z,rotation.roll,rotation.pitch,rotation.yaw,1,1,1]
    for channel,value in zip(channels,values):channel.add_key(unreal.FrameNumber(frame),float(value))
cut_track=sequence.add_track(unreal.MovieSceneCameraCutTrack);cut=cut_track.add_section();cut.set_range(0,120)
binding_id=unreal.MovieSceneObjectBindingID();binding_id.set_editor_property('guid',binding.get_id())
cut.set_camera_binding_id(binding_id)
actor=actors.spawn_actor_from_class(unreal.LevelSequenceActor,unreal.Vector())
actor.set_actor_label('同轨迹阴影镜头');actor.set_sequence(sequence)
settings=unreal.MovieSceneSequencePlaybackSettings()
settings.set_editor_property('auto_play',True)
loop=unreal.MovieSceneSequenceLoopCount();loop.set_editor_property('value',-1)
settings.set_editor_property('loop_count',loop)
actor.set_editor_property('playback_settings',settings)
assets.save_loaded_asset(sequence)
world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
assert levels.save_current_level()
unreal.log('CAMERA_SEQUENCE_BUILD_OK')
unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
