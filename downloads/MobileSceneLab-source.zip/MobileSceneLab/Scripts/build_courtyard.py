"""Generate identical geometry with individual components or explicit instancing."""
import unreal
import math
import random
import json
import hashlib
from pathlib import Path

ROOT=Path(unreal.Paths.project_dir())
assets=unreal.EditorAssetLibrary
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
tools=unreal.AssetToolsHelpers.get_asset_tools()
ml=unreal.MaterialEditingLibrary

def material(name,color,roughness=.82,metallic=0):
    path='/Game/Lab/Materials/'+name
    if assets.does_asset_exist(path):return assets.load_asset(path)
    mat=tools.create_asset(name,'/Game/Lab/Materials',unreal.Material,unreal.MaterialFactoryNew())
    base=ml.create_material_expression(mat,unreal.MaterialExpressionConstant3Vector)
    base.set_editor_property('constant',unreal.LinearColor(*color,1))
    ml.connect_material_property(base,'',unreal.MaterialProperty.MP_BASE_COLOR)
    for prop,value in [(unreal.MaterialProperty.MP_ROUGHNESS,roughness),(unreal.MaterialProperty.MP_METALLIC,metallic)]:
        node=ml.create_material_expression(mat,unreal.MaterialExpressionConstant)
        node.set_editor_property('r',value)
        ml.connect_material_property(node,'',prop)
    ml.recompile_material(mat)
    assets.save_loaded_asset(mat)
    return mat

def make_layout():
    rng=random.Random(4217)
    items=[]
    def block(label,loc,size,mat,rotation=(0,0,0)):
        items.append({'label':label,'mesh':'/Engine/BasicShapes/Cube','location':loc,'scale':[v/100 for v in size],'rotation':rotation,'material':mat})
    block('地基',(0,0,-42),(4300,4800,60),'ground')
    # Inset paving uses a reproducible pattern rather than a flat repeating texture.
    for row in range(24):
        for col in range(23):
            x=(col-11)*168+(84 if row%2 else 0);y=(row-13)*168
            block('铺地',(x,y,-7),(160,160,12),'stone'+str(rng.randrange(5)))
    for wall_y in [550,1650]:
        for row in range(10):
            z=40+row*74
            for col in range(11):
                x=-660+col*132+(66 if row%2 else 0)
                if abs(x)>685:continue
                if z<330 and abs(x)<240:continue
                if 330<=z<550 and abs(x)<math.sqrt(max(0,245**2-(z-330)**2))+48:continue
                block('拱墙',(x,wall_y+rng.uniform(-3,3),z),(128,88,71),'stone'+str(rng.randrange(5)))
        for side in [-1,1]:
            for row in range(5):block('门柱',(side*218,wall_y-25,35+row*65),(82,125,63),'stone3')
        for i in range(17):
            angle=(i+.5)*math.pi/17
            block('拱券',(218*math.cos(angle),wall_y-25,330+218*math.sin(angle)),(46,126,87),'stone4',(math.degrees(angle)-90,0,0))
        block('压顶',(0,wall_y,760),(1450,130,35),'stone3')
        for side in [-1,1]:
            block('台基',(side*450,wall_y-15,12),(480,170,24),'stone2')
            items.append({'label':'藤蔓','mesh':'/Game/Vines/Baked/SM_Vine3','location':(side*12,wall_y-75,365),'scale':(1,1,1),'rotation':(0,0,0),'material':None})
    for side in [-1,1]:
        for column in range(8):
            y=-1550+column*430
            for row in range(8):
                block('侧廊柱',(side*1500,y,42+row*84),(140,140,80),'stone'+str(rng.randrange(5)))
            block('柱脚',(side*1500,y,12),(230,230,24),'stone4')
            block('柱帽',(side*1500,y,720),(210,210,80),'stone3')
        block('侧廊横梁',(side*1500,-45,785),(200,3500,100),'stone2')
    for step in range(4):block('中央展台',(0,-600,15+step*25),(540-step*75,540-step*75,28),'dark')
    items.append({'label':'青铜雕塑','mesh':'/Engine/BasicShapes/Sphere','location':(0,-600,240),'scale':(2.4,2.4,2.4),'rotation':(0,0,0),'material':'bronze'})
    for side in [-1,1]:
        for y in [-1500,-500,500,1500]:
            block('花池',(side*1040,y,32),(350,330,64),'dark')
            block('苔藓土壤',(side*1040,y,68),(320,300,12),'moss')
    return items

def build(variant,items,mats):
    path='/Game/Lab/L_Courtyard_'+variant
    if assets.does_asset_exist(path):
        levels.load_level(path)
        for actor in actors.get_all_level_actors():
            if actor.get_class().get_name() not in ['WorldSettings','LevelScriptActor','Brush','DefaultPhysicsVolume']:actors.destroy_actor(actor)
    else:assert levels.new_level(path)
    meshes={};groups={};count=0
    for item in items:
        mesh=meshes.setdefault(item['mesh'],assets.load_asset(item['mesh']))
        if not mesh:raise RuntimeError('Missing mesh '+item['mesh'])
        location=unreal.Vector(*item['location']);rotation=unreal.Rotator(pitch=item['rotation'][0],yaw=item['rotation'][1],roll=item['rotation'][2]);scale=unreal.Vector(*item['scale'])
        mat=mats.get(item['material'])
        if variant=='Individual':
            actor=actors.spawn_actor_from_class(unreal.StaticMeshActor,location,rotation)
            actor.set_actor_label(item['label'])
            comp=actor.static_mesh_component
            comp.set_static_mesh(mesh)
            if mat:comp.set_material(0,mat)
            actor.set_actor_scale3d(scale)
            count+=1
        else:
            key=(item['mesh'],item['material'])
            if key not in groups:
                actor=actors.spawn_actor_from_class(unreal.Actor,unreal.Vector())
                actor.set_actor_label('实例组_'+(item['material'] or '藤蔓'))
                subsystem=unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
                parent=subsystem.k2_gather_subobject_data_for_instance(actor)[0]
                handle,reason=subsystem.add_new_subobject(unreal.AddNewSubobjectParams(parent_handle=parent,new_class=unreal.InstancedStaticMeshComponent))
                data=unreal.SubobjectDataBlueprintFunctionLibrary.get_data(handle)
                comp=unreal.SubobjectDataBlueprintFunctionLibrary.get_object(data)
                if not comp:raise RuntimeError('Cannot create ISM: '+str(reason))
                comp.set_static_mesh(mesh)
                if mat:comp.set_material(0,mat)
                groups[key]=comp
                count+=1
            comp=groups[key]
            comp.add_instance(unreal.Transform(location=location,rotation=rotation,scale=scale),True)
        comp.set_mobility(unreal.ComponentMobility.STATIC)
        comp.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    sun=actors.spawn_actor_from_class(unreal.DirectionalLight,unreal.Vector(0,0,1800),unreal.Rotator(pitch=-32,yaw=145,roll=0))
    sun.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
    sun.light_component.set_editor_property('intensity',5.0)
    sun.light_component.set_editor_property('light_color',unreal.Color(255,222,178,255))
    sun.light_component.set_editor_property('atmosphere_sun_light',True)
    sky=actors.spawn_actor_from_class(unreal.SkyLight,unreal.Vector(0,0,1000))
    sky.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
    sky.light_component.set_editor_property('real_time_capture',True)
    sky.light_component.set_editor_property('intensity',1.2)
    actors.spawn_actor_from_class(unreal.SkyAtmosphere,unreal.Vector())
    actors.spawn_actor_from_class(unreal.ExponentialHeightFog,unreal.Vector(0,0,-100))
    post=actors.spawn_actor_from_class(unreal.PostProcessVolume,unreal.Vector())
    post.set_editor_property('unbound',True)
    settings=unreal.PostProcessSettings()
    for prop,value in [('override_auto_exposure_method',True),('auto_exposure_method',unreal.AutoExposureMethod.AEM_MANUAL),('override_auto_exposure_apply_physical_camera_exposure',True),('auto_exposure_apply_physical_camera_exposure',False),('override_auto_exposure_bias',True),('auto_exposure_bias',1.0)]:settings.set_editor_property(prop,value)
    post.set_editor_property('settings',settings)
    position=unreal.Vector(650,-2600,1000)
    rotation=unreal.MathLibrary.find_look_at_rotation(position,unreal.Vector(0,350,270))
    camera=actors.spawn_actor_from_class(unreal.CameraActor,position,rotation)
    camera.set_actor_label('固定对照相机')
    camera.camera_component.set_editor_property('field_of_view',58.0)
    camera.set_editor_property('auto_activate_for_player',unreal.AutoReceiveInput.PLAYER0)
    actors.set_selected_level_actors([])
    assert levels.save_current_level()
    return {'map':path,'variant':variant,'geometry_instances':len(items),'mesh_components':count,'layout_sha256':hashlib.sha256(json.dumps(items,sort_keys=True).encode()).hexdigest()}

try:
    mats={}
    for i in range(5):mats['stone'+str(i)]=material('M_Stone'+str(i),(.25+i*.025,.20+i*.02,.145+i*.014))
    mats['ground']=material('M_Ground',(.055,.07,.06))
    mats['dark']=material('M_Dark',(.055,.07,.075))
    mats['moss']=material('M_Moss',(.07,.13,.035))
    mats['bronze']=material('M_Bronze',(.45,.25,.08),.28,.8)
    # Runtime cannot auto-save the usage flags inferred by the editor.
    for name in ['M_Bark','M_Leaves']:
        mat=assets.load_asset('/Game/Showcase/Materials/'+name)
        ml.set_material_usage(mat,unreal.MaterialUsage.MATUSAGE_INSTANCED_STATIC_MESHES)
        ml.recompile_material(mat)
        assets.save_loaded_asset(mat)
    items=make_layout()
    records=[build(variant,items,mats) for variant in ['Individual','Instanced']]
    assets.save_directory('/Game/Lab',only_if_is_dirty=True,recursive=True)
    out=ROOT/'Saved/Experiments';out.mkdir(parents=True,exist_ok=True)
    (out/'scene-build.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.log('MOBILE_SCENE_BUILD_OK '+json.dumps(records))
finally:
    unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
