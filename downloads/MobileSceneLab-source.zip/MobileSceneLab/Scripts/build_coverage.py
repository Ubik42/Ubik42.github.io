"""Original soft leaf cards: identical UV/material/instances, only polygon coverage changes."""
import json
import math
import random
import unreal
from pathlib import Path

root=Path(unreal.Paths.project_dir())
assets=unreal.EditorAssetLibrary
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
tools=unreal.AssetToolsHelpers.get_asset_tools()
ml=unreal.MaterialEditingLibrary

def mesh(name, points):
    path='/Game/Coverage/'+name
    if assets.does_asset_exist(path):
        return assets.load_asset(path)
    dynamic=unreal.DynamicMesh()
    unreal.GeometryScript_Primitives.append_triangulated_polygon(dynamic,unreal.GeometryScriptPrimitiveOptions(),unreal.Transform(),[unreal.Vector2D(x,y) for x,y in points],False)
    planar_name=next(name for name in dir(unreal.GeometryScript_UVs) if name.endswith('from_planar_projection'))
    getattr(unreal.GeometryScript_UVs,planar_name)(dynamic,0,unreal.Transform(scale=unreal.Vector(100,200,1)),unreal.GeometryScriptMeshSelection())
    result=unreal.GeometryScript_NewAssetUtils.create_new_static_mesh_asset_from_mesh(dynamic,path,unreal.GeometryScriptCreateNewStaticMeshAssetOptions())
    asset=result[0] if isinstance(result,tuple) else result
    if not asset:raise RuntimeError('Mesh creation failed: '+name)
    assets.save_loaded_asset(asset)
    return asset

def leaf_material():
    path='/Game/Coverage/M_SoftLeaf'
    mat=assets.load_asset(path) if assets.does_asset_exist(path) else tools.create_asset('M_SoftLeaf','/Game/Coverage',unreal.Material,unreal.MaterialFactoryNew())
    ml.delete_all_material_expressions(mat)
    mat.set_editor_property('blend_mode',unreal.BlendMode.BLEND_TRANSLUCENT)
    mat.set_editor_property('two_sided',True)
    mat.set_editor_property('shading_model',unreal.MaterialShadingModel.MSM_UNLIT)
    uv=ml.create_material_expression(mat,unreal.MaterialExpressionTextureCoordinate)
    shader=ml.create_material_expression(mat,unreal.MaterialExpressionCustom)
    shader.set_editor_property('output_type',unreal.CustomMaterialOutputType.CMOT_FLOAT4)
    item=unreal.CustomInput();item.set_editor_property('input_name','UV')
    shader.set_editor_property('inputs',[item])
    shader.set_editor_property('code','''float2 p=UV*float2(100.0/35.0,200.0/82.0);
float r=length(p);
float alpha=(1.0-smoothstep(0.91,1.0,r))*0.72;
float vein=exp(-abs(p.x)*45.0);
float ribs=pow(saturate(cos((p.y+abs(p.x)*0.65)*35.0)),12.0);
// Constant source color isolates coverage from unordered ISM alpha blending.
// Leaf shading and veins modulate alpha only: C * (1 - product(1-alpha)).
alpha*=saturate(0.18+0.48*(1.0-r)+0.22*vein+0.12*ribs);
return float4(float3(0.055,0.19,0.018),alpha);''')
    assert ml.connect_material_expressions(uv,'',shader,'UV')
    rgb=ml.create_material_expression(mat,unreal.MaterialExpressionComponentMask)
    for prop,value in [('r',True),('g',True),('b',True),('a',False)]:rgb.set_editor_property(prop,value)
    opacity=ml.create_material_expression(mat,unreal.MaterialExpressionComponentMask)
    for prop,value in [('r',False),('g',False),('b',False),('a',True)]:opacity.set_editor_property(prop,value)
    assert ml.connect_material_expressions(shader,'',rgb,'')
    assert ml.connect_material_expressions(shader,'',opacity,'')
    assert ml.connect_material_property(rgb,'',unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    assert ml.connect_material_property(opacity,'',unreal.MaterialProperty.MP_OPACITY)
    ml.set_material_usage(mat,unreal.MaterialUsage.MATUSAGE_INSTANCED_STATIC_MESHES)
    ml.recompile_material(mat);assets.save_loaded_asset(mat)
    return mat

def build(variant, static_mesh, material, transforms):
    path='/Game/Coverage/L_Coverage_'+variant
    if assets.does_asset_exist(path):
        levels.load_level(path)
        for a in actors.get_all_level_actors():
            if a.get_class().get_name() not in ['WorldSettings','LevelScriptActor','Brush','DefaultPhysicsVolume']:actors.destroy_actor(a)
    else:assert levels.new_level(path)
    actor=actors.spawn_actor_from_class(unreal.Actor,unreal.Vector())
    actor.set_actor_label('同布局柔边叶片_'+variant)
    subsystem=unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
    parent=subsystem.k2_gather_subobject_data_for_instance(actor)[0]
    handle,reason=subsystem.add_new_subobject(unreal.AddNewSubobjectParams(parent_handle=parent,new_class=unreal.InstancedStaticMeshComponent))
    comp=unreal.SubobjectDataBlueprintFunctionLibrary.get_object(unreal.SubobjectDataBlueprintFunctionLibrary.get_data(handle))
    if not comp:raise RuntimeError(str(reason))
    comp.set_static_mesh(static_mesh);comp.set_material(0,material)
    comp.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    comp.set_editor_property('cast_shadow',False)
    for location,rotation,scale in transforms:
        comp.add_instance(unreal.Transform(location=unreal.Vector(*location),rotation=unreal.Rotator(pitch=rotation[0],yaw=rotation[1],roll=rotation[2]),scale=unreal.Vector(*scale)),True)
    post=actors.spawn_actor_from_class(unreal.PostProcessVolume,unreal.Vector())
    post.set_editor_property('unbound',True)
    settings=unreal.PostProcessSettings()
    for prop,value in [('override_auto_exposure_method',True),('auto_exposure_method',unreal.AutoExposureMethod.AEM_MANUAL),('override_auto_exposure_apply_physical_camera_exposure',True),('auto_exposure_apply_physical_camera_exposure',False),('override_auto_exposure_bias',True),('auto_exposure_bias',1.0),('override_vignette_intensity',True),('vignette_intensity',0.0)]:settings.set_editor_property(prop,value)
    post.set_editor_property('settings',settings)
    position=unreal.Vector(0,-1300,500)
    camera=actors.spawn_actor_from_class(unreal.CameraActor,position,unreal.MathLibrary.find_look_at_rotation(position,unreal.Vector(0,150,500)))
    camera.camera_component.set_editor_property('field_of_view',60)
    camera.set_editor_property('auto_activate_for_player',unreal.AutoReceiveInput.PLAYER0)
    actors.set_selected_level_actors([]);assert levels.save_current_level()
    return path

try:
    square=[(-50,-100),(50,-100),(50,100),(-50,100)]
    # Circumscribed octagon contains the complete alpha support ellipse.
    polygon=[(35/math.cos(math.pi/8)*math.cos((i+.5)*math.pi/4),82/math.cos(math.pi/8)*math.sin((i+.5)*math.pi/4)) for i in range(8)]
    meshes={'Quad':mesh('SM_LeafQuad',square),'Trimmed':mesh('SM_LeafTrimmed',polygon)}
    material=leaf_material();rng=random.Random(4217);transforms=[]
    for layer in range(6):
        for row in range(13):
            for col in range(25):
                transforms.append(((col*60-720+rng.uniform(-12,12),layer*35,row*74+rng.uniform(-14,14)),(0,rng.uniform(-8,8),90+rng.uniform(-18,18)),(1,1,1)))
    maps={v:build(v,m,material,transforms) for v,m in meshes.items()}
    assets.save_directory('/Game/Coverage',only_if_is_dirty=True,recursive=True)
    area=lambda p:abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p))))/2
    report={'maps':maps,'instances':len(transforms),'triangles_per_mesh':{'Quad':2,'Trimmed':6},'polygon_area_cm2':{'Quad':area(square),'Trimmed':area(polygon)},'alpha_support':'ellipse radii 35 cm and 82 cm; smooth alpha ends at ellipse boundary','seed':4217,'same_material':material.get_path_name(),'transforms':transforms}
    (root/'Saved/Experiments/coverage-build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.log('COVERAGE_BUILD_OK')
finally:unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
