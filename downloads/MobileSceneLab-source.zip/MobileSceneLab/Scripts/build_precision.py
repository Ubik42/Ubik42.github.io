"""Material precision and coordinate-range case; native material nodes only."""
import json
from pathlib import Path
import unreal

root=Path(unreal.Paths.project_dir())
assets=unreal.EditorAssetLibrary
ml=unreal.MaterialEditingLibrary
tools=unreal.AssetToolsHelpers.get_asset_tools()
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)

def material(name,precision,offset):
    path='/Game/Precision/M_'+name
    mat=assets.load_asset(path) if assets.does_asset_exist(path) else tools.create_asset('M_'+name,'/Game/Precision',unreal.Material,unreal.MaterialFactoryNew())
    mat.set_editor_property('shading_model',unreal.MaterialShadingModel.MSM_UNLIT)
    mat.set_editor_property('two_sided',True)
    mat.set_editor_property('float_precision_mode',precision)
    ml.delete_all_material_expressions(mat)
    def node(kind,**props):
        n=ml.create_material_expression(mat,getattr(unreal,'MaterialExpression'+kind))
        for key,value in props.items():n.set_editor_property(key,value)
        return n
    def link(a,b,pin):assert ml.connect_material_expressions(a,'',b,pin)
    uv=node('TextureCoordinate')
    frequency=node('ScalarParameter',parameter_name='TileCount',default_value=32.)
    scale=node('Multiply');link(uv,scale,'A');link(frequency,scale,'B')
    origin=node('ScalarParameter',parameter_name='TileOrigin',default_value=float(offset))
    shifted=node('Add');link(scale,shifted,'A');link(origin,shifted,'B')
    fractional=node('Frac');link(shifted,fractional,'')
    x=node('ComponentMask',r=True,g=False,b=False,a=False);link(fractional,x,'')
    y=node('ComponentMask',r=False,g=True,b=False,a=False);link(fractional,y,'')
    product=node('Multiply');link(x,product,'A');link(y,product,'B')
    # R/G show fractional coordinates; B shows their interaction.
    rgb=node('AppendVector');link(fractional,rgb,'A');link(product,rgb,'B')
    assert ml.connect_material_property(rgb,'',unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    ml.layout_material_expressions(mat);ml.recompile_material(mat);assets.save_loaded_asset(mat)
    return mat

def scene(name,mat):
    path='/Game/Precision/L_Precision_'+name
    if assets.does_asset_exist(path):
        levels.load_level(path)
        for actor in actors.get_all_level_actors():
            if actor.get_class().get_name() not in ['WorldSettings','LevelScriptActor','Brush','DefaultPhysicsVolume']:actors.destroy_actor(actor)
    else:assert levels.new_level(path)
    plane=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector())
    plane.static_mesh_component.set_static_mesh(assets.load_asset('/Engine/BasicShapes/Plane'))
    plane.static_mesh_component.set_material(0,mat)
    plane.set_actor_scale3d(unreal.Vector(6.75,12,1))
    # Keep the default runtime pawn behind the test surface and out of view.
    actors.spawn_actor_from_class(unreal.PlayerStart,unreal.Vector(0,0,-5000))
    camera=actors.spawn_actor_from_class(unreal.CameraActor,unreal.Vector(0,0,1200),unreal.Rotator(pitch=-90,yaw=0,roll=0))
    camera.camera_component.set_editor_property('projection_mode',unreal.CameraProjectionMode.ORTHOGRAPHIC)
    camera.camera_component.set_editor_property('ortho_width',1200.)
    camera.set_editor_property('auto_activate_for_player',unreal.AutoReceiveInput.PLAYER0)
    post=actors.spawn_actor_from_class(unreal.PostProcessVolume,unreal.Vector())
    post.set_editor_property('unbound',True)
    settings=unreal.PostProcessSettings()
    for key,value in [('override_auto_exposure_method',True),('auto_exposure_method',unreal.AutoExposureMethod.AEM_MANUAL),('override_auto_exposure_apply_physical_camera_exposure',True),('auto_exposure_apply_physical_camera_exposure',False),('override_auto_exposure_bias',True),('auto_exposure_bias',0.),('override_vignette_intensity',True),('vignette_intensity',0.)]:settings.set_editor_property(key,value)
    post.set_editor_property('settings',settings)
    actors.set_selected_level_actors([]);assert levels.save_current_level()
    return path

try:
    unreal.SystemLibrary.execute_console_command(unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world(),'r.DumpShaderDebugInfo 1')
    records=[]
    for name,precision,offset in [('Full',unreal.MaterialFloatPrecisionMode.MFPM_FULL,4096),('Half',unreal.MaterialFloatPrecisionMode.MFPM_HALF,4096),('Local',unreal.MaterialFloatPrecisionMode.MFPM_HALF,0)]:
        mat=material(name,precision,offset)
        records.append({'variant':name,'material':mat.get_path_name(),'precision':str(mat.get_editor_property('float_precision_mode')),'offset':offset,'tile_count':32,'map':scene(name,mat)})
    assets.save_directory('/Game/Precision',only_if_is_dirty=True,recursive=True)
    (root/'Saved/Experiments/precision-build.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    unreal.log('PRECISION_BUILD_OK')
finally:unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
