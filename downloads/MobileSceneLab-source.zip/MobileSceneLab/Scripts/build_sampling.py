"""Three texture lookups versus one RGB lookup with the same UV and filtering."""
import json
from pathlib import Path
import unreal

root=Path(unreal.Paths.project_dir())
assets=unreal.EditorAssetLibrary
ml=unreal.MaterialEditingLibrary
tools=unreal.AssetToolsHelpers.get_asset_tools()
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)

def texture(name):
    task=unreal.AssetImportTask()
    for k,v in dict(filename=str(root/'ContentSource/Sampling'/f'{name}.png'),destination_path='/Game/Sampling',destination_name='T_'+name,automated=True,replace_existing=True,save=True).items():task.set_editor_property(k,v)
    tools.import_asset_tasks([task])
    tex=assets.load_asset('/Game/Sampling/T_'+name)
    tex.set_editor_property('srgb',False)
    # Both paths use BGRA8. Compression quality is a separate experiment.
    tex.set_editor_property('compression_settings',unreal.TextureCompressionSettings.TC_VECTOR_DISPLACEMENTMAP)
    tex.set_editor_property('never_stream',True)
    assets.save_loaded_asset(tex)
    return tex

def material(name,textures):
    path='/Game/Sampling/M_'+name
    mat=assets.load_asset(path) if assets.does_asset_exist(path) else tools.create_asset('M_'+name,'/Game/Sampling',unreal.Material,unreal.MaterialFactoryNew())
    mat.set_editor_property('shading_model',unreal.MaterialShadingModel.MSM_UNLIT)
    mat.set_editor_property('two_sided',True)
    ml.delete_all_material_expressions(mat)
    uv=ml.create_material_expression(mat,unreal.MaterialExpressionTextureCoordinate)
    uv.set_editor_property('u_tiling',8.)
    uv.set_editor_property('v_tiling',8.)
    samples=[]
    for tex in textures:
        n=ml.create_material_expression(mat,unreal.MaterialExpressionTextureSample)
        n.set_editor_property('texture',tex)
        n.set_editor_property('sampler_type',unreal.MaterialSamplerType.SAMPLERTYPE_LINEAR_COLOR)
        assert ml.connect_material_expressions(uv,'',n,ml.get_material_expression_input_names(n)[0])
        samples.append(n)
    if len(samples)==1:output=samples[0];pin='RGB'
    else:
        ab=ml.create_material_expression(mat,unreal.MaterialExpressionAppendVector)
        output=ml.create_material_expression(mat,unreal.MaterialExpressionAppendVector)
        assert ml.connect_material_expressions(samples[0],'R',ab,'A')
        assert ml.connect_material_expressions(samples[1],'R',ab,'B')
        assert ml.connect_material_expressions(ab,'',output,'A')
        assert ml.connect_material_expressions(samples[2],'R',output,'B')
        pin=''
    assert ml.connect_material_property(output,pin,unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    ml.layout_material_expressions(mat);ml.recompile_material(mat);assets.save_loaded_asset(mat)
    return mat

def scene(name,mat):
    path='/Game/Sampling/L_Sampling_'+name
    if assets.does_asset_exist(path):
        levels.load_level(path)
        for actor in actors.get_all_level_actors():
            if actor.get_class().get_name() not in ['WorldSettings','LevelScriptActor','Brush','DefaultPhysicsVolume']:actors.destroy_actor(actor)
    else:assert levels.new_level(path)
    plane=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector())
    plane.static_mesh_component.set_static_mesh(assets.load_asset('/Engine/BasicShapes/Plane'))
    plane.static_mesh_component.set_material(0,mat)
    plane.set_actor_scale3d(unreal.Vector(6.75,12,1))
    actors.spawn_actor_from_class(unreal.PlayerStart,unreal.Vector(0,0,-5000))
    camera=actors.spawn_actor_from_class(unreal.CameraActor,unreal.Vector(0,0,1200),unreal.Rotator(pitch=-90,yaw=0,roll=0))
    camera.camera_component.set_editor_property('projection_mode',unreal.CameraProjectionMode.ORTHOGRAPHIC)
    camera.camera_component.set_editor_property('ortho_width',1200.)
    camera.set_editor_property('auto_activate_for_player',unreal.AutoReceiveInput.PLAYER0)
    post=actors.spawn_actor_from_class(unreal.PostProcessVolume,unreal.Vector())
    post.set_editor_property('unbound',True)
    settings=unreal.PostProcessSettings()
    for k,v in [('override_auto_exposure_method',True),('auto_exposure_method',unreal.AutoExposureMethod.AEM_MANUAL),('override_auto_exposure_apply_physical_camera_exposure',True),('auto_exposure_apply_physical_camera_exposure',False),('override_auto_exposure_bias',True),('auto_exposure_bias',0.),('override_vignette_intensity',True),('vignette_intensity',0.)]:settings.set_editor_property(k,v)
    post.set_editor_property('settings',settings)
    actors.set_selected_level_actors([]);assert levels.save_current_level()
    return path

try:
    textures={n:texture(n) for n in ['A','B','C','Packed']}
    records=[]
    for name,inputs in [('Separate',[textures[n] for n in ['A','B','C']]),('Packed',[textures['Packed']])]:
        mat=material(name,inputs)
        records.append(dict(variant=name,map=scene(name,mat),texture_sample_nodes=len(inputs),texture_size=[1024,1024],srgb=False,compression='TC_VECTOR_DISPLACEMENTMAP',note='Editor material graph counts; GPU instruction counts require compiled shader inspection.'))
    assets.save_directory('/Game/Sampling',only_if_is_dirty=True,recursive=True)
    (root/'Saved/Experiments/sampling-build.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    unreal.log('SAMPLING_BUILD_OK')
finally:unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
