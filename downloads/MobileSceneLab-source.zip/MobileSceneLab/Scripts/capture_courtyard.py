import unreal
import json
import time
import traceback
from pathlib import Path

root=Path(unreal.Paths.project_dir())
output=root/'Saved/Experiments'/('capture-'+time.strftime('%Y%m%d-%H%M%S'))
output.mkdir(parents=True,exist_ok=True)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
key=unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
variants=['Individual','Instanced']
state={'index':0,'ticks':0,'handle':None}
manifest={'platform':'Windows UE 5.8 editor / D3D12 SM5; desktop scene verification','resolution':[1600,900],'captures':[]}

def prepare():
    variant=variants[state['index']]
    if not levels.load_level('/Game/Lab/L_Courtyard_'+variant):raise RuntimeError('Cannot load '+variant)
    camera=next(a for a in actors.get_all_level_actors() if a.get_actor_label()=='固定对照相机')
    levels.set_level_viewport_camera_info(camera.get_actor_location(),camera.get_actor_rotation(),key)
    levels.set_level_viewport_fov(58.0,key)
    levels.editor_set_game_view(True,key)
    actors.set_selected_level_actors([])
    world=unreal.EditorLevelLibrary.get_editor_world()
    for command in ['ShowFlag.Grid 0','ShowFlag.Selection 0','r.VSync 0','t.MaxFPS 60','r.ScreenPercentage 100','r.SetRes 1600x900w']:
        unreal.SystemLibrary.execute_console_command(world,command)
    state['ticks']=0

def finish():
    (output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (root/'Saved/Experiments/latest-capture.txt').write_text(str(output),encoding='utf-8')
    if state['handle']:unreal.unregister_slate_post_tick_callback(state['handle'])
    unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')

def tick(dt):
    try:
        state['ticks']+=1
        if state['ticks']==240:
            variant=variants[state['index']]
            path=output/(variant+'.png')
            unreal.SystemLibrary.execute_console_command(unreal.EditorLevelLibrary.get_editor_world(),'HighResShot 1600x900 filename="'+path.as_posix()+'"')
            manifest['captures'].append({'variant':variant,'file':path.name,'warmup_ticks':240})
        if state['ticks']==320:
            state['index']+=1
            if state['index']==len(variants):finish()
            else:prepare()
    except Exception:
        manifest['error']=traceback.format_exc()
        unreal.log_error(manifest['error'])
        finish()

prepare()
unreal.EditorPythonScripting.set_keep_python_script_alive(True)
state['handle']=unreal.register_slate_post_tick_callback(tick)
