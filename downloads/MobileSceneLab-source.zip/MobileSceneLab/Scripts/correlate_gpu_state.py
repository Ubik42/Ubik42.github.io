"""Align coarse device telemetry to estimated CSV measurement windows."""
import argparse
import csv
import datetime as dt
import json
import re
import statistics
from pathlib import Path
csv.field_size_limit(16*1024*1024)

parser = argparse.ArgumentParser()
parser.add_argument('summary', type=Path)
parser.add_argument('telemetry', type=Path)
args = parser.parse_args()
data = json.loads(args.summary.read_text(encoding='utf-8'))
samples = []
with args.telemetry.open(encoding='utf-8-sig', newline='') as stream:
    for raw in csv.DictReader(stream, skipinitialspace=True):
        timestamp = dt.datetime.strptime(raw['timestamp'], '%Y/%m/%d %H:%M:%S.%f').astimezone(dt.timezone.utc)
        samples.append({'time': timestamp, 'clock': float(raw['clocks.current.graphics [MHz]'].split()[0]),
                        'pstate': raw['pstate'], 'utilization': float(raw['utilization.gpu [%]'].split()[0])})
rows = []
for run in data['runs']:
    folder = Path(run['directory'])
    config = json.loads((folder / 'run.json').read_text(encoding='utf-8-sig'))
    anchor_frame = config.get('capture_frames', 900) - 50
    sample_start, sample_end = run['sample_rows']
    log = (folder / 'runtime.log').read_text(encoding='utf-8', errors='replace')
    match = re.search(r'\[(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}:\d+)\].*CSVEvent .*HighResShot.*\[Frame '+str(anchor_frame)+r'\]', log)
    if not match:
        raise ValueError('Missing screenshot time anchor: ' + str(folder))
    anchor = dt.datetime.strptime(match[1], '%Y.%m.%d-%H.%M.%S:%f').replace(tzinfo=dt.timezone.utc)
    with (folder / 'profile.csv').open(encoding='utf-8-sig', newline='') as stream:
        frames = list(csv.DictReader(stream))
    start = anchor - dt.timedelta(milliseconds=sum(float(r['FrameTime']) for r in frames[sample_start:anchor_frame]))
    end = anchor - dt.timedelta(milliseconds=sum(float(r['FrameTime']) for r in frames[sample_end:anchor_frame]))
    selected = [s for s in samples if start-dt.timedelta(seconds=.5) <= s['time'] <= end+dt.timedelta(seconds=.5)]
    rows.append({'batch': folder.name, 'profile': run['shadow_profile'], 'gpu_p50_ms': run['metrics']['GPUTime']['p50'],
                 'estimated_start_utc': start.isoformat(), 'estimated_end_utc': end.isoformat(),
                 'telemetry_samples': len(selected), 'clock_mhz': [s['clock'] for s in selected],
                 'pstates': [s['pstate'] for s in selected], 'utilization_percent': [s['utilization'] for s in selected]})
result = {'scope': 'Estimated from screenshot-command log anchor and CPU FrameTime sums, padded +/-500 ms. Coarse device-wide samples; no per-frame clock or process attribution.', 'runs': rows}
output = args.summary.with_name(args.summary.stem + '-gpu-state.json')
output.write_text(json.dumps(result, indent=2), encoding='utf-8')
for row in rows:
    print(row['profile'], round(row['gpu_p50_ms'],4), row['clock_mhz'], row['pstates'])
