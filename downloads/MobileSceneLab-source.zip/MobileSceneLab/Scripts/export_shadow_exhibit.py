import argparse,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('result_directory',type=Path);args=p.parse_args()
source=args.result_directory.resolve();out=root/'Exhibit';(out/'media').mkdir(parents=True,exist_ok=True)
for name in ['reference.png','budget.png','reference-detail.png','budget-detail.png','difference-x4.png']:
    shutil.copy2(source/name,out/'media'/name)
data=json.loads((source/'result.json').read_text(encoding='utf-8'))
data['source']=source.name
(out/'data.js').write_text('window.result='+json.dumps(data,ensure_ascii=False)+';',encoding='utf-8')
print(out/'index.html')
