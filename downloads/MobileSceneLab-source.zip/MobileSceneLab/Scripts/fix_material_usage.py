import unreal
for name in ['M_Bark','M_Leaves']:
    mat=unreal.EditorAssetLibrary.load_asset('/Game/Showcase/Materials/'+name)
    unreal.MaterialEditingLibrary.set_material_usage(mat,unreal.MaterialUsage.MATUSAGE_INSTANCED_STATIC_MESHES)
    unreal.MaterialEditingLibrary.recompile_material(mat)
    unreal.EditorAssetLibrary.save_loaded_asset(mat)
