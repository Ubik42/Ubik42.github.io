"""Record GPU state around a child benchmark; no device or power settings changed."""
import argparse
import datetime
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    parser.error('A benchmark command is required after --')
args.output.mkdir(parents=True, exist_ok=True)
query = ['nvidia-smi', '--query-gpu=timestamp,index,pstate,clocks.current.graphics,clocks.current.memory,utilization.gpu,power.draw,temperature.gpu', '--format=csv', '--loop-ms=500']
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (args.output / 'gpu-state.csv').open('w', encoding='utf-8') as stream, (args.output / 'gpu-state-errors.txt').open('w', encoding='utf-8') as errors:
    monitor = subprocess.Popen(query, stdout=stream, stderr=errors, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        benchmark = subprocess.run(command, check=False)
    finally:
        monitor.terminate()
        monitor.wait(timeout=10)
record = {'start_utc': start, 'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code': benchmark.returncode, 'command': command,
          'scope': 'Device-wide state sampled every 500 ms; does not attribute utilization to a process or measure mobile hardware.'}
(args.output / 'telemetry-run.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
raise SystemExit(benchmark.returncode)
