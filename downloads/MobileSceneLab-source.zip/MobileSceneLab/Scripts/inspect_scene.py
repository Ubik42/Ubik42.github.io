import unreal,json
from pathlib import Path
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
records=[]
for name in ['Individual','Instanced']:
    levels.load_level('/Game/Lab/L_Courtyard_'+name)
    found=[]
    for a in actors.get_all_level_actors():
        if isinstance(a,(unreal.CameraActor,unreal.DirectionalLight,unreal.PostProcessVolume)):
            found.append({'type':a.get_class().get_name(),'location':str(a.get_actor_location()),'rotation':str(a.get_actor_rotation()),'scale':str(a.get_actor_scale3d())})
    records.append({'map':name,'actors':len(actors.get_all_level_actors()),'controls':found})
(Path(unreal.Paths.project_dir())/'Saved/Experiments/scene-state.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
