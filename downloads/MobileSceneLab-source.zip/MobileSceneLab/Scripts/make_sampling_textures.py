"""Original periodic masks, identical source bytes in separate and packed form."""
from pathlib import Path
import math
from PIL import Image

out=Path(__file__).resolve().parents[1]/'ContentSource/Sampling'
out.mkdir(parents=True,exist_ok=True)
size=1024
channels=[bytearray(size*size) for _ in range(3)]
for y in range(size):
    for x in range(size):
        u,v=x/size,y/size
        values=(.5+.45*math.sin(2*math.pi*(8*u+2*v)),
                .5+.45*math.cos(2*math.pi*6*v),
                .5+.45*math.sin(2*math.pi*4*u)*math.cos(2*math.pi*4*v))
        for c,value in zip(channels,values):c[y*size+x]=round(value*255)
images=[Image.frombytes('L',(size,size),bytes(c)) for c in channels]
for name,img in zip(('A','B','C'),images):Image.merge('RGB',(img,img,img)).save(out/(name+'.png'))
Image.merge('RGB',images).save(out/'Packed.png')
print(out)
