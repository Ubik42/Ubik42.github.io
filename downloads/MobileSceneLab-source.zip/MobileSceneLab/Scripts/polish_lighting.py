import unreal
from pathlib import Path
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
for variant in ['Individual','Instanced']:
    levels.load_level('/Game/Lab/L_Courtyard_'+variant)
    for actor in actors.get_all_level_actors():
        if isinstance(actor,unreal.DirectionalLight):actor.set_actor_rotation(unreal.Rotator(pitch=-32,yaw=145,roll=0),False)
        if isinstance(actor,unreal.SkyLight):actor.light_component.set_editor_property('intensity',1.2)
        if isinstance(actor,unreal.CameraActor):
            position=unreal.Vector(650,-2600,1000)
            actor.set_actor_location(position,False,False)
            actor.set_actor_rotation(unreal.MathLibrary.find_look_at_rotation(position,unreal.Vector(0,350,270)),False)
    levels.save_current_level()
exec((Path(unreal.Paths.project_dir())/'Scripts/capture_courtyard.py').read_text(encoding='utf-8'))
