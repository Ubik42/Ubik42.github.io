"""Matching ES3.1 editor camera paths. Captures are offline, not frame-time samples."""
import json,math,time,traceback,unreal
from pathlib import Path
root=Path(unreal.Paths.project_dir());out=root/'Saved/Experiments'/('shadow-camera-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir(parents=True)
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
key=unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
profiles=[('FullRange',2048,4,1.0),('CourtyardBudget',1024,2,.3)]
state={'profile':0,'frame':0,'ticks':0,'waiting':False,'handle':None,'last':time.monotonic()}
manifest={'platform':'Windows RTX4080 D3D11 ES3_1 editor viewport','offline':True,'fps':20,'frames_per_profile':120,'resolution':[960,540],'captures':[]}
assert levels.load_level('/Game/Lab/L_Courtyard_MobileInstanced')
world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
levels.set_level_viewport_fov(58,key);levels.editor_set_game_view(True,key);actors.set_selected_level_actors([])
def command(text):unreal.SystemLibrary.execute_console_command(world,text)
for cmd in ['ShowFlag.Grid 0','ShowFlag.Selection 0','r.VSync 0','t.MaxFPS 60','r.ScreenPercentage 100']:command(cmd)
def pose():
    phase=state['frame']/119*math.pi*2
    pos=unreal.Vector(650+1250*math.sin(phase),-2600+450*math.sin(phase),1000+120*math.sin(phase))
    rot=unreal.MathLibrary.find_look_at_rotation(pos,unreal.Vector(0,350,270))
    levels.set_level_viewport_camera_info(pos,rot,key)
def prepare():
    name,res,cascades,scale=profiles[state['profile']];(out/name).mkdir(exist_ok=True)
    for cmd in [f'r.Shadow.MaxCSMResolution {res}',f'r.Shadow.CSM.MaxCascades {cascades}',f'r.Shadow.DistanceScale {scale}']:command(cmd)
    state.update(frame=0,ticks=-120,waiting=False,last=time.monotonic());pose()
def finish(error=None):
    if error:manifest['error']=error
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (root/'Saved/Experiments/latest-shadow-camera.txt').write_text(str(out),encoding='utf-8')
    if state['handle']:unreal.unregister_slate_post_tick_callback(state['handle'])
    unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
def tick(dt):
    try:
        state['ticks']+=1
        name=profiles[state['profile']][0];path=out/name/f"frame-{state['frame']:05d}.png"
        if state['waiting']:
            if path.exists() and state['ticks']>=3:
                manifest['captures'].append({'profile':name,'frame':state['frame'],'file':str(path.relative_to(out))})
                state['frame']+=1;state.update(waiting=False,ticks=0,last=time.monotonic())
                if state['frame']==120:
                    state['profile']+=1
                    if state['profile']==len(profiles):finish();return
                    prepare()
                else:pose()
            elif time.monotonic()-state['last']>60:raise RuntimeError('Screenshot did not arrive: '+str(path))
        elif state['ticks']>=6:
            command('HighResShot 960x540 filename="'+path.as_posix()+'"')
            state.update(waiting=True,ticks=0,last=time.monotonic())
    except Exception:finish(traceback.format_exc())
prepare();unreal.EditorPythonScripting.set_keep_python_script_alive(True)
state['handle']=unreal.register_slate_post_tick_callback(tick)
