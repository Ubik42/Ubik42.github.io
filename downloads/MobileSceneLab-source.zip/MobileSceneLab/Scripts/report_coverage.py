import argparse,json,statistics,shutil
from pathlib import Path
from PIL import Image,ImageChops,ImageStat
from resolution_metadata import read_resolution

p=argparse.ArgumentParser();p.add_argument('summary',type=Path);p.add_argument('--prefix',default='coverage');a=p.parse_args()
data=json.loads(a.summary.read_text(encoding='utf-8'))
root=Path(__file__).resolve().parents[1]
dimensions=sorted(set(tuple(read_resolution(Path(r['directory'])/'profile.csv')) for r in data['runs']))
result={'batch':a.summary.name,'groups':{},'runtime_resolutions':dimensions,'measurement':'D3D11 ES3.1 desktop GPU; runtime size from CSV metadata, screenshots may differ; CSV rows 3500..5499'}
images={}
for variant in ['Quad','Trimmed']:
    runs=[r for r in data['runs'] if r['map'].endswith('_'+variant)]
    if len(runs)!=3:raise ValueError('Expected three complete runs for '+variant)
    keys=[k for k in runs[0]['metrics'] if k.startswith('GPU/') or k in ['GPUTime','RHI/DrawCalls','RenderThreadTime']]
    result['groups'][variant]={k:{'batch_p50':[r['metrics'][k]['p50'] for r in runs],'median':statistics.median(r['metrics'][k]['p50'] for r in runs)} for k in keys}
    images[variant]=Image.open(Path(runs[0]['directory'])/'runtime.png').convert('RGB')
out=a.summary.parent/a.summary.stem;out.mkdir(exist_ok=True)
for variant,image in images.items():image.save(out/(variant+'.png'))
diff=ImageChops.difference(images['Quad'],images['Trimmed'])
result['image_error_8bit']={'mean':ImageStat.Stat(diff).mean,'max':[x[1] for x in diff.getextrema()]}
diff.point(lambda x:min(255,x*8)).save(out/'difference-x8.png')
result['geometry']=json.loads((root/'Saved/Experiments/coverage-build.json').read_text(encoding='utf-8'))
result['geometry'].pop('transforms')
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
exhibit=root/'Exhibit'
(exhibit/(a.prefix+'-data.js')).write_text('window.'+('coverage' if a.prefix=='coverage' else 'coverageHigh')+'='+json.dumps(result,ensure_ascii=False)+';',encoding='utf-8')
for variant in ['Quad','Trimmed']:shutil.copy2(out/(variant+'.png'),exhibit/'media'/(a.prefix+'-'+variant+'.png'))
shutil.copy2(out/'difference-x8.png',exhibit/'media'/(a.prefix+'-difference.png'))
print(json.dumps(result,ensure_ascii=False,indent=2))
