"""Separate real UE captures from a binary16 arithmetic reference model."""
import argparse,hashlib,json,shutil,struct
from pathlib import Path
from PIL import Image,ImageChops,ImageStat

p=argparse.ArgumentParser();p.add_argument('batch');args=p.parse_args()
root=Path(__file__).resolve().parents[1]
out=root/'Exhibit';media=out/'media';media.mkdir(parents=True,exist_ok=True)
records={};images={}
for name in ['Full','Half','Local']:
    candidates=list((root/'Saved/Experiments').glob('runtime-'+args.batch+'-'+name+'-Instanced-*'))
    if len(candidates)!=1:raise RuntimeError(f'Expected one run for {name}, found {len(candidates)}')
    folder=candidates[0]
    record=json.loads((folder/'run.json').read_text(encoding='utf-8-sig'))
    resolution=json.loads((folder/'resolution-check.json').read_text())
    records[name]={'renderer':record['renderer'],'map':record['map'],'resolution':resolution,
        'image_sha256':hashlib.sha256((folder/'runtime.png').read_bytes()).hexdigest()}
    images[name]=Image.open(folder/'runtime.png').convert('RGB')
    images[name].save(media/f'precision-{name}.png')
errors={}
for name in ['Half','Local']:
    diff=ImageChops.difference(images['Full'],images[name])
    errors[name]={'mean':ImageStat.Stat(diff).mean,'max':[v[1] for v in diff.getextrema()]}
    diff.point(lambda p:min(255,p*16)).save(media/f'precision-{name}-difference.png')
f16=lambda value:struct.unpack('e',struct.pack('e',value))[0]
numeric=[]
for base in [0,32,256,4096]:
    value=base+.375;rounded=f16(value)
    numeric.append({'integer_origin':base,'input_fraction':.375,'binary16_value':rounded,'fraction_after_rounding':rounded-int(rounded)})
data={'batch':args.batch,'captures':records,'image_error_vs_full_8bit':errors,
    'binary16_reference':numeric,'reference_scope':'Python struct IEEE-754 binary16 rounding model; not a UE GPU capture',
    'scope':'D3D11 ES3.1 desktop mobile preview; images do not establish native FP16 execution or performance'}
(out/'precision-data.js').write_text('window.precisionCase='+json.dumps(data,ensure_ascii=False)+';\n',encoding='utf-8')
evidence=root/'Evidence/Precision';evidence.mkdir(parents=True,exist_ok=True)
(evidence/'summary.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(root/'Saved/Experiments/precision-build.json',evidence/'materials.json')
print(json.dumps(data,ensure_ascii=False,indent=2))
