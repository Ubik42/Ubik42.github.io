import argparse,json,statistics,shutil
from pathlib import Path
from PIL import Image,ImageChops,ImageStat

p=argparse.ArgumentParser();p.add_argument('summary',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
data=json.loads(a.summary.read_text(encoding='utf-8'))
result={'batch':a.summary.stem,'groups':{},'conditions':{'api':'Windows RTX4080 D3D11 ES3.1','sample_rows':[3500,5500],'order':['Separate','Packed','Packed','Separate','Separate','Packed']}}
evidence=root/'Evidence/Sampling';evidence.mkdir(parents=True,exist_ok=True)
images={}
for variant in ['Separate','Packed']:
    runs=[r for r in data['runs'] if r['map'].endswith('_'+variant)]
    assert len(runs)==3
    for i,r in enumerate(runs):
        assert r['runtime_resolution']==r['image_size']==[3840,2160]
        shutil.copy2(Path(r['directory'])/'profile.csv',evidence/f'{variant}-{i+1}.csv')
    result['groups'][variant]={k:{'p50':[r['metrics'][k]['p50'] for r in runs],'median':statistics.median(r['metrics'][k]['p50'] for r in runs)} for k in ['GPUTime','GPU/Basepass','RenderThreadTime','RHI/DrawCalls']}
    images[variant]=Image.open(Path(runs[0]['directory'])/'runtime.png').convert('RGB')
    repeat=[]
    for r in runs[1:]:
        d=ImageChops.difference(images[variant],Image.open(Path(r['directory'])/'runtime.png').convert('RGB'))
        repeat.append({'mean':ImageStat.Stat(d).mean,'max':[x[1] for x in d.getextrema()]})
    result['groups'][variant]['repeat_image_error']=repeat
    images[variant].save(root/'Exhibit/media'/f'sampling-{variant}.png')
diff=ImageChops.difference(images['Separate'],images['Packed'])
result['image_error_8bit']={'mean':ImageStat.Stat(diff).mean,'max':[x[1] for x in diff.getextrema()]}
diff.point(lambda v:min(v*16,255)).save(root/'Exhibit/media/sampling-difference.png')
result['build']=json.loads((root/'Saved/Experiments/sampling-build.json').read_text(encoding='utf-8'))
(evidence/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(a.summary,evidence/'runs.json')
(root/'Exhibit/sampling-data.js').write_text('window.samplingCase='+json.dumps(result,ensure_ascii=False)+';',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
