"""Report isolated shadow settings; retain all batch medians and their spread."""
import argparse
import json
import statistics
import shutil
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('summary', type=Path)
args = parser.parse_args()
data = json.loads(args.summary.read_text(encoding='utf-8'))
profiles = ['FullRange', 'DistanceOnly', 'ResolutionOnly', 'CascadesOnly']
keys = ['GPUTime', 'GPU/ShadowDepths', 'GPU/ShadowProjection', 'DrawCall/ShadowDepths']
report = {}
for profile in profiles:
    runs = [r for r in data['runs'] if r['shadow_profile'] == profile]
    if len(runs) != 3:
        raise ValueError(f'{profile}: expected three complete runs, got {len(runs)}')
    report[profile] = {}
    for key in keys:
        values = [r['metrics'][key]['p50'] for r in runs]
        report[profile][key] = {'median': statistics.median(values), 'batch_p50': values,
                               'min': min(values), 'max': max(values)}
out = args.summary.with_name(args.summary.stem + '-ablation.json')
out.write_text(json.dumps({'source': args.summary.name, 'profiles': report}, indent=2), encoding='utf-8')
lines = ['# 阴影参数单变量实验', '',
         'Windows / RTX 4080 / D3D11 ES3.1；历史批次 CSV 系统分辨率 888×500、独立截图 1600×900。每配置三次独立运行，每次统计第 300–779 帧。', '',
         'FullRange 为 400 m、2048、4 级联；其余分别只改距离到 120 m、分辨率到 1024、级联上限到 2。', '',
         '| 配置 | GPU ms | ShadowDepths ms | ShadowProjection ms | 阴影 Draw |',
         '| --- | ---: | ---: | ---: | ---: |']
for profile in profiles:
    lines.append('| ' + profile + ' | ' + ' | '.join(f'{report[profile][k]["median"]:.5f}' for k in keys) + ' |')
lines += ['', '表中为三次批次 P50 的中位数。逐批数值与范围保存在同名 JSON；较小差异需结合批次波动解释。',
          '画质检查使用各运行目录的 runtime.png；此表仅记录时间和绘制计数，不判断画质等价。']
out.with_suffix('.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
exhibit = Path(__file__).resolve().parents[1] / 'Exhibit'
(exhibit / 'ablation.js').write_text('window.ablation=' + json.dumps(report) + ';', encoding='utf-8')
for profile in profiles:
    run = next(r for r in data['runs'] if r['shadow_profile'] == profile)
    shutil.copy2(Path(run['directory']) / 'runtime.png', exhibit / 'media' / (profile + '.png'))
print('\n'.join(lines))
