import argparse,json,statistics
from pathlib import Path
from PIL import Image,ImageChops,ImageStat
p=argparse.ArgumentParser();p.add_argument('summary',type=Path);args=p.parse_args()
data=json.loads(args.summary.read_text(encoding='utf-8'))
out=args.summary.parent/args.summary.stem;out.mkdir(exist_ok=True)
profiles=['FullRange','CourtyardBudget'];keys=['GPUTime','GPU/ShadowDepths','GPU/ShadowProjection','GPU/Basepass','RHI/DrawCalls','DrawCall/ShadowDepths','RenderTargetPoolUsed']
stats={profile:{key:statistics.median(r['metrics'][key]['p50'] for r in data['runs'] if r['shadow_profile']==profile) for key in keys} for profile in profiles}
images=[]
for profile,name in zip(profiles,['reference','budget']):
    run=next(r for r in data['runs'] if r['shadow_profile']==profile)
    image=Image.open(Path(run['directory'])/'runtime.png').convert('RGB');image.save(out/(name+'.png'));images.append(image)
    image.crop((780,410,1450,840)).resize((1005,645)).save(out/(name+'-detail.png'))
diff=ImageChops.difference(*images);diff.point(lambda v:min(255,v*4)).save(out/'difference-x4.png')
stats['image_error_8bit']={'mean':ImageStat.Stat(diff).mean,'max':[v[1] for v in diff.getextrema()]}
stats['source']=str(args.summary)
(out/'result.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(stats,ensure_ascii=False,indent=2))
