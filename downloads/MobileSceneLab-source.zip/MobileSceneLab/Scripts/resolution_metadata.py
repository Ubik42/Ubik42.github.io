import csv,json,sys
from pathlib import Path
from PIL import Image

def read_resolution(path):
    with Path(path).open('rb') as stream:
        stream.seek(0,2);stream.seek(max(0,stream.tell()-100000))
        line=stream.read().decode('utf-8-sig').splitlines()[-1]
    row=next(csv.reader([line]))
    result=[]
    for key in ['[systemresolution.resx]','[systemresolution.resy]']:
        index=row.index(key);result.append(int(row[index+1]))
    return result

if __name__=='__main__':
    root=Path(sys.argv[1]);run=json.loads((root/'run.json').read_text(encoding='utf-8-sig'))
    measured=read_resolution(root/'profile.csv');image=list(Image.open(root/'runtime.png').size)
    report={'requested':run.get('requested_resolution'),'csv_system_resolution':measured,'screenshot_size':image}
    (root/'resolution-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(report)
    assert report['requested']==measured==image, 'Requested, runtime and screenshot resolutions differ'
