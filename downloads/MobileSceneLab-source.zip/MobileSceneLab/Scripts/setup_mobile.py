"""Create separate mobile maps; leave the measured desktop maps intact."""
import unreal
assets=unreal.EditorAssetLibrary
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
cube=assets.load_asset('/Engine/EngineResources/DefaultTextureCube')
assert isinstance(cube,unreal.TextureCube), 'Expected an engine environment cubemap'
for variant in ['Individual','Instanced']:
    assert levels.load_level('/Game/Lab/L_Courtyard_'+variant)
    for actor in actors.get_all_level_actors():
        if isinstance(actor,unreal.SkyLight):
            component=actor.light_component
            component.set_editor_property('real_time_capture',False)
            component.set_editor_property('source_type',unreal.SkyLightSourceType.SLS_SPECIFIED_CUBEMAP)
            component.set_editor_property('cubemap',cube)
            component.set_editor_property('intensity',1.5)
            component.recapture_sky()
    world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    assert unreal.EditorLoadingAndSavingUtils.save_map(world,'/Game/Lab/L_Courtyard_Mobile'+variant)
unreal.log('MOBILE_ENVIRONMENT_MAPS_OK')
unreal.SystemLibrary.execute_console_command(None,'QUIT_EDITOR')
