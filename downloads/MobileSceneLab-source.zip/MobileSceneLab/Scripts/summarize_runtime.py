import argparse,csv,json,statistics
from pathlib import Path
from PIL import Image,ImageStat
csv.field_size_limit(16*1024*1024)

parser=argparse.ArgumentParser()
parser.add_argument('runs',nargs='+',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
results=[]
metrics=['FrameTime','GameThreadTime','RenderThreadTime','GPUTime','RenderThreadTime_CriticalPath','RHI/DrawCalls','RHI/PrimitivesDrawn','DrawCall/Basepass','DrawCall/ShadowDepths','DrawCall/BeginOcclusionTests','GPUSceneInstanceCount']
for directory in args.runs:
    run=json.loads((directory/'run.json').read_text(encoding='utf-8-sig'))
    image=Image.open(directory/'runtime.png').convert('RGB')
    if max(ImageStat.Stat(image).mean)<1:raise RuntimeError('Black capture: '+str(directory))
    with (directory/'profile.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    interval=run.get('sample_rows',[300,780]);expected=interval[1]-interval[0]
    samples=rows[interval[0]:interval[1]]
    record={'directory':str(directory),'variant':run['variant'],'map':run.get('map'),'platform':run['platform'],'shadow_profile':run.get('shadowProfile','Default'),'sample_rows':interval,'image_size':list(image.size),'metrics':{}}
    optional_metrics=[key for key in ['GPU/ShadowDepths','GPU/ShadowProjection','GPU/Basepass','GPU/Translucency','GPU/TranslucencyStandard','RenderTargetPoolUsed'] if rows and key in rows[0]]
    for name in metrics+optional_metrics:
        values=[]
        for row in samples:
            try:values.append(float(row[name]))
            except (KeyError,TypeError,ValueError):pass
        if len(values)!=expected:raise RuntimeError(f'{name}: expected {expected} samples, got {len(values)}')
        record['metrics'][name]={'mean':statistics.mean(values),'p50':statistics.median(values),'p95':sorted(values)[int((len(values)-1)*.95)],'all_zero':not any(values)}
    results.append(record)
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps({'platforms':sorted(set(r['platform'] for r in results)),'measurement':'Each run records its sample_rows interval [start,end); screenshot after interval excluded','runs':results},ensure_ascii=False,indent=2),encoding='utf-8')
for r in results:print(r['variant'],{key:round(r['metrics'][key]['p50'],4)for key in ['FrameTime','RenderThreadTime','GPUTime','RHI/DrawCalls']})
