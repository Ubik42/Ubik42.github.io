"""Install and launch the packaged UE courtyard on an explicitly selected emulator."""
import argparse,hashlib,json,re,subprocess,time
from pathlib import Path
from datetime import datetime
p=argparse.ArgumentParser();p.add_argument('--serial',required=True);p.add_argument('--apk',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
sdk=Path(r'D:\3D\_tools\mini-effect-sdk\build\android-sdk')
adb=sdk/'platform-tools/adb.exe'
def call(*parts,binary=False):
    r=subprocess.run([str(adb),'-s',a.serial,*parts],capture_output=True,check=True,timeout=180)
    return r.stdout if binary else r.stdout.decode('utf-8',errors='replace').strip()
if call('shell','getprop','ro.kernel.qemu')!='1':raise RuntimeError('This check requires an emulator')
if call('shell','getprop','sys.boot_completed')!='1':raise RuntimeError('Emulator is still booting')
badging=subprocess.run([str(sdk/'build-tools/35.0.1/aapt.exe'),'dump','badging',str(a.apk)],capture_output=True,check=True).stdout.decode('utf-8',errors='replace')
package=re.search(r"package: name='([^']+)'",badging).group(1)
activity=re.search(r"launchable-activity: name='([^']+)'",badging).group(1)
if package!='io.ubik.mobilescenelab':raise RuntimeError('Unexpected package: '+package)
out=root/'Saved/Experiments'/('android-courtyard-'+datetime.now().strftime('%Y%m%d-%H%M%S'));out.mkdir(parents=True)
(out/'apk-badging.txt').write_text(badging,encoding='utf-8')
print(call('install','-r',str(a.apk)),flush=True)
call('shell','am','force-stop',package)
# Do not clear device-wide logcat; filter this launch using the process ID.
print(call('shell','am','start','-n',package+'/'+activity),flush=True)
deadline=time.monotonic()+90;pid='';logs=''
while time.monotonic()<deadline:
    probe=subprocess.run([str(adb),'-s',a.serial,'shell','pidof',package],capture_output=True,text=True)
    pid=probe.stdout.strip()
    if pid:
        logs=call('logcat','-d','--pid='+pid)
        if 'Bringing World' in logs or 'Game Engine Initialized' in logs:break
    time.sleep(2)
if pid:time.sleep(5);logs=call('logcat','-d','--pid='+pid)
(out/'runtime-logcat.txt').write_text(logs,encoding='utf-8')
(out/'screen.png').write_bytes(call('exec-out','screencap','-p',binary=True))
record={'package':package,'activity':activity,'pid':pid,'apk_sha256':hashlib.sha256(a.apk.read_bytes()).hexdigest(),'apk_bytes':a.apk.stat().st_size,'model':call('shell','getprop','ro.product.model'),'android':call('shell','getprop','ro.build.version.release'),'engine_start_signal':bool(re.search('Bringing World|Game Engine Initialized',logs)),'android_map_loaded':'Bringing World /Game/Lab/L_Courtyard_Android.' in logs,'vulkan_es31':'Vulkan_ES31' in logs,'scope':'Android emulator launch and screenshot; visual inspection still required. Host GPU is not a phone GPU.'}
(out/'run.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2));print(out)
if not record['engine_start_signal']:raise RuntimeError('No engine start signal; inspect captured log and screenshot')

if not record['android_map_loaded'] or not record['vulkan_es31']:raise RuntimeError('Expected Android map or Vulkan ES31 path not found in log')
