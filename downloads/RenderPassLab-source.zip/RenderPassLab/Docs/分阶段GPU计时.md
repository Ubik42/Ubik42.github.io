# 分阶段 GPU 计时

原有整链测量使用首尾两个时间戳。新 `stages` 诊断模式在独立 Render Pass 末尾追加 GPU 时间戳，输出 `stages.csv`，将场景、雾、调色、Bloom 水平/垂直合成等区间分开。

```powershell
.\build\Release\renderpass-lab.exe bloom artifacts\stages-reference 1920 1080 180 90 stages
.\build\Release\renderpass-lab.exe bloom-separable artifacts\stages-separable 1920 1080 180 90 stages
python scripts/summarize-stages.py artifacts/stages-reference artifacts/stages-separable --output artifacts/stages-summary.json
```

当前拒绝对融合 Subpass 做区间拆分，避免把额外流水线阶段时间戳误解释为原本重叠工作的独立成本。每段包含相关过渡与同步；不是纯Shader指令执行时间。常规整链模式仍只写两个时间戳，现有六轮测量保持不变。

2026-10-31首轮诊断，RTX4080/1080p，各预热90帧、采样180帧：

| 区间P50 | 二维核 | 分离核 |
| --- | ---: | ---: |
| 场景 | 2.75016 ms | 2.88125 ms |
| 雾 | 0.017408 ms | 0.017408 ms |
| 调色 | 0.016384 ms | 0.016384 ms |
| Bloom二维核/合成 | 0.108544 ms | — |
| Bloom水平 | — | 0.018432 ms |
| Bloom垂直/合成 | — | 0.019456 ms |

局部Bloom减少了约0.07ms，但该轮分离路径的场景时间更高，整链P50为2.9116与2.958445ms。此诊断说明场景成本与运行波动会掩盖后处理局部收益，不支持替换既有六轮基准或宣称本轮整链加速。

逐帧区间之和与首尾总时间的最大CSV舍入差为0.000008ms，验证了索引和单位。不同区间P50相加不必等于整链P50，应在同一帧上先求和再统计。原始记录位于 `artifacts/stages-reference-20261031` 与 `artifacts/stages-separable-20261031`。
