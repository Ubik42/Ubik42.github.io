# 本地对照演示

直接打开 `index.html`，或在工程根目录运行：

```powershell
python -m http.server 8941 --bind 127.0.0.1 --directory exhibit
```

页面使用真实 Vulkan 离线截图与 CSV 统计，支持拖动画面分隔线、键盘滑块、二维核/分离核切换、32 倍绝对差分和逐轮 P50/P95。所有资源在本目录内，无远程依赖。

当前数据来自 `bloom-comparison-20261031-140010`。场景改用四子像素采样与更严格命中判断，整链 GPU 中位数为 3.02627→2.93016 ms；它替代旧单样本画面的展示数据。旧实验保持原记录。

重新导出：`python scripts/export-exhibit.py artifacts/<批次目录>`。

2026-10-31 已在浏览器核对桌面与 390px 窄屏、切换差分、滑块 75% 状态。实际截图见 `artifacts/exhibit-20261031/page.png`。页面尚未发布到个人网站；对外正文的 Gemini 3.8 润色请求返回 HTTP 402 RESOURCE_EXHAUSTED，待后续完成。
