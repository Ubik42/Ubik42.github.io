"""Same-kernel bloom comparison; desktop GPU timing, no capture layer."""
import csv, hashlib, json, shutil, statistics, subprocess
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

root=Path(__file__).resolve().parents[1]
out=root/'artifacts'/('bloom-comparison-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
out.mkdir(parents=True)
for directory in ['src','shaders']:
    shutil.copytree(root/directory,out/'source'/directory)
shutil.copy2(root/'CMakeLists.txt',out/'source/CMakeLists.txt')
shutil.copy2(__file__,out/'source/benchmark-bloom.py')
exe=root/'build/Release/renderpass-lab.exe'
runs=[]
for index,mode in enumerate(['bloom','bloom-separable','bloom-separable','bloom','bloom','bloom-separable']):
    directory=out/f'{index+1}-{mode}'
    subprocess.run([str(exe),mode,str(directory),'1920','1080','300','150'],check=True)
    run=json.loads((directory/'run.json').read_text())
    image=Image.open(directory/'frame.ppm');image.save(directory/'frame.png')
    with (directory/'frames.csv').open() as f:values=[float(r['gpu_ms']) for r in csv.DictReader(f)]
    run.update(directory=str(directory),p50=statistics.median(values),p95=sorted(values)[284])
    runs.append(run)
reference=Image.open(out/'1-bloom/frame.png')
candidate=Image.open(out/'2-bloom-separable/frame.png')
diff=ImageChops.difference(reference,candidate)
stat=ImageStat.Stat(diff)
diff.point(lambda p:min(p*32,255)).save(out/'difference-x32.png')
medians={mode:statistics.median(r['p50'] for r in runs if r['mode']==mode) for mode in ['bloom','bloom-separable']}
summary={'platform':'Windows RTX 4080; not mobile hardware','runs':runs,'median_batch_p50_ms':medians,
 'gpu_reduction_percent':100*(1-medians['bloom-separable']/medians['bloom']),
 'image_error_8bit':{'mean_per_channel':stat.mean,'max_per_channel':[x[1] for x in diff.getextrema()]},
 'tradeoff':'81+1 reads in one bloom pass versus 9+9+1 across two; extra RGBA16F full-resolution intermediate; intermediate quantization changes pixels',
 'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),
 'shader_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'build/shaders').glob('*.spv'))}}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='runs'},ensure_ascii=False,indent=2))
print(out)
