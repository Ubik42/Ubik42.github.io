"""Same bloom-separable chain, two HDR formats, interleaved timing and image comparison."""
import csv
import hashlib
import json
import statistics
import subprocess
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

root = Path(__file__).resolve().parents[1]
output = root / 'artifacts' / ('formats-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
output.mkdir(parents=True)
exe = root / 'build/Release/renderpass-lab.exe'
runs = []
for index, fmt in enumerate(['rgba32f', 'rgba16f', 'rgba16f', 'rgba32f', 'rgba32f', 'rgba16f']):
    directory = output / f'{index+1}-{fmt}'
    subprocess.run([str(exe), 'bloom-separable', str(directory), '1920', '1080', '300', '150', 'benchmark', fmt], check=True)
    record = json.loads((directory / 'run.json').read_text())
    with (directory / 'frames.csv').open(newline='') as stream:
        values = [float(row['gpu_ms']) for row in csv.DictReader(stream)]
    record.update(batch=directory.name, p50=statistics.median(values), p95=sorted(values)[int((len(values)-1)*.95)])
    runs.append(record)
images = {}
for fmt in ['rgba32f', 'rgba16f']:
    run = next(r for r in runs if r['hdr_format'] == fmt)
    images[fmt] = Image.open(output / run['batch'] / 'frame.ppm').convert('RGB')
    images[fmt].save(output / (fmt + '.png'))
diff = ImageChops.difference(images['rgba32f'], images['rgba16f'])
diff.point(lambda p: min(255, p*32)).save(output / 'difference-x32.png')
summary = {'scope': 'Desktop RTX GPU, complete offscreen chain; format is the only rendering change',
           'runs': runs, 'image_error_8bit': {'mean': ImageStat.Stat(diff).mean, 'max': [x[1] for x in diff.getextrema()]},
           'batch_p50_medians': {fmt: statistics.median(r['p50'] for r in runs if r['hdr_format'] == fmt) for fmt in images},
           'executable_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
           'shader_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'build/shaders').glob('*.spv')}}
(output / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(output)
print(json.dumps({k:summary[k] for k in ['image_error_8bit','batch_p50_medians']}, indent=2))
