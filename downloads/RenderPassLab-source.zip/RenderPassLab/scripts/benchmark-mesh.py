"""Same conventional vertex/depth scene through split and subpass paths."""
import csv, hashlib, json, statistics, subprocess
from datetime import datetime, timezone
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

root=Path(__file__).resolve().parents[1]
output=root/'artifacts'/('mesh-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
output.mkdir(parents=True)
exe=root/'build/Release/renderpass-lab.exe'
runs=[]
for index,mode in enumerate(['split','subpass','subpass','split','split','subpass']):
    directory=output/f'{index+1}-{mode}'
    started=datetime.now(timezone.utc).isoformat()
    subprocess.run([str(exe),mode,str(directory),'1920','1080','6000','6000','benchmark','rgba16f','mesh'],check=True)
    record=json.loads((directory/'run.json').read_text())
    with (directory/'frames.csv').open(newline='') as f: values=[float(row['gpu_ms']) for row in csv.DictReader(f)]
    record.update(batch=directory.name,p50=statistics.median(values),p95=sorted(values)[int((len(values)-1)*.95)],started_utc=started,finished_utc=datetime.now(timezone.utc).isoformat())
    runs.append(record)
images={}
for mode in ['split','subpass']:
    first=next(r for r in runs if r['mode']==mode)
    images[mode]=Image.open(output/first['batch']/'frame.ppm').convert('RGB')
    images[mode].save(output/(mode+'.png'))
diff=ImageChops.difference(images['split'],images['subpass'])
diff.point(lambda p:min(255,p*32)).save(output/'difference-x32.png')
repeat_errors=[]
for run in runs:
    repeat=ImageChops.difference(images[run['mode']],Image.open(output/run['batch']/'frame.ppm').convert('RGB'))
    repeat_errors.append({'batch':run['batch'],'max':[v[1] for v in repeat.getextrema()]})
summary={'scope':'Conventional triangle scene; complete offscreen GPU chain, Windows desktop GPU',
    'runs':runs,'repeat_image_errors':repeat_errors,
    'image_error_8bit':{'mean':ImageStat.Stat(diff).mean,'max':[v[1] for v in diff.getextrema()]},
    'batch_p50_medians':{mode:statistics.median(r['p50'] for r in runs if r['mode']==mode) for mode in images},
    'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),
    'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['src','shaders'] for p in (root/folder).glob('*') if p.is_file()}}
(output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(output)
print(json.dumps({k:summary[k] for k in ['image_error_8bit','batch_p50_medians','repeat_image_errors']},indent=2))
