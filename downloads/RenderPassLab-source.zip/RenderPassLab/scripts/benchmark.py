"""Run interleaved GPU batches, keep raw frames and compare decoded pixels."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import statistics
import subprocess
import shutil
from datetime import datetime, timezone
from pathlib import Path
from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parents[1]

def percentile(values: list[float], quantile: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    low = int(position)
    return ordered[low] + (ordered[min(low + 1, len(ordered) - 1)] - ordered[low]) * (position - low)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--width', type=int, default=1920)
    parser.add_argument('--height', type=int, default=1080)
    parser.add_argument('--samples', type=int, default=120)
    parser.add_argument('--warmup', type=int, default=40)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--include-inline', action='store_true')
    args = parser.parse_args()
    exe = ROOT / 'build/Release/renderpass-lab.exe'
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = args.output or ROOT / 'artifacts' / stamp
    output.mkdir(parents=True, exist_ok=False)
    # ABBAAB: three batches per mode, changing which mode runs first.
    sequence = ['split', 'subpass', 'subpass', 'split', 'split', 'subpass']
    if args.include_inline:
        sequence = ['split','subpass','inline','subpass','inline','split','inline','split','subpass']
    records = []
    reference = None
    for index, mode in enumerate(sequence):
        destination = output / f'{index + 1:02d}-{mode}'
        command = [str(exe), mode, str(destination), str(args.width), str(args.height), str(args.samples), str(args.warmup)]
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        print(result.stdout.strip(), flush=True)
        (destination / 'stdout.txt').write_text(result.stdout + result.stderr, encoding='utf-8')
        info = json.loads((destination / 'run.json').read_text(encoding='utf-8'))
        with (destination / 'frames.csv').open(newline='') as source:
            values = [float(row['gpu_ms']) for row in csv.DictReader(source)]
        info.update(batch=index + 1, p50_ms=statistics.median(values), p95_ms=percentile(values, .95), mean_ms=statistics.mean(values), command=command)
        picture = Image.open(destination / 'frame.ppm').convert('RGB')
        picture.save(destination / 'frame.png')
        if reference is None:
            reference = picture.copy()
        difference = ImageChops.difference(reference, picture)
        histogram = difference.histogram()
        info['max_channel_error_8bit'] = max(high for low, high in difference.getextrema())
        info['mean_absolute_channel_error_8bit'] = sum((i % 256) * count for i, count in enumerate(histogram)) / (picture.width * picture.height * 3)
        info['exact_pixels_match'] = difference.getbbox() is None
        records.append(info)
    medians = {mode: [r['p50_ms'] for r in records if r['mode'] == mode] for mode in dict.fromkeys(sequence)}
    result = {
        'created_utc': stamp,
        'sequence': sequence,
        'runs': records,
        'batch_medians_ms': medians,
        'median_of_batch_medians_ms': {mode: statistics.median(values) for mode, values in medians.items()},
        'all_images_equal': all(r['exact_pixels_match'] for r in records),
        'scope': 'GPU interval includes procedural scene and three post stages; excludes CPU, presentation, readback. Serialized queue submissions.',
        'architecture_limit': 'Windows RTX desktop results. No mobile GPU bandwidth, power or thermal measurements.',
        'logical_intermediate_store_bytes_split': args.width * args.height * 8 * 3,
        'logical_intermediate_store_bytes_subpass': 0,
        'logical_bytes_note': 'Attachment storeOp contract only. Does not measure DRAM traffic or prove physical subpass merging.',
        'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT / 'src/main.cpp', *sorted((ROOT / 'shaders').glob('*')), exe]},
    }
    snapshot = output / 'source-snapshot'
    for entry in ['CMakeLists.txt', 'src', 'shaders', 'scripts']:
        source = ROOT / entry
        target = snapshot / entry
        if source.is_dir():
            shutil.copytree(source, target, ignore=shutil.ignore_patterns('__pycache__'))
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    (output / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# GPU 对照运行', '', f'UTC：{stamp}', '', f'设备：{records[0]["device"]}；{args.width}×{args.height}；每批预热 {args.warmup} 帧、采样 {args.samples} 帧。', '', '| 批次 | 路径 | GPU P50 / ms | GPU P95 / ms | 最大通道差 / 255 |', '| --- | --- | --- | --- | --- |']
    for r in records:
        lines.append(f'| {r["batch"]} | {r["mode"]} | {r["p50_ms"]:.5f} | {r["p95_ms"]:.5f} | {r["max_channel_error_8bit"]} |')
    lines += ['', '计时覆盖四个渲染阶段，排除 CPU 等待、读回和显示。按帧提交并等待完成，数据不表示应用吞吐率。', '', '逻辑附件字节数只描述 storeOp 契约；实际显存流量、tile 合并和移动设备收益尚未测量。', '', '同目录保留逐帧 CSV、PNG/PPM、运行配置及源码指纹。']
    (output / '运行结果.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(output)

if __name__ == '__main__':
    main()
