$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
cmake -S $projectRoot -B "$projectRoot/build" -G 'Visual Studio 17 2022' -A x64
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
cmake --build "$projectRoot/build" --config Release --parallel 8
if ($LASTEXITCODE -ne 0) { throw 'C++ or shader build failed' }
