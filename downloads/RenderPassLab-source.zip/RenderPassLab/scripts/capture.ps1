param([ValidateSet('split','subpass','inline','bloom','bloom-separable')][string]$Mode='subpass', [ValidateSet('sdf','mesh')][string]$Scene='sdf')
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$renderDoc='D:\3D\_tools\_Unreal\RenderDoc\RenderDoc_1.46_64\renderdoccmd.exe'
$destination=Join-Path $projectRoot ('artifacts/capture-'+$Scene+'-'+$Mode+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
$oldLayerPath=$env:VK_LAYER_PATH
$oldLayers=$env:VK_INSTANCE_LAYERS
$oldCapture=$env:ENABLE_VULKAN_RENDERDOC_CAPTURE
try {
    $env:VK_LAYER_PATH=Split-Path -Parent $renderDoc
    $env:VK_INSTANCE_LAYERS='VK_LAYER_RENDERDOC_Capture'
    $env:ENABLE_VULKAN_RENDERDOC_CAPTURE='1'
    & $renderDoc capture -w "$projectRoot/build/Release/renderpass-lab.exe" $Mode $destination 960 540 1 2 capture rgba16f $Scene
    if($LASTEXITCODE -ne 0){throw 'RenderDoc launch failed'}
} finally {
    $env:VK_LAYER_PATH=$oldLayerPath
    $env:VK_INSTANCE_LAYERS=$oldLayers
    $env:ENABLE_VULKAN_RENDERDOC_CAPTURE=$oldCapture
}
$captures=Get-ChildItem -LiteralPath $destination -Filter '*.rdc'
if(!$captures){throw 'No .rdc capture was produced'}
$captures | Select-Object FullName,Length
