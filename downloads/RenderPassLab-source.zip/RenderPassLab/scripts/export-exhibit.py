"""Export actual benchmark images and measurements into a portable exhibit."""
import argparse,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('batch',type=Path);args=parser.parse_args()
batch=args.batch.resolve();data=json.loads((batch/'summary.json').read_text(encoding='utf-8'))
out=root/'exhibit';(out/'media').mkdir(parents=True,exist_ok=True)
for source,name in [('1-bloom/frame.png','reference.png'),('2-bloom-separable/frame.png','separable.png'),('difference-x32.png','difference.png')]:
    shutil.copy2(batch/source,out/'media'/name)
public={key:data[key] for key in ['platform','median_batch_p50_ms','gpu_reduction_percent','image_error_8bit','tradeoff']}
public['batch']=batch.name
public['runs']=[{'mode':r['mode'],'p50':r['p50'],'p95':r['p95']} for r in data['runs']]
(out/'data.js').write_text('window.measurement='+json.dumps(public,ensure_ascii=False)+';',encoding='utf-8')
print(out/'index.html')
