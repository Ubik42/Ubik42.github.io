"""Extract actual Vulkan command structure from RenderDoc's XML export."""
import argparse
import json
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

parser = argparse.ArgumentParser()
parser.add_argument('xml', type=Path)
args = parser.parse_args()
tree = ElementTree.parse(args.xml)
chunks = list(tree.getroot().iter('chunk'))
counts = Counter(chunk.get('name') for chunk in chunks)
names = ['vkCmdBeginRenderPass', 'vkCmdNextSubpass', 'vkCmdDraw', 'vkCmdEndRenderPass']
result = {'capture': str(args.xml), 'commands': {name: counts[name] for name in names}, 'render_passes': []}
for chunk in chunks:
    if chunk.get('name') != 'vkCreateRenderPass':
        continue
    subpasses = chunk.find('.//*[@name="subpassCount"]')
    attachments = chunk.find('.//*[@name="pAttachments"]')
    stores = []
    if attachments is not None:
        for attachment in attachments:
            fmt = attachment.find('.//*[@name="format"]')
            store = attachment.find('.//*[@name="storeOp"]')
            load = attachment.find('.//*[@name="loadOp"]')
            if store is not None:
                stores.append({'format': fmt.get('string'), 'load': load.get('string'), 'store': store.get('string')})
    result['render_passes'].append({'subpass_count': int(subpasses.text), 'attachments': stores})
output = args.xml.with_name('capture-structure.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
