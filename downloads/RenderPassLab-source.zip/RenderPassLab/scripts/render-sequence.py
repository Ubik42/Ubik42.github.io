"""Generate matching native camera sequences and encode intermediate footage."""
import json,subprocess
from pathlib import Path
from datetime import datetime
root=Path(__file__).resolve().parents[1]
out=root/'artifacts'/('camera-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
for mode in ['bloom','bloom-separable']:
    folder=out/mode
    subprocess.run([str(root/'build/Release/renderpass-lab.exe'),mode,str(folder),'1280','720','240','0','sequence'],check=True)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-framerate','30','-i',str(folder/'frame-%05d.ppm'),'-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out/(mode+'.mp4'))],check=True)
(out/'README.txt').write_text('Two matching native Vulkan camera sequences. 240 frames, 1280x720, encoded at 30 fps. Offline capture, not real-time performance. Final explanatory video composition remains separate.',encoding='utf-8')
print(out)
