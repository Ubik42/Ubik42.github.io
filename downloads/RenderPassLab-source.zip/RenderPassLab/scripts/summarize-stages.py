"""Summarize instrumented GPU intervals without mixing them with aggregate runs."""
import argparse,csv,json,statistics
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('runs',nargs='+',type=Path);parser.add_argument('--output',required=True,type=Path);args=parser.parse_args()
results=[]
for directory in args.runs:
    meta=json.loads((directory/'run.json').read_text())
    if not meta.get('stage_timing_instrumented'):raise ValueError('Not a stage-timing run: '+str(directory))
    with (directory/'stages.csv').open() as f:rows=list(csv.DictReader(f))
    with (directory/'frames.csv').open() as f:totals=list(csv.DictReader(f))
    assert len(rows)==len(totals)==meta['samples']
    keys=[key for key in rows[0] if key!='sample']
    errors=[]
    for row,total in zip(rows,totals):
        assert row['sample']==total['sample']
        errors.append(abs(sum(float(row[key]) for key in keys)-float(total['gpu_ms'])))
    if max(errors)>0.0001:raise ValueError('Intervals do not sum to total')
    stats={key:statistics.median(float(row[key]) for row in rows) for key in keys}
    bloom_keys=[key for key in keys if key.startswith('bloom')]
    if bloom_keys:stats['bloom_combined_ms']=statistics.median(sum(float(row[key]) for key in bloom_keys) for row in rows)
    results.append({'directory':str(directory),'mode':meta['mode'],'samples':len(rows),'interval_p50_ms':stats,'total_p50_ms':statistics.median(float(row['gpu_ms']) for row in totals),'max_sum_rounding_error_ms':max(errors)})
report={'scope':'Instrumented intervals include pass transitions and synchronization; diagnostic only. Do not replace uninstrumented interleaved benchmarks.','runs':results}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
