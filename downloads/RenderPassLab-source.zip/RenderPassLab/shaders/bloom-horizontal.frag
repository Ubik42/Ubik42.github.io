#version 450
#extension GL_EXT_samplerless_texture_functions : require
layout(set=0,binding=1) uniform texture2D previousImage;
layout(location=0) out vec4 result;
void main() {
    ivec2 p=ivec2(gl_FragCoord.xy),size=textureSize(previousImage,0);
    vec3 glow=vec3(0); float total=0;
    for(int x=-4;x<=4;x++) {
        float weight=exp(-float(x*x)/8.0);
        vec3 c=texelFetch(previousImage,clamp(p+ivec2(x*3,0),ivec2(0),size-1),0).rgb;
        glow+=max(c-vec3(1),vec3(0))*weight;
        total+=weight;
    }
    result=vec4(glow/total,1);
}
