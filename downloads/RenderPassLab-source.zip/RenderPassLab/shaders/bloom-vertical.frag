#version 450
#extension GL_GOOGLE_include_directive : require
#extension GL_EXT_samplerless_texture_functions : require
#include "post.glsl"
layout(set=0,binding=1) uniform texture2D horizontalImage;
layout(set=0,binding=2) uniform texture2D originalImage;
layout(location=0) out vec4 result;
void main() {
    ivec2 p=ivec2(gl_FragCoord.xy),size=textureSize(horizontalImage,0);
    vec3 glow=vec3(0); float total=0;
    for(int y=-4;y<=4;y++) {
        float weight=exp(-float(y*y)/8.0);
        glow+=texelFetch(horizontalImage,clamp(p+ivec2(0,y*3),ivec2(0),size-1),0).rgb*weight;
        total+=weight;
    }
    vec4 center=texelFetch(originalImage,p,0);
    result=applyTone(vec4(center.rgb+glow/total*0.85,center.a));
}
