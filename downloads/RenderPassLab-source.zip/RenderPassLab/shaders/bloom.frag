#version 450
#extension GL_GOOGLE_include_directive : require
#extension GL_EXT_samplerless_texture_functions : require
#include "post.glsl"
layout(set=0,binding=1) uniform texture2D previousImage;
layout(location=0) out vec4 result;
void main() {
    ivec2 p=ivec2(gl_FragCoord.xy),size=textureSize(previousImage,0);
    vec3 glow=vec3(0); float total=0;
    // Full-resolution reference kernel. A later separable/downsampled path will be compared to it.
    for(int y=-4;y<=4;y++)for(int x=-4;x<=4;x++) {
        float weight=exp(-float(x*x+y*y)/8.0);
        vec3 c=texelFetch(previousImage,clamp(p+ivec2(x,y)*3,ivec2(0),size-1),0).rgb;
        glow+=max(c-vec3(1),vec3(0))*weight;
        total+=weight;
    }
    vec4 center=texelFetch(previousImage,p,0);
    result=applyTone(vec4(center.rgb+glow/total*0.85,center.a));
}
