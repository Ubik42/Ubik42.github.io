#version 450
#extension GL_GOOGLE_include_directive : require
#include "post.glsl"
layout(input_attachment_index=0,set=0,binding=0) uniform subpassInput previous;
layout(location=0) out vec4 result;
void main() { result=applyFog(subpassLoad(previous)); }
