#version 450
layout(location=0) in vec3 world;
layout(location=1) in vec3 normal;
layout(location=2) in vec3 albedo;
layout(location=3) in vec3 material;
layout(location=4) in vec3 eyePosition;
layout(location=0) out vec4 hdr;
void main(){
    vec3 n=normalize(normal),v=normalize(eyePosition-world),l=normalize(vec3(-.5,.85,.3)),h=normalize(v+l);
    float rough=material.x,metal=material.y;
    float nl=max(dot(n,l),0),nv=max(dot(n,v),.001),nh=max(dot(n,h),0),vh=max(dot(v,h),0);
    float a=rough*rough,a2=a*a,den=nh*nh*(a2-1)+1,k=(rough+1)*(rough+1)/8;
    float D=a2/(3.14159265*den*den),G=nl/(nl*(1-k)+k)*nv/(nv*(1-k)+k);
    vec3 f0=mix(vec3(.04),albedo,metal),F=f0+(1-f0)*pow(1-vh,5);
    vec3 brdf=(1-F)*(1-metal)*albedo/3.14159265+D*G*F/(4*max(nl,.001)*nv);
    vec3 reflection=reflect(-v,n);
    vec3 env=mix(vec3(.065,.105,.16),vec3(.008,.022,.06),pow(max(reflection.y,0),.6));
    vec3 c=brdf*nl*vec3(4.6,3.9,2.9)+albedo*(1-metal)*vec3(.23,.32,.45)+env*f0*2.8;
    vec3 toRing=vec3(0,1.65,0)-world;
    c+=albedo*vec3(.06,.45,.65)*max(dot(n,normalize(toRing)),0)/(1+dot(toRing,toRing)*.45);
    if(material.z>.5)c=albedo;
    hdr=vec4(c,length(eyePosition-world));
}
