#version 450
layout(push_constant) uniform Frame { vec2 resolution; float cameraPhase; float unused; } frame;
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in vec3 albedo;
layout(location=3) in vec3 material;
layout(location=0) out vec3 world;
layout(location=1) out vec3 n;
layout(location=2) out vec3 color;
layout(location=3) out vec3 parameters;
layout(location=4) out vec3 eyePosition;
void main(){
    vec3 eye=vec3(3.9,2.7,7.4),target=vec3(0,1.25,-.4);
    float angle=sin(frame.cameraPhase*6.2831853)*.55;
    eye.xz=mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*eye.xz;
    vec3 f=normalize(target-eye),r=normalize(cross(f,vec3(0,1,0))),u=cross(r,f),v=position-eye;
    float z=dot(v,f),nearPlane=.1,farPlane=50.;
    gl_Position=vec4(dot(v,r)*1.65/(frame.resolution.x/frame.resolution.y),-dot(v,u)*1.65,
        farPlane/(farPlane-nearPlane)*z-farPlane*nearPlane/(farPlane-nearPlane),z);
    world=position;n=normal;color=albedo;parameters=material;eyePosition=eye;
}
