// Shared equations keep all three execution paths comparable.
vec4 applyFog(vec4 p) {
    float f=1-exp(-p.a*0.009);
    return vec4(mix(p.rgb,vec3(0.025,0.04,0.075),f),p.a);
}
vec4 applyGrade(vec4 p) {
    float y=dot(p.rgb,vec3(0.2126,0.7152,0.0722));
    return vec4(mix(vec3(y),p.rgb,1.08)*vec3(1.06,1.0,0.96),p.a);
}
vec4 applyTone(vec4 p) {
    vec3 c=p.rgb;
    c=clamp((c*(2.51*c+0.03))/(c*(2.43*c+0.59)+0.14),0,1);
    return vec4(pow(c,vec3(1.0/2.2)),1);
}
