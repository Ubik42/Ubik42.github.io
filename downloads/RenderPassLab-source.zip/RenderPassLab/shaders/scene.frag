#version 450
#extension GL_GOOGLE_include_directive : require
#include "post.glsl"
layout(location=0) out vec4 hdr;
layout(push_constant) uniform Frame { vec2 resolution; float cameraPhase; float padding; } frame;
vec4 halfRound(vec4 p) { return vec4(unpackHalf2x16(packHalf2x16(p.xy)),unpackHalf2x16(packHalf2x16(p.zw))); }
vec4 finishColor(vec4 p) {
#ifdef INLINE_OUTPUT
    p=halfRound(p);
    p=halfRound(applyFog(p));
    p=halfRound(applyGrade(p));
    return applyTone(p);
#else
    return p;
#endif
}
// Original procedural exhibit. Analytic environment lighting, no baked/game assets.
float box(vec3 p, vec3 b) { vec3 q=abs(p)-b; return length(max(q,0))+min(max(q.x,max(q.y,q.z)),0); }
vec2 world(vec3 p) {
    vec2 hit=vec2(p.y, 1);
    float d=length(p-vec3(0,1.65,0))-0.82;
    if(d<hit.x) hit=vec2(d,2);
    vec3 ring=p-vec3(0,1.65,0);
    ring.yz=mat2(0.82,-0.572,0.572,0.82)*ring.yz;
    d=length(vec2(length(ring.xz)-1.18,ring.y))-0.045;
    if(d<hit.x) hit=vec2(d,3);
    d=box(p-vec3(0,0.18,0),vec3(1.5,0.18,1.5));
    if(d<hit.x) hit=vec2(d,4);
    vec3 c=p; c.x=abs(c.x)-3.7; c.z-=clamp(round(c.z/3.5),-1,0)*3.5;
    d=box(c-vec3(0,1.9,0),vec3(0.18,1.9,0.18))-0.04;
    if(d<hit.x) hit=vec2(d,5);
    d=box(vec3(abs(p.x)-3.7,p.y-3.9,p.z+1.75),vec3(0.28,0.12,2.1));
    if(d<hit.x) hit=vec2(d,5);
    d=box(p-vec3(0,0.07,0),vec3(2.0,0.07,2.0))-0.04;
    if(d<hit.x) hit=vec2(d,4);
    d=length(p-vec3(-2.4,0.65,-1.8))-0.65;
    if(d<hit.x) hit=vec2(d,6);
    d=box(p-vec3(2.2,0.5,-1.7),vec3(0.48))-0.12;
    if(d<hit.x) hit=vec2(d,7);
    d=box(p-vec3(0,0.38,-3.6),vec3(2.8,0.38,0.45));
    if(d<hit.x) hit=vec2(d,4);
    return hit;
}
vec3 normalAt(vec3 p) {
    vec2 e=vec2(0.001,0);
    return normalize(vec3(world(p+e.xyy).x-world(p-e.xyy).x,world(p+e.yxy).x-world(p-e.yxy).x,world(p+e.yyx).x-world(p-e.yyx).x));
}
float shadow(vec3 p, vec3 l) {
    float s=1,t=0.03;
    for(int i=0;i<28;i++) { float d=world(p+l*t).x; s=min(s,12*d/t); t+=clamp(d,0.02,0.5); if(t>10)break; }
    return clamp(s,0.05,1);
}
vec3 sky(vec3 d) { return mix(vec3(0.065,0.105,0.16),vec3(0.008,0.022,0.06),pow(max(d.y,0),0.6)); }
vec4 renderSample(vec2 pixel) {
    vec2 uv=(pixel*2-frame.resolution)/frame.resolution.y;
    uv.y=-uv.y;
    vec3 eye=vec3(3.9,2.7,7.4), target=vec3(0,1.25,-0.4);
    float angle=sin(frame.cameraPhase*6.2831853)*0.55;
    eye.xz=mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*eye.xz;
    vec3 f=normalize(target-eye), r=normalize(cross(f,vec3(0,1,0))), u=cross(r,f);
    vec3 ray=normalize(f*1.65+r*uv.x+u*uv.y);
    float t=0; vec2 h=vec2(0);
    bool found=false;
    for(int i=0;i<160;i++) { h=world(eye+ray*t); if(h.x<0.0004){found=true;break;} if(t>38)break; t+=h.x*0.88; }
    vec3 color=sky(ray);
    if(found&&t<38) {
        vec3 p=eye+ray*t,n=normalAt(p),v=-ray,l=normalize(vec3(-0.5,0.85,0.3)),halfway=normalize(v+l);
        vec3 albedo=vec3(0.18,0.23,0.28); float metallic=0, rough=0.65;
        if(h.y==1) { vec2 tile=abs(fract(p.xz*0.45)-0.5); float aa=max(0.001,t/frame.resolution.y*0.35); float grout=smoothstep(0.488-aa,0.488+aa,max(tile.x,tile.y)); albedo=mix(vec3(0.055,0.075,0.09),vec3(0.015),grout); rough=0.42; }
        if(h.y==2) { albedo=vec3(0.91,0.49,0.12); metallic=0.94; rough=0.22; }
        if(h.y==3) return vec4(vec3(0.1,2.6,3.4),t);
        if(h.y==4) { albedo=vec3(0.06,0.10,0.15); metallic=0.4; rough=0.25; }
        if(h.y==5) { albedo=vec3(0.12,0.17,0.21); metallic=0.65; rough=0.35; }
        if(h.y==6) { albedo=vec3(0.07,0.32,0.55); metallic=0.75; rough=0.32; }
        if(h.y==7) { albedo=vec3(0.76,0.65,0.52); rough=0.28; }
        float ndl=max(dot(n,l),0),ndv=max(dot(n,v),0.001),ndh=max(dot(n,halfway),0),vdh=max(dot(v,halfway),0);
        float a=rough*rough,a2=a*a,den=ndh*ndh*(a2-1)+1;
        float D=a2/(3.14159265*den*den), k=(rough+1)*(rough+1)/8;
        float G=ndl/(ndl*(1-k)+k)*ndv/(ndv*(1-k)+k);
        vec3 f0=mix(vec3(0.04),albedo,metallic),F=f0+(1-f0)*pow(1-vdh,5);
        vec3 brdf=(1-F)*(1-metallic)*albedo/3.14159265+D*G*F/(4*max(ndl,0.001)*ndv);
        vec3 env=sky(reflect(ray,n));
        float ao=clamp(world(p+n*0.25).x/0.25,0.35,1);
        color=brdf*ndl*vec3(4.6,3.9,2.9)*shadow(p+n*0.008,l);
        color+=ao*(albedo*(1-metallic)*vec3(0.23,0.32,0.45)+env*f0*2.8);
        // Cool local fill suggests the emissive ring; this is analytic lighting, not GI.
        vec3 toRing=vec3(0,1.65,0)-p;
        color+=albedo*vec3(0.06,0.45,0.65)*max(dot(n,normalize(toRing)),0)/(1+dot(toRing,toRing)*0.45);
    }
    return vec4(color,found?min(t,38):38);
}
void main() {
    // Identical four-sample scene input for every post-processing path.
    vec4 color=vec4(0);
    for(int y=0;y<2;y++)for(int x=0;x<2;x++)
        color+=renderSample(gl_FragCoord.xy+vec2(x,y)*0.5-0.25);
    hdr=finishColor(color*0.25);
}
