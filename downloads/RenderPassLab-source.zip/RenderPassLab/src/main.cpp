#include <windows.h>
#include <vulkan/vulkan.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#ifdef RPL_RENDERDOC
#include <renderdoc_app.h>
#endif

#define VK_FUNCTIONS(X) \
 X(vkCreateInstance) X(vkDestroyInstance) X(vkEnumeratePhysicalDevices) X(vkGetPhysicalDeviceProperties) \
 X(vkGetPhysicalDeviceMemoryProperties) X(vkGetPhysicalDeviceQueueFamilyProperties) X(vkGetPhysicalDeviceFormatProperties) \
 X(vkCreateDevice) X(vkDestroyDevice) X(vkGetDeviceQueue) X(vkDeviceWaitIdle) \
 X(vkCreateImage) X(vkGetImageMemoryRequirements) X(vkAllocateMemory) X(vkBindImageMemory) X(vkCreateImageView) \
 X(vkDestroyImageView) X(vkDestroyImage) X(vkFreeMemory) X(vkCreateBuffer) X(vkGetBufferMemoryRequirements) \
 X(vkBindBufferMemory) X(vkDestroyBuffer) X(vkMapMemory) X(vkUnmapMemory) \
 X(vkCreateRenderPass) X(vkDestroyRenderPass) X(vkCreateFramebuffer) X(vkDestroyFramebuffer) \
 X(vkCreateDescriptorSetLayout) X(vkDestroyDescriptorSetLayout) X(vkCreateDescriptorPool) X(vkDestroyDescriptorPool) \
 X(vkAllocateDescriptorSets) X(vkUpdateDescriptorSets) X(vkCreatePipelineLayout) X(vkDestroyPipelineLayout) \
 X(vkCreateShaderModule) X(vkDestroyShaderModule) X(vkCreateGraphicsPipelines) X(vkDestroyPipeline) \
 X(vkCreateCommandPool) X(vkDestroyCommandPool) X(vkAllocateCommandBuffers) X(vkResetCommandBuffer) \
 X(vkBeginCommandBuffer) X(vkEndCommandBuffer) X(vkCmdBeginRenderPass) X(vkCmdNextSubpass) X(vkCmdEndRenderPass) \
 X(vkCmdBindPipeline) X(vkCmdBindDescriptorSets) X(vkCmdPushConstants) X(vkCmdDraw) X(vkCmdPipelineBarrier) \
 X(vkCmdCopyImageToBuffer) X(vkCreateQueryPool) X(vkDestroyQueryPool) X(vkCmdResetQueryPool) \
 X(vkCmdWriteTimestamp) X(vkGetQueryPoolResults) X(vkCreateFence) X(vkDestroyFence) X(vkResetFences) X(vkWaitForFences) X(vkQueueSubmit)
#define DECLARE(name) PFN_##name name = nullptr;
VK_FUNCTIONS(DECLARE)
#undef DECLARE
void check(VkResult r, const char* what) { if(r!=VK_SUCCESS) throw std::runtime_error(std::string(what)+" VkResult="+std::to_string(r)); }
#define OK(expr) check((expr), #expr)
struct Image { VkImage image{}; VkDeviceMemory memory{}; VkImageView view{}; };
struct Lab {
    HMODULE loader{}; VkInstance instance{}; VkPhysicalDevice physical{}; VkPhysicalDeviceProperties properties{};
    VkDevice device{}; VkQueue queue{}; uint32_t family=0, validBits=0; uint32_t width=960,height=540;
    bool fused=false, inlineMode=false, bloom=false, separable=false; int stageCount=4;
    float cameraPhase=0;
    bool stageTiming=false;
    std::vector<double> lastStageTimes;
    uint32_t queryCount() const { return stageTiming?uint32_t((inlineMode?1:stageCount)+1):2; }
    std::array<Image,5> images{}; std::vector<VkRenderPass> passes;
    std::vector<VkFramebuffer> framebuffers; std::array<VkPipeline,5> pipelines{};
    VkDescriptorSetLayout descriptorLayout{}; VkDescriptorPool descriptorPool{};
    std::array<VkDescriptorSet,4> sets{}; VkPipelineLayout pipelineLayout{};
    VkCommandPool commandPool{}; VkCommandBuffer command{}; VkQueryPool queryPool{}; VkFence fence{};
    VkBuffer readback{}; VkDeviceMemory readbackMemory{};
    uint32_t memoryType(uint32_t bits, VkMemoryPropertyFlags required) {
        VkPhysicalDeviceMemoryProperties p{}; vkGetPhysicalDeviceMemoryProperties(physical,&p);
        for(uint32_t i=0;i<p.memoryTypeCount;i++) if((bits&(1u<<i)) && (p.memoryTypes[i].propertyFlags&required)==required) return i;
        throw std::runtime_error("Required Vulkan memory type unavailable");
    }
    void init() {
        loader=LoadLibraryW(L"vulkan-1.dll"); if(!loader) throw std::runtime_error("Vulkan loader unavailable");
#define LOAD(name) name=reinterpret_cast<PFN_##name>(GetProcAddress(loader,#name)); if(!name) throw std::runtime_error(#name);
        VK_FUNCTIONS(LOAD)
#undef LOAD
        auto instanceProc=reinterpret_cast<PFN_vkGetInstanceProcAddr>(GetProcAddress(loader,"vkGetInstanceProcAddr"));
        if(!instanceProc)throw std::runtime_error("vkGetInstanceProcAddr unavailable");
        vkCreateInstance=reinterpret_cast<PFN_vkCreateInstance>(instanceProc(nullptr,"vkCreateInstance"));
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO}; app.pApplicationName="RenderPassLab"; app.apiVersion=VK_API_VERSION_1_1;
        VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO}; ci.pApplicationInfo=&app;
        OK(vkCreateInstance(&ci,nullptr,&instance));
        // Resolve through the instance dispatch table so Vulkan layers/capture tools see calls.
#define RESOLVE(name) if(auto address=instanceProc(instance,#name))name=reinterpret_cast<PFN_##name>(address);
        VK_FUNCTIONS(RESOLVE)
#undef RESOLVE
        uint32_t count=0; OK(vkEnumeratePhysicalDevices(instance,&count,nullptr));
        std::vector<VkPhysicalDevice> devices(count); OK(vkEnumeratePhysicalDevices(instance,&count,devices.data()));
        if(devices.empty()) throw std::runtime_error("No Vulkan device");
        physical=devices.front(); for(auto d:devices) { VkPhysicalDeviceProperties p; vkGetPhysicalDeviceProperties(d,&p); if(p.deviceType==VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) {physical=d;break;} }
        vkGetPhysicalDeviceProperties(physical,&properties);
        vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,nullptr); std::vector<VkQueueFamilyProperties> qs(count);
        vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,qs.data()); bool found=false;
        for(uint32_t i=0;i<count;i++) if((qs[i].queueFlags&VK_QUEUE_GRAPHICS_BIT)&&qs[i].timestampValidBits) { family=i;validBits=qs[i].timestampValidBits;found=true;break; }
        if(!found) throw std::runtime_error("No graphics queue with timestamps");
        for(auto format:{VK_FORMAT_R16G16B16A16_SFLOAT,VK_FORMAT_R8G8B8A8_UNORM}) { VkFormatProperties fp;vkGetPhysicalDeviceFormatProperties(physical,format,&fp);if(!(fp.optimalTilingFeatures&VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT))throw std::runtime_error("Attachment format unsupported"); }
        float priority=1; VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};qi.queueFamilyIndex=family;qi.queueCount=1;qi.pQueuePriorities=&priority;
        VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};di.queueCreateInfoCount=1;di.pQueueCreateInfos=&qi;
        OK(vkCreateDevice(physical,&di,nullptr,&device));vkGetDeviceQueue(device,family,0,&queue);
        for(int i=inlineMode?stageCount-1:0;i<stageCount;i++) {
            VkImageCreateInfo im{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};im.imageType=VK_IMAGE_TYPE_2D;im.format=i==stageCount-1?VK_FORMAT_R8G8B8A8_UNORM:VK_FORMAT_R16G16B16A16_SFLOAT;
            im.extent={width,height,1};im.mipLevels=im.arrayLayers=1;im.samples=VK_SAMPLE_COUNT_1_BIT;im.tiling=VK_IMAGE_TILING_OPTIMAL;
            im.usage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | (i==stageCount-1?VK_IMAGE_USAGE_TRANSFER_SRC_BIT:VK_IMAGE_USAGE_INPUT_ATTACHMENT_BIT);
            if(fused&&i<3) im.usage|=VK_IMAGE_USAGE_TRANSIENT_ATTACHMENT_BIT;
            if(bloom&&i>=2&&i<stageCount-1) im.usage|=VK_IMAGE_USAGE_SAMPLED_BIT;
            OK(vkCreateImage(device,&im,nullptr,&images[i].image)); VkMemoryRequirements req;vkGetImageMemoryRequirements(device,images[i].image,&req);
            VkMemoryAllocateInfo alloc{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};alloc.allocationSize=req.size;alloc.memoryTypeIndex=memoryType(req.memoryTypeBits,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
            OK(vkAllocateMemory(device,&alloc,nullptr,&images[i].memory));OK(vkBindImageMemory(device,images[i].image,images[i].memory,0));
            VkImageViewCreateInfo view{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};view.image=images[i].image;view.viewType=VK_IMAGE_VIEW_TYPE_2D;view.format=im.format;view.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
            OK(vkCreateImageView(device,&view,nullptr,&images[i].view));
        }
        VkBufferCreateInfo bc{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bc.size=VkDeviceSize(width)*height*4;bc.usage=VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        OK(vkCreateBuffer(device,&bc,nullptr,&readback));VkMemoryRequirements br;vkGetBufferMemoryRequirements(device,readback,&br);
        VkMemoryAllocateInfo ba{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ba.allocationSize=br.size;ba.memoryTypeIndex=memoryType(br.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        OK(vkAllocateMemory(device,&ba,nullptr,&readbackMemory));OK(vkBindBufferMemory(device,readback,readbackMemory,0));
        createDescriptors();createPasses();createPipelines();
        VkCommandPoolCreateInfo cp{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};cp.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;cp.queueFamilyIndex=family;OK(vkCreateCommandPool(device,&cp,nullptr,&commandPool));
        VkCommandBufferAllocateInfo ca{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};ca.commandPool=commandPool;ca.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;ca.commandBufferCount=1;OK(vkAllocateCommandBuffers(device,&ca,&command));
        VkQueryPoolCreateInfo qc{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};qc.queryType=VK_QUERY_TYPE_TIMESTAMP;qc.queryCount=queryCount();OK(vkCreateQueryPool(device,&qc,nullptr,&queryPool));
        VkFenceCreateInfo fc{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};OK(vkCreateFence(device,&fc,nullptr,&fence));
    }
    void createDescriptors() {
        VkDescriptorSetLayoutBinding binding{};binding.binding=0;binding.descriptorType=VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT;binding.descriptorCount=1;binding.stageFlags=VK_SHADER_STAGE_FRAGMENT_BIT;
        std::array<VkDescriptorSetLayoutBinding,3> bindings{binding,binding,binding};
        for(int i=1;i<3;i++){bindings[i].binding=i;bindings[i].descriptorType=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;}
        VkDescriptorSetLayoutCreateInfo dl{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};dl.bindingCount=bloom?3:1;dl.pBindings=bindings.data();OK(vkCreateDescriptorSetLayout(device,&dl,nullptr,&descriptorLayout));
        VkDescriptorPoolSize sizes[]={{VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT,4},{VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,8}};VkDescriptorPoolCreateInfo dp{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};dp.maxSets=4;dp.poolSizeCount=bloom?2:1;dp.pPoolSizes=sizes;OK(vkCreateDescriptorPool(device,&dp,nullptr,&descriptorPool));
        std::array<VkDescriptorSetLayout,4> layouts{descriptorLayout,descriptorLayout,descriptorLayout,descriptorLayout};
        VkDescriptorSetAllocateInfo da{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};da.descriptorPool=descriptorPool;da.descriptorSetCount=4;da.pSetLayouts=layouts.data();OK(vkAllocateDescriptorSets(device,&da,sets.data()));
        auto writeImage=[&](int set,int bindingIndex,int imageIndex,VkDescriptorType type){VkDescriptorImageInfo image{};image.imageView=images[imageIndex].view;image.imageLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};w.dstSet=sets[set];w.dstBinding=bindingIndex;w.descriptorCount=1;w.descriptorType=type;w.pImageInfo=&image;vkUpdateDescriptorSets(device,1,&w,0,nullptr);};
        if(!inlineMode)for(int i=0;i<stageCount-1;i++)writeImage(i,0,i,VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT);
        if(bloom)writeImage(2,1,2,VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE);
        if(separable){writeImage(3,1,3,VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE);writeImage(3,2,2,VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE);}
        VkPushConstantRange range{VK_SHADER_STAGE_FRAGMENT_BIT,0,16};VkPipelineLayoutCreateInfo pl{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};pl.setLayoutCount=1;pl.pSetLayouts=&descriptorLayout;pl.pushConstantRangeCount=1;pl.pPushConstantRanges=&range;OK(vkCreatePipelineLayout(device,&pl,nullptr,&pipelineLayout));
    }
    VkAttachmentDescription attachment(int index, bool input) {
        VkAttachmentDescription a{};a.format=index==stageCount-1?VK_FORMAT_R8G8B8A8_UNORM:VK_FORMAT_R16G16B16A16_SFLOAT;a.samples=VK_SAMPLE_COUNT_1_BIT;
        a.loadOp=input?VK_ATTACHMENT_LOAD_OP_LOAD:VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        a.storeOp=(input||(fused&&index<3))?VK_ATTACHMENT_STORE_OP_DONT_CARE:VK_ATTACHMENT_STORE_OP_STORE;
        if(separable&&index==2)a.storeOp=VK_ATTACHMENT_STORE_OP_STORE;
        a.stencilLoadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE;a.stencilStoreOp=VK_ATTACHMENT_STORE_OP_DONT_CARE;
        a.initialLayout=input?VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:VK_IMAGE_LAYOUT_UNDEFINED;
        a.finalLayout=index==stageCount-1?VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;return a;
    }
    void createPasses() {
        for(int pass=0;pass<((fused||inlineMode)?1:stageCount);pass++) {
            std::vector<VkAttachmentDescription> attachments;std::vector<VkImageView> views;
            std::vector<VkSubpassDescription> subpasses;std::array<VkAttachmentReference,4> colors{},inputs{};std::vector<VkSubpassDependency> deps;
            int n=fused?4:1;
            if(inlineMode){attachments.push_back(attachment(3,false));views.push_back(images[3].view);}
            else if(fused) for(int i=0;i<4;i++){attachments.push_back(attachment(i,false));views.push_back(images[i].view);}
            else { if(pass>0){attachments.push_back(attachment(pass-1,true));views.push_back(images[pass-1].view);} attachments.push_back(attachment(pass,false));views.push_back(images[pass].view); }
            for(int s=0;s<n;s++) {
                colors[s]={uint32_t(fused?s:(pass>0?1:0)),VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
                inputs[s]={uint32_t(fused?s-1:0),VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
                VkSubpassDescription sub{};sub.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS;sub.colorAttachmentCount=1;sub.pColorAttachments=&colors[s];
                if((fused&&s>0)||(!fused&&pass>0)){sub.inputAttachmentCount=1;sub.pInputAttachments=&inputs[s];}
                subpasses.push_back(sub);
                if(s>0) { VkSubpassDependency dep{};dep.srcSubpass=s-1;dep.dstSubpass=s;dep.srcStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;dep.dstStageMask=VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;dep.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;dep.dstAccessMask=VK_ACCESS_INPUT_ATTACHMENT_READ_BIT;dep.dependencyFlags=VK_DEPENDENCY_BY_REGION_BIT;deps.push_back(dep); }
            }
            // Explicit external dependency covers imported input and layout transitions.
            VkSubpassDependency enter{};enter.srcSubpass=VK_SUBPASS_EXTERNAL;enter.dstSubpass=0;enter.srcStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;enter.dstStageMask=VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT|VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;enter.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;enter.dstAccessMask=VK_ACCESS_INPUT_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;enter.dependencyFlags=VK_DEPENDENCY_BY_REGION_BIT;deps.push_back(enter);
            if(bloom&&pass>=3){deps.back().dstAccessMask|=VK_ACCESS_SHADER_READ_BIT;deps.back().dependencyFlags=0;}
            VkRenderPassCreateInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};rp.attachmentCount=uint32_t(attachments.size());rp.pAttachments=attachments.data();rp.subpassCount=n;rp.pSubpasses=subpasses.data();rp.dependencyCount=uint32_t(deps.size());rp.pDependencies=deps.data();
            VkRenderPass renderPass{};OK(vkCreateRenderPass(device,&rp,nullptr,&renderPass));passes.push_back(renderPass);
            VkFramebufferCreateInfo fb{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};fb.renderPass=renderPass;fb.attachmentCount=uint32_t(views.size());fb.pAttachments=views.data();fb.width=width;fb.height=height;fb.layers=1;VkFramebuffer framebuffer;OK(vkCreateFramebuffer(device,&fb,nullptr,&framebuffer));framebuffers.push_back(framebuffer);
        }
    }
    VkShaderModule shader(const std::string& name) {
        std::ifstream file(std::string(SHADER_DIR)+"/"+name+".spv",std::ios::binary|std::ios::ate);if(!file)throw std::runtime_error("Missing shader "+name);
        size_t size=size_t(file.tellg());std::vector<uint32_t> data((size+3)/4);file.seekg(0);file.read(reinterpret_cast<char*>(data.data()),size);
        VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};ci.codeSize=size;ci.pCode=data.data();VkShaderModule module;OK(vkCreateShaderModule(device,&ci,nullptr,&module));return module;
    }
    void createPipelines() {
        auto vert=shader("fullscreen.vert");const char* names[]={"scene.frag","fog.frag","grade.frag","tone.frag"};
        for(int i=0;i<(inlineMode?1:stageCount);i++) {
            auto frag=shader(inlineMode?"scene-inline.frag":(separable&&i>=3?(i==3?"bloom-horizontal.frag":"bloom-vertical.frag"):(bloom&&i==3?"bloom.frag":names[i])));std::array<VkPipelineShaderStageCreateInfo,2> stages{};
            for(auto& s:stages){s.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;s.pName="main";}stages[0].stage=VK_SHADER_STAGE_VERTEX_BIT;stages[0].module=vert;stages[1].stage=VK_SHADER_STAGE_FRAGMENT_BIT;stages[1].module=frag;
            VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};ia.topology=VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
            VkViewport viewport{0,0,float(width),float(height),0,1};VkRect2D scissor{{0,0},{width,height}};VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};vp.viewportCount=vp.scissorCount=1;vp.pViewports=&viewport;vp.pScissors=&scissor;
            VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};rs.polygonMode=VK_POLYGON_MODE_FILL;rs.cullMode=VK_CULL_MODE_NONE;rs.lineWidth=1;
            VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};ms.rasterizationSamples=VK_SAMPLE_COUNT_1_BIT;
            VkPipelineColorBlendAttachmentState color{};color.colorWriteMask=15;VkPipelineColorBlendStateCreateInfo blend{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};blend.attachmentCount=1;blend.pAttachments=&color;
            VkGraphicsPipelineCreateInfo p{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};p.stageCount=2;p.pStages=stages.data();p.pVertexInputState=&vi;p.pInputAssemblyState=&ia;p.pViewportState=&vp;p.pRasterizationState=&rs;p.pMultisampleState=&ms;p.pColorBlendState=&blend;p.layout=pipelineLayout;p.renderPass=passes[fused?0:i];p.subpass=fused?i:0;
            OK(vkCreateGraphicsPipelines(device,VK_NULL_HANDLE,1,&p,nullptr,&pipelines[i]));vkDestroyShaderModule(device,frag,nullptr);
        }vkDestroyShaderModule(device,vert,nullptr);
    }
    double frame(bool capture) {
        OK(vkResetCommandBuffer(command,0));VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};OK(vkBeginCommandBuffer(command,&begin));
        vkCmdResetQueryPool(command,queryPool,0,queryCount());vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,queryPool,0);
        for(int i=0;i<(inlineMode?1:stageCount);i++) {
            if(!fused||i==0){VkRenderPassBeginInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};rp.renderPass=passes[fused?0:i];rp.framebuffer=framebuffers[fused?0:i];rp.renderArea={{0,0},{width,height}};vkCmdBeginRenderPass(command,&rp,VK_SUBPASS_CONTENTS_INLINE);}
            else vkCmdNextSubpass(command,VK_SUBPASS_CONTENTS_INLINE);
            vkCmdBindPipeline(command,VK_PIPELINE_BIND_POINT_GRAPHICS,pipelines[i]);
            if(i>0)vkCmdBindDescriptorSets(command,VK_PIPELINE_BIND_POINT_GRAPHICS,pipelineLayout,0,1,&sets[i-1],0,nullptr);
            float parameters[]={float(width),float(height),cameraPhase,0};vkCmdPushConstants(command,pipelineLayout,VK_SHADER_STAGE_FRAGMENT_BIT,0,16,parameters);vkCmdDraw(command,3,1,0,0);
            if(!fused||i==3)vkCmdEndRenderPass(command);
            if(stageTiming)vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,queryPool,i+1);
        }
        if(!stageTiming)vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,queryPool,1);
        if(capture){
            VkMemoryBarrier barrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};barrier.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT;vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,1,&barrier,0,nullptr,0,nullptr);
            VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};copy.imageExtent={width,height,1};vkCmdCopyImageToBuffer(command,images[stageCount-1].image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,readback,1,&copy);
            barrier.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_HOST_READ_BIT;vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,0,1,&barrier,0,nullptr,0,nullptr);
        }
        OK(vkEndCommandBuffer(command));OK(vkResetFences(device,1,&fence));VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.commandBufferCount=1;submit.pCommandBuffers=&command;OK(vkQueueSubmit(queue,1,&submit,fence));OK(vkWaitForFences(device,1,&fence,VK_TRUE,UINT64_MAX));
        std::vector<uint64_t> ticks(queryCount());OK(vkGetQueryPoolResults(device,queryPool,0,queryCount(),ticks.size()*sizeof(uint64_t),ticks.data(),sizeof(uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT));
        auto elapsed=[&](uint64_t start,uint64_t end){uint64_t delta=end-start;if(validBits<64)delta&=((uint64_t(1)<<validBits)-1);return double(delta)*properties.limits.timestampPeriod/1e6;};
        lastStageTimes.clear();if(stageTiming)for(size_t i=1;i<ticks.size();i++)lastStageTimes.push_back(elapsed(ticks[i-1],ticks[i]));
        return elapsed(ticks.front(),ticks.back());
    }
    void save(const std::filesystem::path& path) {
        void* data=nullptr;OK(vkMapMemory(device,readbackMemory,0,VK_WHOLE_SIZE,0,&data));
        std::ofstream out(path,std::ios::binary);out<<"P6\n"<<width<<" "<<height<<"\n255\n";auto* bytes=static_cast<uint8_t*>(data);
        std::vector<uint8_t> rgb(size_t(width)*height*3);
        for(size_t i=0;i<size_t(width)*height;i++){rgb[i*3]=bytes[i*4];rgb[i*3+1]=bytes[i*4+1];rgb[i*3+2]=bytes[i*4+2];}
        out.write(reinterpret_cast<const char*>(rgb.data()),rgb.size());vkUnmapMemory(device,readbackMemory);
    }
    ~Lab(){
        if(device){vkDeviceWaitIdle(device);if(fence)vkDestroyFence(device,fence,nullptr);if(queryPool)vkDestroyQueryPool(device,queryPool,nullptr);if(commandPool)vkDestroyCommandPool(device,commandPool,nullptr);
            for(auto p:pipelines)if(p)vkDestroyPipeline(device,p,nullptr);for(auto f:framebuffers)vkDestroyFramebuffer(device,f,nullptr);for(auto p:passes)vkDestroyRenderPass(device,p,nullptr);
            if(pipelineLayout)vkDestroyPipelineLayout(device,pipelineLayout,nullptr);if(descriptorPool)vkDestroyDescriptorPool(device,descriptorPool,nullptr);if(descriptorLayout)vkDestroyDescriptorSetLayout(device,descriptorLayout,nullptr);
            if(readback)vkDestroyBuffer(device,readback,nullptr);if(readbackMemory)vkFreeMemory(device,readbackMemory,nullptr);
            for(auto i:images){if(i.view)vkDestroyImageView(device,i.view,nullptr);if(i.image)vkDestroyImage(device,i.image,nullptr);if(i.memory)vkFreeMemory(device,i.memory,nullptr);}vkDestroyDevice(device,nullptr);
        }if(instance)vkDestroyInstance(instance,nullptr);if(loader)FreeLibrary(loader);
    }
};
int main(int argc,char**argv){try{
    if(argc<3){std::cerr<<"renderpass-lab split|subpass|inline|bloom output-dir [width height samples warmup]\n";return 2;}
    std::string mode=argv[1];if(mode!="split"&&mode!="subpass"&&mode!="inline"&&mode!="bloom"&&mode!="bloom-separable")throw std::runtime_error("Invalid mode");
    Lab lab;lab.fused=mode=="subpass";lab.inlineMode=mode=="inline";lab.separable=mode=="bloom-separable";lab.bloom=mode=="bloom"||lab.separable;lab.stageCount=lab.separable?5:4;if(argc>4){lab.width=std::stoul(argv[3]);lab.height=std::stoul(argv[4]);}
    int samples=argc>5?std::stoi(argv[5]):90,warmup=argc>6?std::stoi(argv[6]):30;
    if(lab.width<16||lab.height<16||lab.width>8192||lab.height>8192||samples<1||warmup<0)throw std::runtime_error("Invalid dimensions/sample count");
    lab.stageTiming=argc>7&&std::string(argv[7])=="stages";
    if(lab.stageTiming&&lab.fused)throw std::runtime_error("Stage timing is for separate render passes; subpass mode must use aggregate timing");
    std::filesystem::path out=argv[2];std::filesystem::create_directories(out);lab.init();
    if(argc>7&&std::string(argv[7])=="sequence") {
        for(int i=0;i<samples;i++) {
            lab.cameraPhase=float(i)/float(samples);
            lab.frame(true);
            char name[64];std::snprintf(name,sizeof(name),"frame-%05d.ppm",i);
            lab.save(out/name);
        }
        std::ofstream sequence(out/"sequence.json");
        sequence<<"{\"mode\":\""<<mode<<"\",\"frames\":"<<samples<<",\"width\":"<<lab.width<<",\"height\":"<<lab.height<<",\"playback_fps\":30,\"measurement\":false,\"description\":\"Offline native Vulkan frames; camera phase i/frameCount; not a real-time FPS recording\"}";
        std::cout<<"Saved "<<samples<<" native Vulkan camera frames\n";return 0;
    }
    bool captured=false;
#ifdef RPL_RENDERDOC
    RENDERDOC_API_1_6_0* captureApi=nullptr;
    if(argc>7&&std::string(argv[7])=="capture") {
        auto module=GetModuleHandleW(L"renderdoc.dll");
        if(!module)throw std::runtime_error("Run capture mode through renderdoccmd capture");
        auto getApi=reinterpret_cast<pRENDERDOC_GetAPI>(GetProcAddress(module,"RENDERDOC_GetAPI"));
        if(!getApi||!getApi(eRENDERDOC_API_Version_1_6_0,reinterpret_cast<void**>(&captureApi)))throw std::runtime_error("RenderDoc API unavailable");
        captureApi->SetCaptureFilePathTemplate((std::filesystem::absolute(out)/"renderpass").string().c_str());
    }
#else
    if(argc>7&&std::string(argv[7])=="capture")throw std::runtime_error("This build has no RenderDoc header support");
#endif
    std::ofstream csv(out/"frames.csv");csv<<"sample,gpu_ms\n";std::vector<double> times;
    std::ofstream stageCsv;
    if(lab.stageTiming){stageCsv.open(out/"stages.csv");stageCsv<<"sample,scene_ms";if(!lab.inlineMode)stageCsv<<",fog_ms,grade_ms,"<<(lab.separable?"bloom_horizontal_ms,bloom_vertical_composite_ms":(lab.bloom?"bloom_composite_ms":"tone_ms"));stageCsv<<"\n";}
    for(int i=-warmup;i<samples;i++){
#ifdef RPL_RENDERDOC
        if(captureApi&&i==samples-1)captureApi->StartFrameCapture(RENDERDOC_DEVICEPOINTER_FROM_VKINSTANCE(lab.instance),nullptr);
#endif
        double ms=lab.frame(i==samples-1);
#ifdef RPL_RENDERDOC
        if(captureApi&&i==samples-1){captured=captureApi->EndFrameCapture(RENDERDOC_DEVICEPOINTER_FROM_VKINSTANCE(lab.instance),nullptr)!=0;if(!captured)throw std::runtime_error("RenderDoc capture failed");}
#endif
        if(i>=0){csv<<i<<","<<ms<<"\n";times.push_back(ms);}
        if(i>=0&&lab.stageTiming){stageCsv<<i;for(double value:lab.lastStageTimes)stageCsv<<","<<value;stageCsv<<"\n";}
    }
    if(captured)std::cout<<"RenderDoc capture saved; timing with capture is not benchmark data\n";
    lab.save(out/"frame.ppm");std::sort(times.begin(),times.end());
    std::ofstream info(out/"run.json");
    info<<"{\n\"mode\":\""<<mode<<"\",\n\"device\":\""<<lab.properties.deviceName
        <<"\",\n\"driver_version_raw\":"<<lab.properties.driverVersion<<",\n\"api_version_raw\":"<<lab.properties.apiVersion
        <<",\n\"width\":"<<lab.width<<",\n\"height\":"<<lab.height<<",\n\"samples\":"<<samples<<",\n\"warmup\":"<<warmup
        <<",\n\"timestamp_period_ns\":"<<lab.properties.limits.timestampPeriod<<",\n\"timestamp_valid_bits\":"<<lab.validBits
        <<",\n\"gpu_p50_ms\":"<<times[times.size()/2]<<",\n\"render_pass_count\":"<<lab.passes.size()
        <<",\n\"draw_count\":"<<(lab.inlineMode?1:lab.stageCount)
        <<",\n\"stage_timing_instrumented\":"<<(lab.stageTiming?"true":"false")
        <<",\n\"scope\":\"complete configured GPU rendering chain; excludes upload, readback, presentation and CPU wait\",\n\"platform\":\"Windows desktop GPU; not mobile hardware\"\n}\n";
    std::cout<<mode<<" / "<<lab.properties.deviceName<<" / GPU P50 "<<times[times.size()/2]<<" ms\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
