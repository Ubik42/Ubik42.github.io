#pragma once
#include <array>
#include <cmath>
#include <vector>

// Original CPU-built triangle scene; shared vertex bytes for every pass variant.
struct MeshVertex { float p[3], n[3], color[3], roughness, metallic, emission; };
inline std::vector<MeshVertex> makeMeshScene() {
    using V=std::array<float,3>;
    std::vector<MeshVertex> out;
    auto vertex=[&](V p,V n,V c,float rough,float metal,float emission=0.f){
        out.push_back({{p[0],p[1],p[2]},{n[0],n[1],n[2]},
            {c[0],c[1],c[2]},rough,metal,emission});
    };
    auto box=[&](V center,V half,V color,float rough,float metal){
        for(int axis=0;axis<3;++axis)for(int sign:{-1,1}){
            const int a=(axis+1)%3,b=(axis+2)%3;
            const int corners[6][2]={{-1,-1},{1,-1},{1,1},{-1,-1},{1,1},{-1,1}};
            for(const auto& corner:corners){V p=center,n{};p[axis]+=sign*half[axis];p[a]+=corner[0]*half[a];p[b]+=corner[1]*half[b];n[axis]=float(sign);vertex(p,n,color,rough,metal);}
        }
    };
    auto sphere=[&](V center,float radius,V color,float rough,float metal){
        constexpr int rings=32,slices=64;
        const int uv[6][2]={{0,0},{1,0},{1,1},{0,0},{1,1},{0,1}};
        for(int y=0;y<rings;y++)for(int x=0;x<slices;x++)for(const auto& offset:uv){
            float theta=(y+offset[1])*3.14159265f/rings,phi=(x+offset[0])*6.2831853f/slices;
            V n={std::sin(theta)*std::cos(phi),std::cos(theta),std::sin(theta)*std::sin(phi)},p{};
            for(int k=0;k<3;k++)p[k]=center[k]+radius*n[k];vertex(p,n,color,rough,metal);
        }
    };
    for(int z=-6;z<=4;z++)for(int x=-6;x<=6;x++){
        float tint=((x+z)&1)?1.f:.82f;
        box({float(x),-.09f,float(z)},{.485f,.09f,.485f},{.055f*tint,.075f*tint,.095f*tint},.48f,.15f);
    }
    box({0,.12f,0},{2,.12f,2},{.035f,.075f,.12f},.28f,.55f);
    box({0,.3f,0},{1.5f,.06f,1.5f},{.08f,.12f,.17f},.3f,.6f);
    sphere({0,1.65f,0},.82f,{.91f,.49f,.12f},.22f,.94f);
    sphere({-2.4f,.65f,-1.8f},.65f,{.07f,.32f,.55f},.32f,.75f);
    box({2.2f,.5f,-1.7f},{.48f,.5f,.48f},{.76f,.65f,.52f},.3f,.05f);
    for(float x:{-3.7f,3.7f}){
        for(float z:{-3.5f,0.f})box({x,1.9f,z},{.18f,1.9f,.18f},{.12f,.17f,.21f},.35f,.65f);
        box({x,3.9f,-1.75f},{.28f,.12f,2.1f},{.12f,.17f,.21f},.35f,.65f);
    }
    const int uv[6][2]={{0,0},{1,0},{1,1},{0,0},{1,1},{0,1}};
    for(int ring=0;ring<96;ring++)for(int side=0;side<12;side++)for(const auto& offset:uv){
        float a=(ring+offset[0])*6.2831853f/96,b=(side+offset[1])*6.2831853f/12;
        V n={std::cos(a)*std::cos(b),std::sin(b),std::sin(a)*std::cos(b)};
        V p={(1.18f+.045f*std::cos(b))*std::cos(a),.045f*std::sin(b),(1.18f+.045f*std::cos(b))*std::sin(a)};
        auto tilt=[](V v){return V{v[0],.82f*v[1]-.572f*v[2],.572f*v[1]+.82f*v[2]};};
        p=tilt(p);n=tilt(n);p[1]+=1.65f;vertex(p,n,{.1f,2.6f,3.4f},.4f,0,1);
    }
    return out;
}
