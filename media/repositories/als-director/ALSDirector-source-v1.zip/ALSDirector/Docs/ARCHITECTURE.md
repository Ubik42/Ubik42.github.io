# 运行合同

## 模块

| 文件 | 职责 |
| --- | --- |
| DirectorPlan | JSON 全量校验与允许动作集合，不接触场景 |
| DirectorRuntime | 会话、请求、队列、角色参数、移动与状态回传 |
| DirectorPresentation | 中文导演台、相机、测试场景、复位、事件记录与逐帧录制 |
| Tools/bridge.py | 文件通道，自动选择最新运行实例，或用 ALS_DIRECTOR_BRIDGE 指定目录 |
| Tools/acceptance.py | 独立宿主回归，计划固定标记为 test |

## 一次请求

```json
{"session_id":"运行实例ID","request_id":"本条请求ID","text":"走到青箱，像抱着重物，目光看向门口","move_target":"","look_at":"","remaining_steps":0}
```

游戏还会提供 `system_prompt` 和中文 `current_state`。场景目标只接受 `blue_box`、`red_target`、`door`。模型应基于这些目标解释自然语言，不能虚构场景对象。

```json
{"session_id":"运行实例ID","request_id":"本条请求ID","source":"codex","plan":{"steps":[{"action":"move_to","target":"blue_box","gait":"walk","style":"carrying","look_at":"door"}]}}
```

回复文件名为 `<request_id>.response.json`。`source=codex` 表示当前对话回传；`test` 表示测试夹具；`replay` 表示已保存计划回放。来源字段是展示标签，不是加密认证；通道只面向同机可信进程，不应暴露为公共网络服务。

## 状态与中断

- `move_to` 替换当前路线，可串联最多八步。到目标中心 155 cm 内算到达，以避开目标物体碰撞；30 秒游戏时间或连续 5 秒无有效进展会取消路线。
- 独立的 `adjust` 补丁仅改变提供的字段，保留当前目标与未完成队列。到达以后，后续步骤显式提供的字段仍可覆盖补丁值。
- `stop` 停止移动并清空队列，但不自动改变姿态或注视；“恢复正常”应同时提供 style、stance 和 look_at。
- 急停不经过模型，清空待回复编号并立即停止移动。它不会模拟刹车过渡，不能将急停画面视为自然减速。
- 新请求覆盖待回复编号，不取消已经在执行的路线；非法或超时的模型计划不改变原移动。输入后的等待期间需要停下时使用急停。
- `ready / waiting / executing / arrived / blocked / rejected / stopped / timeout` 记录最近控制事件；真实运动以 `moving`、`speed` 和 `move_target` 为准，拒绝补丁时角色仍可能继续原路线。

## 动画层

步态映射 ALS Walking / Running / Sprinting；站姿映射 Standing / Crouching；表现映射 Default / Box / Injured，警戒使用 DesiredAiming。注视通过平滑更新控制朝向进入 ALS 视线系统，受 ALS 原动画范围限制，不保证头部能朝身后无限旋转。现有脚部、转向与道具附着逻辑不在本项目重写。

## 录制

`record-start` 将游戏固定为 30 fps 步长，每帧只截取游戏窗口的最终图像，不捕获桌面其他应用；`record-stop` 恢复原帧率设置。每次录制在 Saved/Recordings 下生成独立目录，最多 5400 帧。png 序列可用 FFmpeg 编码为 H.264。录制是固定步长的实机渲染，不代表机器以实时 30 fps 完成截图，也不是模型延迟测试。

事件日志为 `<session_id>.events.jsonl`，记录 UTC、事件、详情、执行来源和录制帧号。验证报告保存游戏实际位置、速度、姿态及队列，而非仅记录发送了什么命令。
