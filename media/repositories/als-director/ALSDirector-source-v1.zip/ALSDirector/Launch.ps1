$projectPath = Join-Path $PSScriptRoot 'ALSDirector.uproject'
$packagedPath = Join-Path $PSScriptRoot 'Releases/v1/Windows/ALSDirector.exe'
if (Test-Path -LiteralPath $packagedPath) {
    & $packagedPath -windowed -ResX=1920 -ResY=1080 -NoSplash
} else {
    $enginePath = if ($env:UE58_ROOT) { $env:UE58_ROOT } else { 'C:/Program Files/Epic Games/UE_5.8' }
    $editorPath = Join-Path $enginePath 'Engine/Binaries/Win64/UnrealEditor.exe'
    & $editorPath $projectPath /Game/DirectorStage -game -windowed -ResX=1920 -ResY=1080 -NoSplash
}
