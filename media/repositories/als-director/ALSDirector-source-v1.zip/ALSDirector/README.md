# ALS 动作导演

UE 5.8.1、ALS-Refactored 4.18，自然语言驱动现有角色动画的演示工程。v1 提供中文导演台、跟随与全景镜头、移动队列、途中表现补丁、急停复位、状态回传与固定步长录制。

ALS 资源固定上游提交 `b754d6f0f2bb03741d301f8fb88077ebfe561e17`，完整资源归档保留在 `Saved/als-upstream.zip`。本机参考仓为稀疏检出，不能仅复制其已有 Content 代替完整插件资源。

## 接入方式

当前 Codex 对话中的 GPT 读取游戏请求，结合角色状态生成 JSON 动作计划。游戏检查计划后执行。`Tools/bridge.py` 只传递文件，不调用模型、不做关键词匹配，也不包含伪装成模型回复的预设解析器。录制时需要保持 Codex 对话活动；独立运行游戏不会自行获得 GPT 回复。

```text
游戏输入 → Saved/DirectorBridge/request.json → 当前 Codex 对话
当前 Codex 对话 → <request_id>.response.json → 校验 → ALS 状态与移动
游戏状态 → Saved/DirectorBridge/state.json → 当前 Codex 对话
```

## 启动

在 PowerShell 中执行 `./Launch.ps1`，优先启动 `Releases/v1/Windows/ALSDirector.exe`，没有独立构建时使用 UE Editor 的 Game 模式。独立程序已在本机启动与回归验证；尚未验证无开发环境的干净机器。

从源码包重建：安装 UE 5.8.1 和带 C++ 工作负载的 Visual Studio，执行 `./Tools/setup.ps1`。默认引擎路径为 `C:/Program Files/Epic Games/UE_5.8`，可用 `UE58_ROOT` 覆盖。脚本从固定上游提交获取完整 ALS 插件，保留许可证，并构建 Editor 模块。场景地图与项目材质已经包含在源码包中。

打包 Windows：

```powershell
& "$env:UE58_ROOT/Engine/Build/BatchFiles/RunUAT.bat" BuildCookRun -project="$PWD/ALSDirector.uproject" -noP4 -platform=Win64 -clientconfig=Development -build -cook -stage -pak -archive -archivedirectory="$PWD/Releases/v1" -map=DirectorStage -unattended
```

上例执行前需要设置 `UE58_ROOT`。独立包供本机展示，源码下载包不捆绑引擎或第三方动画资产。

## 演示操作

在游戏中发送一句话，再在本 Codex 对话中要求处理待执行指令。也可直接在对话中描述动作，由助手通过桥发送并回传计划。

```powershell
python Tools/bridge.py request --text '慢慢走到蓝色箱子'
python Tools/bridge.py read
python Tools/bridge.py state
python Tools/bridge.py stop
python Tools/bridge.py reset
python Tools/bridge.py camera
```

读取请求后，助手必须使用该请求的完整 `request_id` 回传，不能使用过期请求。

实际动作计划形态：

```json
{"steps":[{"action":"move_to","target":"blue_box","gait":"walk","style":"carrying","stance":"stand","look_at":"door"}]}
```

其中 `move_to` 表示走到目标附近；`gait` 是速度档位，`style` 是现有动画姿态，`look_at` 是注视目标。省略字段保留当前值。`adjust` 只修改表现，不取消移动；`stop` 停止移动。连续动作最多 8 步，只有移动动作可以等待到达后再执行下一步。

| 字段 | 支持值 |
| --- | --- |
| action | move_to、adjust、stop |
| target / look_at | blue_box 蓝箱、red_target 红色目标、door 门口；look_at 另支持 none |
| gait | walk、run、sprint |
| style | normal、alert、carrying、injured |
| stance | stand、crouch |

`style=carrying` 复用 ALS 抱箱动画，`injured` 复用受伤动画，`alert` 开启瞄准状态。这里不生成新动画，不模拟重量，不提供障碍绕行。游戏使用直线移动，到目标 155 cm 内停止；受阻或超时会取消后续动作。

## 安全与验证

模型不能执行任意代码。未知字段、非法枚举、空计划和不支持的序列会被拒绝，整份计划通过检查后才生效。会话 ID 和请求 ID 隔离旧回复；立即停止使正在等待的回复失效。请求等待上限 180 秒，等待期间原移动继续。

自动化测试入口：`ALSDirector.Plan.Validation`。运行证据位于 `Saved/Logs`；运行状态包含真实位置、速度、动画实例是否加载、实际 ALS 步态和叠加姿态。

`python Tools/runtime_checks.py` 执行四项协议回归：移动、途中修改保留目标、非法计划拒绝、急停后丢弃旧回复。该脚本使用明确标注的测试夹具，不是自然语言理解器。测试会改变当前角色状态，结果保存在 `Saved/DirectorBridge/runtime-test-results.json`。

当前完整验收使用 `python Tools/acceptance.py --record`：十二项独立程序回归与录像，已通过。脚本会先结束已有录制、复位场景，再运行测试；失败时保留已经完成的结果，并尝试停止录制和角色。`Media/acceptance.json` 是剔除本机路径的公开结果。

## 演示与录制

- `Media/showcase.mp4`：当前 GPT 对话真实回传计划的实机片段，剪去部分等待。
- `Media/showcase-uncut.mp4`：同一轮未剪辑记录，保留等待。
- `Media/regression.mp4`：成功的十二项回归片段，来源明确显示为测试夹具。
- `Docs/ARCHITECTURE.md`：字段语义、异步执行限制、日志与来源边界。

```powershell
python Tools/bridge.py record-start
python Tools/bridge.py record-stop
```

逐帧 PNG 保存到运行程序的 `Saved/Recordings`。独立构建的 Saved 在 `Releases/v1/Windows/ALSDirector/Saved`，Editor 模式在工程 Saved；桥默认自动选择最新状态文件。指定实例可设置 `ALS_DIRECTOR_BRIDGE`。

录制固定游戏步长为 1/30 秒，结束后恢复帧率设置。它是实机渲染，不等于截图以实时 30 fps 完成，也不能据此测量 GPT 响应延迟。原运动在等待语言回复期间继续，短路线可能在补丁返回前已完成。
