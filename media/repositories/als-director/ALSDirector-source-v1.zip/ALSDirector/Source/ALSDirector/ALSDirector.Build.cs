using UnrealBuildTool;
public class ALSDirector : ModuleRules
{
    public ALSDirector(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new[]{"Core","CoreUObject","Engine","InputCore","ALS","GameplayTags"});
        PrivateDependencyModuleNames.AddRange(new[]{"Slate","SlateCore","Json","JsonUtilities"});
    }
}
