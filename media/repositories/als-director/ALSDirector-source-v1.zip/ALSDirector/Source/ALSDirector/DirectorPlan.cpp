#include "DirectorPlan.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

namespace
{
bool OneOf(const FString& Value, std::initializer_list<const TCHAR*> Values)
{
    for (const TCHAR* Item : Values) if (Value == Item) return true;
    return false;
}
}

bool DirectorPlan::Parse(const FString& Json, TArray<FDirectorStep>& Out, FString& Error)
{
    Out.Reset();
    Error.Reset();
    if (Json.Len() > 16384) { Error = TEXT("计划过大"); return false; }
    TSharedPtr<FJsonObject> Root;
    if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Json), Root) || !Root.IsValid())
    { Error = TEXT("模型没有返回合法 JSON"); return false; }
    const TArray<TSharedPtr<FJsonValue>>* Steps;
    if (Root->Values.Num() != 1 || !Root->TryGetArrayField(TEXT("steps"), Steps) || Steps->IsEmpty() || Steps->Num() > 8)
    { Error = TEXT("计划必须只含 steps，且包含 1–8 步"); return false; }
    TArray<FDirectorStep> Validated;
    for (const auto& Value : *Steps)
    {
        const TSharedPtr<FJsonObject>* Obj;
        if (!Value->TryGetObject(Obj)) { Error = TEXT("步骤必须是对象"); return false; }
        for (const auto& Pair : (*Obj)->Values)
        {
            const FString Key(*Pair.Key);
            if (!OneOf(Key, {TEXT("action"), TEXT("target"), TEXT("gait"), TEXT("style"), TEXT("stance"), TEXT("look_at")}) || Pair.Value->Type != EJson::String)
            { Error = TEXT("未知字段或字段不是字符串: ") + Key; return false; }
        }
        FDirectorStep S;
        (*Obj)->TryGetStringField(TEXT("action"), S.Action);
        (*Obj)->TryGetStringField(TEXT("target"), S.Target);
        (*Obj)->TryGetStringField(TEXT("gait"), S.Gait);
        (*Obj)->TryGetStringField(TEXT("style"), S.Style);
        (*Obj)->TryGetStringField(TEXT("stance"), S.Stance);
        (*Obj)->TryGetStringField(TEXT("look_at"), S.LookAt);
        if (!OneOf(S.Action, {TEXT("move_to"), TEXT("adjust"), TEXT("stop")}))
        { Error = TEXT("不支持该动作"); return false; }
        if ((S.Action == TEXT("move_to") && !OneOf(S.Target, {TEXT("blue_box"),TEXT("red_target"),TEXT("door")})) ||
            (S.Action != TEXT("move_to") && !S.Target.IsEmpty()))
        { Error = TEXT("移动目标无效"); return false; }
        if (!OneOf(S.Gait, {TEXT(""),TEXT("walk"),TEXT("run"),TEXT("sprint")}) ||
            !OneOf(S.Style, {TEXT(""),TEXT("normal"),TEXT("alert"),TEXT("carrying"),TEXT("injured")}) ||
            !OneOf(S.Stance, {TEXT(""),TEXT("stand"),TEXT("crouch")}) ||
            !OneOf(S.LookAt, {TEXT(""),TEXT("none"),TEXT("blue_box"),TEXT("red_target"),TEXT("door")}))
        { Error = TEXT("步态、姿态或注视目标不在支持范围"); return false; }
        // An adjust has no duration. Only move_to can gate a subsequent action.
        if (Validated.Num() > 0 && Validated.Last().Action != TEXT("move_to"))
        { Error = TEXT("只有移动步骤可以等待后续步骤；同时修改请放在同一步"); return false; }
        Validated.Add(MoveTemp(S));
    }
    Out = MoveTemp(Validated);
    return true;
}

FString DirectorPlan::SystemPrompt()
{
    return TEXT("You direct one ALS character. Return ONLY a JSON object with steps (1-8). ")
        TEXT("Each step has action: move_to|adjust|stop; optional gait: walk|run|sprint, style: normal|alert|carrying|injured, stance: stand|crouch, look_at: none|blue_box|red_target|door. ")
        TEXT("move_to requires target: blue_box|red_target|door. Other actions must omit target. ")
        TEXT("Scene: blue_box=蓝色箱子, red_target=红色目标, door=门口. No other objects exist. ")
        TEXT("Omitted fields preserve current state. adjust changes current movement without cancelling its destination. ")
        TEXT("move_to replaces the current destination and waits for arrival before the next step. adjust/stop must be the last step. ")
        TEXT("stop stops motion. Stop and relax means action stop, style normal, stance stand, look_at none. ")
        TEXT("carrying uses existing ALS box carrying animation, not a generated or backpack animation. ")
        TEXT("No jumping, arbitrary animation generation, intensity control or obstacle pathfinding is supported. ")
        TEXT("For unsupported or ambiguous requests return {\"steps\":[]} so the client rejects without acting. ")
        TEXT("Interpret Chinese and English instructions. Do not produce code or extra keys.");
}
