#pragma once
#include "CoreMinimal.h"

// Patch semantics: omitted fields preserve the running state. Each complete
// plan is validated before any state changes, including future steps.
struct FDirectorStep
{
    FString Action;
    FString Target;
    FString Gait;
    FString Style;
    FString Stance;
    FString LookAt;
};

namespace DirectorPlan
{
    bool Parse(const FString& Json, TArray<FDirectorStep>& Out, FString& Error);
    FString SystemPrompt();
}
