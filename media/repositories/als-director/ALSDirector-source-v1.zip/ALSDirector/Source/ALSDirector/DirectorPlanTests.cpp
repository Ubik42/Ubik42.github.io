#include "DirectorPlan.h"
#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FDirectorPlanTest, "ALSDirector.Plan.Validation", EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FDirectorPlanTest::RunTest(const FString& Parameters)
{
    TArray<FDirectorStep> Steps;
    FString Error;
    TestTrue(TEXT("Valid sequence"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"move_to","target":"blue_box","gait":"walk"},{"action":"stop","style":"normal"}]})"), Steps, Error));
    TestEqual(TEXT("Two steps"), Steps.Num(), 2);
    TestFalse(TEXT("Unknown action"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"execute"}]})"), Steps, Error));
    TestEqual(TEXT("Failure clears output"), Steps.Num(), 0);
    TestFalse(TEXT("Unknown target"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"move_to","target":"moon"}]})"), Steps, Error));
    TestFalse(TEXT("No partial plan"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"move_to","target":"door"},{"action":"stop","gait":"fly"}]})"), Steps, Error));
    TestEqual(TEXT("Atomic validation"), Steps.Num(), 0);
    TestFalse(TEXT("Reject empty"), DirectorPlan::Parse(TEXT(R"({"steps":[]})"), Steps, Error));
    TestFalse(TEXT("Reject unknown field"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"stop","code":"test"}]})"), Steps, Error));
    TestFalse(TEXT("Reject invalid sequencing"), DirectorPlan::Parse(TEXT(R"({"steps":[{"action":"adjust"},{"action":"stop"}]})"), Steps, Error));
    return true;
}
#endif
