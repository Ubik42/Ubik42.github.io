#include "DirectorRuntime.h"
#include "AlsCharacter.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/DirectionalLight.h"
#include "Engine/PointLight.h"
#include "Engine/GameViewportClient.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/App.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Styling/CoreStyle.h"

namespace
{
FString TargetName(const FString& V)
{
    if (V == TEXT("blue_box")) return TEXT("01  青色箱子");
    if (V == TEXT("red_target")) return TEXT("02  红色标柱");
    if (V == TEXT("door")) return TEXT("03  绿色门口");
    return TEXT("无");
}
const FLinearColor Cyan(0.19f, 0.92f, 0.80f);
const FLinearColor Muted(0.61f, 0.70f, 0.77f);
}

void ADirectorController::RecordEvent(const FString& Event, const FString& Detail) const
{
    auto Json = MakeShared<FJsonObject>();
    Json->SetStringField(TEXT("utc"), FDateTime::UtcNow().ToIso8601());
    Json->SetStringField(TEXT("session_id"), SessionId);
    Json->SetStringField(TEXT("request_id"), PendingId);
    Json->SetStringField(TEXT("event"), Event);
    Json->SetStringField(TEXT("detail"), Detail);
    Json->SetStringField(TEXT("origin"), LastOrigin);
    Json->SetNumberField(TEXT("recording_frame"), RecordingFrame);
    FString Line;
    FJsonSerializer::Serialize(Json, TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&Line));
    FFileHelper::SaveStringToFile(Line + TEXT("\n"), *(GetBridgeDirectory() / (SessionId + TEXT(".events.jsonl"))),
        FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_Append);
}

void ADirectorController::ResetStage()
{
    EmergencyStop();
    if (auto* C = Character())
    {
        C->SetActorLocationAndRotation(FVector(-450,-300,100), FRotator::ZeroRotator, false, nullptr, ETeleportType::TeleportPhysics);
        FDirectorStep Initial;
        Initial.Gait = TEXT("walk"); Initial.Style = TEXT("normal"); Initial.Stance = TEXT("stand"); Initial.LookAt = TEXT("none");
        ApplyModifiers(Initial);
    }
    StepIndex = 0;
    LastText.Reset(); LastPlan.Reset(); LastOrigin.Reset();
    Phase = TEXT("ready"); Status = TEXT("场景已复位，等待新的导演指令");
    RecordEvent(TEXT("reset"), Status);
}

void ADirectorController::ToggleCamera() { CameraMode = CameraMode == TEXT("follow") ? TEXT("overview") : TEXT("follow"); }
void ADirectorController::ToggleDebug() { bDebug = !bDebug; }

void ADirectorController::UpdateCamera(float Dt)
{
    if (!DirectorCamera.IsValid()) return;
    FVector Location, Focus;
    if (CameraMode == TEXT("overview"))
    {
        Location = FVector(-1250,-1600,1300);
        Focus = FVector(-130,100,0);
    }
    else
    {
        const FVector P = Character() ? Character()->GetActorLocation() : FVector(-450,-300,100);
        Location = P + FVector(-470,-710,300);
        Focus = P + FVector(-150,95,25);
    }
    auto* Camera = DirectorCamera.Get();
    Camera->SetActorLocation(FMath::VInterpTo(Camera->GetActorLocation(), Location, Dt, 3.0f));
    Camera->SetActorRotation(FMath::RInterpTo(Camera->GetActorRotation(), (Focus-Location).Rotation(), Dt, 3.0f));
}

void ADirectorController::BeginRecording()
{
    if (bRecording) return;
    RecordingDirectory = FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("Recordings") / FGuid::NewGuid().ToString(EGuidFormats::Digits));
    IFileManager::Get().MakeDirectory(*RecordingDirectory, true);
    RecordingFrame = 0;
    bRecording = true;
    bPreviousFixedFrameRate = GEngine->bUseFixedFrameRate;
    PreviousFixedFrameRate = GEngine->FixedFrameRate;
    GEngine->bUseFixedFrameRate = true;
    GEngine->FixedFrameRate = 30.0f;
    FApp::SetFixedDeltaTime(1.0 / 30.0);
    FApp::SetUseFixedTimeStep(true);
    ConsoleCommand(TEXT("t.MaxFPS 30"));
    RecordEvent(TEXT("record_start"), RecordingDirectory);
}

void ADirectorController::EndRecording()
{
    if (!bRecording) return;
    bRecording = false;
    GEngine->bUseFixedFrameRate = bPreviousFixedFrameRate;
    GEngine->FixedFrameRate = PreviousFixedFrameRate;
    FApp::SetUseFixedTimeStep(false);
    ConsoleCommand(TEXT("t.MaxFPS 60"));
    RecordEvent(TEXT("record_end"), FString::Printf(TEXT("%d frames, 30 fps simulation capture"), RecordingFrame));
}

FString ADirectorController::GetDirectorSummary() const
{
    const FString G = Gait == TEXT("walk") ? TEXT("步行") : Gait == TEXT("run") ? TEXT("跑步") : TEXT("冲刺");
    const FString S = Style == TEXT("carrying") ? TEXT("抱箱") : Style == TEXT("injured") ? TEXT("受伤") : Style == TEXT("alert") ? TEXT("警戒") : TEXT("自然");
    return G + TEXT("  /  ") + S + TEXT("  /  ") + (Stance == TEXT("crouch") ? TEXT("蹲伏") : TEXT("站立"));
}

void ADirectorController::BuildPanel()
{
    if (!GEngine || !GEngine->GameViewport) return;
    const auto Font = FCoreStyle::GetDefaultFontStyle("Regular", 17);
    const auto Small = FCoreStyle::GetDefaultFontStyle("Regular", 13);
    const auto Bold = FCoreStyle::GetDefaultFontStyle("Bold", 22);
    const auto* Brush = FCoreStyle::Get().GetBrush("WhiteBrush");
    auto Text = [&](const FString& Value, const FSlateFontInfo& F, FLinearColor Color = FLinearColor::White) -> TSharedRef<SWidget>
    { return SNew(STextBlock).Text(FText::FromString(Value)).Font(F).ColorAndOpacity(Color).AutoWrapText(true); };
    auto Button = [&](const FString& Label, TFunction<void()> Action, FLinearColor Color = FLinearColor(0.09f,0.15f,0.18f)) -> TSharedRef<SWidget>
    { return SNew(SButton).ButtonColorAndOpacity(Color).ContentPadding(FMargin(12,10)).OnClicked_Lambda([Action](){Action();return FReply::Handled();})[Text(Label, Font)]; };

    auto Side = SNew(SVerticalBox);
    Side->AddSlot().AutoHeight()[Text(TEXT("导演台"), Bold)];
    Side->AddSlot().AutoHeight().Padding(0,6,0,20)[Text(TEXT("描述意图，让角色开始表演。"), Small, Muted)];
    Side->AddSlot().AutoHeight()[SAssignNew(Input, SEditableTextBox).Font(Font).Padding(FMargin(10)).HintText(FText::FromString(TEXT("走向青箱，抱箱并看向门口"))).OnTextCommitted_Lambda([this](const FText& V,ETextCommit::Type T){if(T==ETextCommit::OnEnter) SubmitText(V.ToString());})];
    Side->AddSlot().AutoHeight().Padding(0,8)[Button(TEXT("发送导演指令  ↗"), [this](){SubmitText(Input->GetText().ToString());}, FLinearColor(0.035f,0.30f,0.25f))];
    Side->AddSlot().AutoHeight()[Button(TEXT("立即停止"), [this](){EmergencyStop();}, FLinearColor(0.32f,0.055f,0.055f))];
    Side->AddSlot().AutoHeight().Padding(0,22,0,6)[Text(TEXT("角色表现"), Small, Muted)];
    Side->AddSlot().AutoHeight()[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(GetDirectorSummary());}).Font(Bold).ColorAndOpacity(Cyan)];
    Side->AddSlot().AutoHeight().Padding(0,12)[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(FString::Printf(TEXT("速度  %.0f cm/s\n目的地  %s\n注视  %s"),Character()?Character()->GetVelocity().Size2D():0,*TargetName(MoveTarget),*TargetName(LookAt)));}).Font(Font)];
    Side->AddSlot().AutoHeight().Padding(0,5,0,12)[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(Status);}).Font(Small).ColorAndOpacity(Cyan).AutoWrapText(true)];
    Side->AddSlot().AutoHeight()[Text(TEXT("01 青箱   /   02 红柱   /   03 门口"), Small, Muted)];
    Side->AddSlot().AutoHeight().Padding(0,18,0,8)[SNew(SHorizontalBox)
        +SHorizontalBox::Slot().FillWidth(1).Padding(0,0,4,0)[Button(TEXT("切换镜头"),[this](){ToggleCamera();})]
        +SHorizontalBox::Slot().FillWidth(1)[Button(TEXT("场景复位"),[this](){ResetStage();})]];
    Side->AddSlot().AutoHeight()[Button(TEXT("显示 / 隐藏调试线"),[this](){ToggleDebug();})];
    Side->AddSlot().AutoHeight().Padding(0,18,0,6)[Text(TEXT("执行来源与结构化计划"),Small,Muted)];
    Side->AddSlot().AutoHeight()[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(LastOrigin.IsEmpty()?TEXT("尚未收到计划"):LastOrigin);}).Font(Small).ColorAndOpacity(Cyan)];
    Side->AddSlot().FillHeight(1).Padding(0,8)[SNew(SScrollBox)+SScrollBox::Slot()[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(LastPlan);}).Font(Small).AutoWrapText(true).ColorAndOpacity(Muted)]];
    Side->AddSlot().AutoHeight()[Text(TEXT("当前 Codex 对话桥接 · 非独立模型服务\nALS 现有动画 · 非文本生成动画"),Small,Muted)];

    Panel = SNew(SOverlay)
        +SOverlay::Slot().HAlign(HAlign_Left).VAlign(VAlign_Top).Padding(40,30)[SNew(SBox).WidthOverride(720)[SNew(SVerticalBox)
            +SVerticalBox::Slot().AutoHeight()[Text(TEXT("动作导演"), FCoreStyle::GetDefaultFontStyle("Bold",40))]
            +SVerticalBox::Slot().AutoHeight().Padding(0,6)[Text(TEXT("自然语言 × 运行时角色表现"),Font,Cyan)]]]
        +SOverlay::Slot().HAlign(HAlign_Left).VAlign(VAlign_Bottom).Padding(40,0,420,40)[SNew(SBox).WidthOverride(650)[SNew(SBorder).BorderImage(Brush).BorderBackgroundColor(FLinearColor(0.01f,0.018f,0.025f,0.96f)).Padding(22)[SNew(SVerticalBox)
            +SVerticalBox::Slot().AutoHeight()[Text(TEXT("当前导演指令"),Small,Cyan)]
            +SVerticalBox::Slot().AutoHeight().Padding(0,8)[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(LastText.IsEmpty()?TEXT("等待一句话，开始新的表演。"):LastText);}).Font(Bold).AutoWrapText(true)]]]]
        +SOverlay::Slot().HAlign(HAlign_Right).Padding(0,24,24,24)[SNew(SBox).WidthOverride(365)[SNew(SBorder).BorderImage(Brush).BorderBackgroundColor(FLinearColor(0.015f,0.024f,0.034f)).Padding(22)[Side]]];
    GEngine->GameViewport->AddViewportWidgetContent(Panel.ToSharedRef(),10);
}

void ADirectorGameMode::BuildStage()
{
    auto* Cube = LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Cube.Cube"));
    auto* Material = LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/DirectorMaterials/M_Stage.M_Stage"));
    if (!Material) Material = LoadObject<UMaterialInterface>(nullptr,TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    auto Box = [&](FVector P,FVector Scale,FLinearColor Color)
    {
        auto* A=GetWorld()->SpawnActor<AStaticMeshActor>(P,FRotator::ZeroRotator);
        A->SetMobility(EComponentMobility::Movable);
        A->GetStaticMeshComponent()->SetStaticMesh(Cube);
        A->SetActorScale3D(Scale);
        auto* M=UMaterialInstanceDynamic::Create(Material,A);
        M->SetVectorParameterValue(TEXT("Color"),Color);
        A->GetStaticMeshComponent()->SetMaterial(0,M);
        return A;
    };
    const FLinearColor Floor(0.065f,0.095f,0.12f), Line(0.13f,0.19f,0.22f), Teal(0.025f,0.7f,0.64f), Red(0.8f,0.1f,0.06f), Green(0.16f,0.6f,0.29f);
    Box(FVector(0,0,-25),FVector(23,23,0.5),Floor);
    for(int32 I=-10; I<=10; ++I)
    {
        auto* X=Box(FVector(I*100,0,0.1f),FVector(0.012f,22,0.002f),Line);
        auto* Y=Box(FVector(0,I*100,0.1f),FVector(22,0.012f,0.002f),Line);
        X->SetActorEnableCollision(false); Y->SetActorEnableCollision(false);
    }
    Box(FVector(550,-400,45),FVector(0.9f,0.9f,0.9f),Teal);
    Box(FVector(600,430,85),FVector(0.55f,0.55f,1.7f),Red);
    for(float Y:{310.f,490.f}) Box(FVector(-550,Y,125),FVector(0.22f,0.22f,2.5f),Green);
    Box(FVector(-550,400,250),FVector(0.22f,2.02f,0.22f),Green);
    for(int32 I=0;I<3;++I)
    {
        FVector P=I==0?FVector(550,-400,110):I==1?FVector(600,430,195):FVector(-550,400,280);
        auto* A=GetWorld()->SpawnActor<AActor>();
        auto* T=NewObject<UTextRenderComponent>(A); A->SetRootComponent(T); T->RegisterComponent();
        T->SetWorldLocation(P); T->SetWorldRotation(FRotator(0,-125,0));
        T->SetText(FText::FromString(FString::Printf(TEXT("0%d"),I+1)));T->SetWorldSize(35);T->SetHorizontalAlignment(EHTA_Center);
    }
    // Simple architectural rhythm; no generated art or third-party environment assets.
    for(int32 I=-4;I<=4;++I) Box(FVector(1080,I*240,150),FVector(0.18f,0.4f,3),FLinearColor(0.12f,0.19f,0.24f));
    Box(FVector(1080,0,300),FVector(0.18f,22,0.2f),Line);
    auto* Sun=GetWorld()->SpawnActor<ADirectionalLight>(FVector(0,0,800),FRotator(-55,-35,0));
    Sun->GetLightComponent()->SetMobility(EComponentMobility::Movable);
    Sun->GetLightComponent()->SetIntensity(3.5f);
    auto Fill=[&](FVector P,FLinearColor Color,float Intensity)
    {
        auto* L=GetWorld()->SpawnActor<APointLight>(P,FRotator::ZeroRotator);
        auto* C=Cast<UPointLightComponent>(L->GetLightComponent());
        C->SetMobility(EComponentMobility::Movable);C->SetLightColor(Color);C->SetIntensity(Intensity);C->SetAttenuationRadius(2800);C->SetCastShadows(false);
    };
    Fill(FVector(-600,-700,450),FLinearColor(0.6f,0.8f,1),80000);
    Fill(FVector(600,300,600),FLinearColor(1,0.8f,0.6f),100000);
}
