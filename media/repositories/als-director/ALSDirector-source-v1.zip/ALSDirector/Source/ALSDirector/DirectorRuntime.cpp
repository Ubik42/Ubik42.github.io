#include "DirectorRuntime.h"
#include "UObject/ConstructorHelpers.h"
#include "AlsCharacter.h"
#include "Utility/AlsGameplayTags.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Engine/World.h"
#include "Engine/GameViewportClient.h"
#include "Engine/Engine.h"
#include "UnrealClient.h"
#include "EngineUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerStart.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "DrawDebugHelpers.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/App.h"
#include "Misc/DateTime.h"
#include "HAL/IConsoleManager.h"
#include "HAL/FileManager.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonReader.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Styling/CoreStyle.h"

DEFINE_LOG_CATEGORY_STATIC(LogDirector, Log, All);

namespace
{
FString JsonString(const TSharedRef<FJsonObject>& Object)
{
    FString Result;
    FJsonSerializer::Serialize(Object, TJsonWriterFactory<>::Create(&Result));
    return Result;
}
void SaveJson(const FString& Path, const TSharedRef<FJsonObject>& Object)
{
    // Consumer sees either the previous document or the complete new one.
    const FString Temp = Path + TEXT(".tmp");
    if (FFileHelper::SaveStringToFile(JsonString(Object), *Temp, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM))
        IFileManager::Get().Move(*Path, *Temp, true, true);
}
FString LocalGait(const FString& V)
{
    return V == TEXT("walk") ? TEXT("步行") : V == TEXT("run") ? TEXT("跑步") : TEXT("冲刺");
}
FString LocalStyle(const FString& V)
{
    if (V == TEXT("alert")) return TEXT("警戒 / 瞄准朝向");
    if (V == TEXT("carrying")) return TEXT("抱箱 / ALS 既有姿态");
    if (V == TEXT("injured")) return TEXT("受伤 / ALS 既有姿态");
    return TEXT("正常");
}
}

ADirectorController::ADirectorController()
{
    PrimaryActorTick.bCanEverTick = true;
    bAutoManageActiveCameraTarget = false;
}

AAlsCharacter* ADirectorController::Character() const { return Cast<AAlsCharacter>(GetPawn()); }
FString ADirectorController::GetBridgeDirectory() const
{
    return FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("DirectorBridge"));
}

void ADirectorController::BeginPlay()
{
    Super::BeginPlay();
    SessionId = FGuid::NewGuid().ToString(EGuidFormats::Digits);
    Targets.Add(TEXT("blue_box"), FVector(550, -400, 0));
    Targets.Add(TEXT("red_target"), FVector(600, 430, 0));
    Targets.Add(TEXT("door"), FVector(-550, 400, 0));
    IFileManager::Get().MakeDirectory(*GetBridgeDirectory(), true);
    if (auto* C = Character())
    {
        C->SetActorLocation(FVector(-450, -300, 100));
        C->GetMesh()->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
        FDirectorStep Initial;
        Initial.Gait = Gait; Initial.Style = Style; Initial.Stance = Stance;
        ApplyModifiers(Initial);
    }
    auto* Camera = GetWorld()->SpawnActor<ACameraActor>();
    DirectorCamera = Camera;
    Camera->GetCameraComponent()->SetFieldOfView(55);
    Camera->GetCameraComponent()->bConstrainAspectRatio = false;
    Camera->GetCameraComponent()->PostProcessSettings.bOverride_AutoExposureBias = true;
    Camera->GetCameraComponent()->PostProcessSettings.AutoExposureBias = 0.0f;
    SetViewTarget(Camera);
    UpdateCamera(100);
    ConsoleCommand(TEXT("t.MaxFPS 60"));
    bShowMouseCursor = true;
    SetInputMode(FInputModeGameAndUI().SetHideCursorDuringCapture(false));
    BuildPanel();
    WriteState();
    UE_LOG(LogDirector, Display, TEXT("BRIDGE_READY %s"), *GetBridgeDirectory());
}

void ADirectorController::EndPlay(const EEndPlayReason::Type Reason)
{
    EndRecording();
    if (Panel.IsValid() && GEngine && GEngine->GameViewport) GEngine->GameViewport->RemoveViewportWidgetContent(Panel.ToSharedRef());
    auto Closed = MakeShared<FJsonObject>();
    Closed->SetBoolField(TEXT("running"), false);
    Closed->SetStringField(TEXT("session_id"), SessionId);
    SaveJson(GetBridgeDirectory() / TEXT("state.json"), Closed);
    Super::EndPlay(Reason);
}

void ADirectorController::SubmitText(const FString& Text)
{
    const FString Clean = Text.TrimStartAndEnd();
    if (Clean.IsEmpty() || Clean.Len() > 1000) { Status = TEXT("请输入 1–1000 个字符"); return; }
    LastText = Clean;
    Phase = TEXT("waiting");
    PendingId = FGuid::NewGuid().ToString(EGuidFormats::Digits);
    RequestTime = FPlatformTime::Seconds();
    auto Request = MakeShared<FJsonObject>();
    Request->SetStringField(TEXT("session_id"), SessionId);
    Request->SetStringField(TEXT("request_id"), PendingId);
    Request->SetStringField(TEXT("text"), Clean);
    Request->SetStringField(TEXT("system_prompt"), DirectorPlan::SystemPrompt());
    Request->SetStringField(TEXT("current_state"), GetTelemetry());
    Request->SetStringField(TEXT("move_target"), MoveTarget);
    Request->SetStringField(TEXT("look_at"), LookAt);
    Request->SetNumberField(TEXT("remaining_steps"), FMath::Max(0, Plan.Num() - StepIndex));
    SaveJson(GetBridgeDirectory() / TEXT("request.json"), Request);
    Status = TEXT("等待当前 Codex 对话中的 GPT 回传；原动作继续，可立即停止");
    WriteState();
    RecordEvent(TEXT("request"), Clean);
    UE_LOG(LogDirector, Display, TEXT("REQUEST %s %s"), *PendingId, *Clean);
}

void ADirectorController::EmergencyStop()
{
    PendingId.Reset();
    Plan.Reset();
    bMoving = false;
    MoveTarget.Reset();
    Phase = TEXT("stopped");
    if (auto* C = Character()) { C->ConsumeMovementInputVector(); C->GetCharacterMovement()->StopMovementImmediately(); }
    Status = TEXT("已立即停止；待返回的旧指令已失效");
    WriteState();
    RecordEvent(TEXT("stop"), Status);
}

bool ADirectorController::ApplyPlan(const FString& Json, const FString& Origin)
{
    TArray<FDirectorStep> Candidate;
    FString Error;
    if (!DirectorPlan::Parse(Json, Candidate, Error))
    { Status = TEXT("计划已拒绝：") + Error; Phase = TEXT("rejected"); ++RejectedCount; RecordEvent(TEXT("rejected"), Error); UE_LOG(LogDirector, Warning, TEXT("REJECT %s"), *Error); return false; }
    if (!Character()) { Status = TEXT("没有 ALS 角色，无法执行"); return false; }
    LastPlan = Json;
    LastOrigin = Origin;
    ++AcceptedCount;
    Phase = TEXT("executing");
    // A patch affects the current pose without replacing the queued route.
    if (Candidate.Num() == 1 && Candidate[0].Action == TEXT("adjust"))
    {
        ApplyModifiers(Candidate[0]);
        Status = TEXT("表现已更新；保留移动和后续步骤");
        RecordEvent(TEXT("accepted"), Json);
        return true;
    }
    Plan = MoveTemp(Candidate);
    StepIndex = 0;
    Status = Origin + TEXT("：计划已校验");
    BeginStep();
    RecordEvent(TEXT("accepted"), Json);
    UE_LOG(LogDirector, Display, TEXT("ACCEPT %s %s"), *Origin, *Json);
    return true;
}

void ADirectorController::ApplyModifiers(const FDirectorStep& S)
{
    auto* C = Character();
    if (!C) return;
    if (!S.Gait.IsEmpty()) Gait = S.Gait;
    if (!S.Style.IsEmpty()) Style = S.Style;
    if (!S.Stance.IsEmpty()) Stance = S.Stance;
    if (!S.LookAt.IsEmpty()) LookAt = S.LookAt == TEXT("none") ? FString() : S.LookAt;
    C->SetDesiredGait(Gait == TEXT("sprint") ? AlsGaitTags::Sprinting : Gait == TEXT("run") ? AlsGaitTags::Running : AlsGaitTags::Walking);
    C->SetDesiredStance(Stance == TEXT("crouch") ? AlsStanceTags::Crouching : AlsStanceTags::Standing);
    C->SetOverlayMode(Style == TEXT("carrying") ? AlsOverlayModeTags::Box : Style == TEXT("injured") ? AlsOverlayModeTags::Injured : AlsOverlayModeTags::Default);
    C->SetDesiredAiming(Style == TEXT("alert"));
    C->SetDesiredRotationMode(AlsRotationModeTags::VelocityDirection);
}

void ADirectorController::BeginStep()
{
    if (!Plan.IsValidIndex(StepIndex)) return;
    const FDirectorStep S = Plan[StepIndex];
    ApplyModifiers(S);
    if (S.Action == TEXT("move_to"))
    {
        Phase = TEXT("executing");
        MoveTarget = S.Target;
        bMoving = true;
        MovementStart = LastProgressTime = GetWorld()->GetTimeSeconds();
        BestDistance = FVector::Dist2D(Character()->GetActorLocation(), Targets[MoveTarget]);
        Status = TEXT("正在接近目标");
    }
    else if (S.Action == TEXT("stop"))
    {
        bMoving = false; MoveTarget.Reset();
        Character()->ConsumeMovementInputVector();
        Character()->GetCharacterMovement()->StopMovementImmediately();
        Status = TEXT("停止动作已执行");
        Phase = TEXT("stopped");
        Plan.Reset(); StepIndex = 0;
    }
    else Status = TEXT("表现参数已更新；保留原移动目标");
}

void ADirectorController::FinishMovement(const FString& Reason, bool Success)
{
    bMoving = false;
    MoveTarget.Reset();
    if (Character()) Character()->ConsumeMovementInputVector();
    Status = Reason;
    Phase = Success ? TEXT("arrived") : TEXT("blocked");
    RecordEvent(Phase, Reason);
    UE_LOG(LogDirector, Display, TEXT("MOVEMENT %s"), *Reason);
    if (Success) { ++StepIndex; BeginStep(); }
    else Plan.Reset();
}

void ADirectorController::Tick(float Dt)
{
    Super::Tick(Dt);
    LastTickSeconds = Dt;
    if (WasInputKeyJustPressed(EKeys::Escape)) EmergencyStop();
    auto* C = Character();
    if (C)
    {
        FVector Direction = C->GetActorForwardVector();
        if (bMoving)
        {
            FVector Delta = Targets[MoveTarget] - C->GetActorLocation(); Delta.Z = 0;
            const float Distance = Delta.Size();
            const double Now = GetWorld()->GetTimeSeconds();
            if (Distance < 155) FinishMovement(TEXT("已到达目标"), true);
            else if (Now - MovementStart > 30 || Now - LastProgressTime > 5)
                FinishMovement(TEXT("移动超时或被阻挡，计划已取消"), false);
            else
            {
                if (Distance < BestDistance - 10) { BestDistance = Distance; LastProgressTime = Now; }
                Direction = Delta.GetSafeNormal();
                C->AddMovementInput(Direction, 1.0f);
                if (bDebug) DrawDebugLine(GetWorld(), C->GetActorLocation(), Targets[MoveTarget] + FVector(0,0,90), FColor::Cyan, false, 0, 0, 1.5f);
            }
        }
        if (!LookAt.IsEmpty())
        {
            Direction = Targets[LookAt] + FVector(0,0,120) - C->GetActorLocation();
            if (bDebug) DrawDebugLine(GetWorld(), C->GetActorLocation() + FVector(0,0,65), Targets[LookAt] + FVector(0,0,120), FColor::Yellow, false, 0, 0, 1.5f);
        }
        if (bMoving || !LookAt.IsEmpty()) SetControlRotation(FMath::RInterpTo(GetControlRotation(), Direction.Rotation(), Dt, 3.0f));
    }
    UpdateCamera(Dt);
    PollElapsed += Dt;
    if (PollElapsed > 0.1f) { PollElapsed = 0; PollBridge(); WriteState(); }
    if (bRecording)
    {
        FScreenshotRequest::RequestScreenshot(RecordingDirectory / FString::Printf(TEXT("frame_%06d.png"), RecordingFrame++), true, false);
        if (RecordingFrame >= 30 * 180) EndRecording();
    }
}

void ADirectorController::PollBridge()
{
    // Local UI requests and automation use the same SubmitText path.
    const FString InputPath = GetBridgeDirectory() / TEXT("input.json");
    FString Text;
    if (FFileHelper::LoadFileToString(Text, *InputPath))
    {
        IFileManager::Get().Delete(*InputPath);
        TSharedPtr<FJsonObject> InputObject;
        if (FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), InputObject) && InputObject.IsValid())
        {
            FString InputSession, Utterance;
            InputObject->TryGetStringField(TEXT("session_id"), InputSession);
            if (InputSession == SessionId && InputObject->TryGetStringField(TEXT("text"), Utterance))
            {
                if (Utterance == TEXT("__STOP__")) EmergencyStop();
                else if (Utterance == TEXT("__RESET__")) ResetStage();
                else if (Utterance == TEXT("__CAMERA__")) ToggleCamera();
                else if (Utterance == TEXT("__DEBUG__")) ToggleDebug();
                else if (Utterance == TEXT("__RECORD_START__")) BeginRecording();
                else if (Utterance == TEXT("__RECORD_STOP__")) EndRecording();
                else if (Utterance == TEXT("__QUIT__")) ConsoleCommand(TEXT("quit"));
                else if (Utterance == TEXT("__CAPTURE__")) FScreenshotRequest::RequestScreenshot(TEXT("Director"), true, true);
                else SubmitText(Utterance);
            }
        }
    }
    if (PendingId.IsEmpty()) return;
    if (FPlatformTime::Seconds() - RequestTime > 180)
    { PendingId.Reset(); Phase = TEXT("timeout"); Status = TEXT("GPT 回传超时；可重新发送，原动作不变"); RecordEvent(Phase, Status); return; }
    const FString ResponsePath = GetBridgeDirectory() / (PendingId + TEXT(".response.json"));
    if (!FFileHelper::LoadFileToString(Text, *ResponsePath)) return;
    IFileManager::Get().Delete(*ResponsePath);
    TSharedPtr<FJsonObject> Response;
    if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Response) || !Response.IsValid())
    { Status = TEXT("回传不是合法 JSON"); PendingId.Reset(); return; }
    FString ResponseId, ResponseSession, PlanJson;
    FString Source;
    Response->TryGetStringField(TEXT("source"), Source);
    Response->TryGetStringField(TEXT("request_id"), ResponseId);
    Response->TryGetStringField(TEXT("session_id"), ResponseSession);
    if (ResponseId != PendingId || ResponseSession != SessionId)
    { Status = TEXT("已拒绝过期会话或不匹配的请求"); return; }
    const TSharedPtr<FJsonObject>* PlanObject;
    ResponseLatency = FPlatformTime::Seconds() - RequestTime;
    PendingId.Reset();
    if (!Response->TryGetObjectField(TEXT("plan"), PlanObject)) { Status = TEXT("回传缺少动作计划"); return; }
    ApplyPlan(JsonString(PlanObject->ToSharedRef()), Source == TEXT("test") ? TEXT("自动化测试夹具") : Source == TEXT("replay") ? TEXT("已保存计划回放") : TEXT("GPT / Codex 本地桥"));
}

FString ADirectorController::GetTelemetry() const
{
    const float Speed = Character() ? Character()->GetVelocity().Size2D() : 0;
    return FString::Printf(TEXT("%s · %s · %s\n速度 %.0f cm/s   |   目标 %s\n注视 %s   |   %s"),
        *LocalGait(Gait), *LocalStyle(Style), Stance == TEXT("crouch") ? TEXT("蹲伏") : TEXT("站立"), Speed,
        MoveTarget.IsEmpty() ? TEXT("无") : *MoveTarget, LookAt.IsEmpty() ? TEXT("随移动") : *LookAt, *Status);
}

void ADirectorController::WriteState() const
{
    auto State = MakeShared<FJsonObject>();
    State->SetBoolField(TEXT("running"), true);
    State->SetStringField(TEXT("session_id"), SessionId);
    State->SetStringField(TEXT("pending_request"), PendingId);
    State->SetStringField(TEXT("status"), Status);
    State->SetStringField(TEXT("gait"), Gait);
    State->SetStringField(TEXT("style"), Style);
    State->SetStringField(TEXT("stance"), Stance);
    State->SetStringField(TEXT("move_target"), MoveTarget);
    State->SetStringField(TEXT("look_at"), LookAt);
    State->SetBoolField(TEXT("moving"), bMoving);
    State->SetStringField(TEXT("last_text"), LastText);
    State->SetStringField(TEXT("last_plan"), LastPlan);
    State->SetStringField(TEXT("origin"), LastOrigin);
    State->SetStringField(TEXT("phase"), Phase);
    State->SetNumberField(TEXT("accepted_count"), AcceptedCount);
    State->SetNumberField(TEXT("rejected_count"), RejectedCount);
    State->SetNumberField(TEXT("response_seconds"), ResponseLatency);
    State->SetNumberField(TEXT("remaining_steps"), FMath::Max(0, Plan.Num() - StepIndex));
    State->SetStringField(TEXT("camera"), CameraMode);
    State->SetBoolField(TEXT("recording"), bRecording);
    State->SetStringField(TEXT("recording_directory"), RecordingDirectory);
    State->SetNumberField(TEXT("recording_frames"), RecordingFrame);
    State->SetNumberField(TEXT("tick_seconds"), LastTickSeconds);
    State->SetNumberField(TEXT("world_seconds"), GetWorld()->GetTimeSeconds());
    if (const auto* C = Character())
    {
        State->SetNumberField(TEXT("speed"), C->GetVelocity().Size2D());
        State->SetNumberField(TEXT("x"), C->GetActorLocation().X);
        State->SetNumberField(TEXT("y"), C->GetActorLocation().Y);
        State->SetNumberField(TEXT("z"), C->GetActorLocation().Z);
        State->SetStringField(TEXT("actual_stance"), C->GetStance().ToString());
        State->SetNumberField(TEXT("view_yaw"), GetControlRotation().Yaw);
        State->SetNumberField(TEXT("body_yaw"), C->GetActorRotation().Yaw);
        State->SetBoolField(TEXT("animation_loaded"), C->GetMesh()->GetAnimInstance() != nullptr);
        State->SetStringField(TEXT("actual_gait"), C->GetGait().ToString());
        State->SetStringField(TEXT("overlay"), C->GetOverlayMode().ToString());
    }
    SaveJson(GetBridgeDirectory() / TEXT("state.json"), State);
}

ADirectorGameMode::ADirectorGameMode()
{
    PlayerControllerClass = ADirectorController::StaticClass();
    DefaultPawnClass = nullptr;
}

void ADirectorGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
    // Defer Blueprint loading until all ALS runtime modules have registered their classes.
    DefaultPawnClass = LoadClass<APawn>(nullptr, TEXT("/ALS/ALS/Character/B_Als_Character.B_Als_Character_C"));
    Super::InitGame(MapName, Options, ErrorMessage);
}

void ADirectorGameMode::StartPlay()
{
    BuildStage();
    Super::StartPlay();
}
