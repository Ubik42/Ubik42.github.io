#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/PlayerController.h"
#include "DirectorPlan.h"
#include "DirectorRuntime.generated.h"

class AAlsCharacter;
class SEditableTextBox;
class SWidget;
class ACameraActor;

UCLASS()
class ALSDIRECTOR_API ADirectorController : public APlayerController
{
    GENERATED_BODY()
public:
    ADirectorController();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
    void SubmitText(const FString& Text);
    bool ApplyPlan(const FString& Json, const FString& Origin);
    void EmergencyStop();
    FString GetTelemetry() const;
    FString GetBridgeDirectory() const;
    void ResetStage();
    void ToggleCamera();
    void ToggleDebug();
    void BeginRecording();
    void EndRecording();
    FString GetDirectorSummary() const;
private:
    void BuildPanel();
    void UpdateCamera(float Dt);
    void RecordEvent(const FString& Event, const FString& Detail) const;
    void PollBridge();
    void WriteState() const;
    void BeginStep();
    void ApplyModifiers(const FDirectorStep& Step);
    void FinishMovement(const FString& Reason, bool Success);
    AAlsCharacter* Character() const;
    TSharedPtr<SWidget> Panel;
    TSharedPtr<SEditableTextBox> Input;
    TMap<FString, FVector> Targets;
    TArray<FDirectorStep> Plan;
    int32 StepIndex = 0;
    FString PendingId;
    FString SessionId;
    FString Status = TEXT("就绪：输入指令，发送给当前 Codex 对话中的 GPT");
    FString LastText;
    FString LastPlan;
    FString LastOrigin;
    FString RecordingDirectory;
    FString CameraMode = TEXT("follow");
    TWeakObjectPtr<ACameraActor> DirectorCamera;
    bool bDebug = true;
    bool bRecording = false;
    bool bPreviousFixedFrameRate = false;
    float PreviousFixedFrameRate = 30;
    float LastTickSeconds = 0;
    int32 RecordingFrame = 0;
    int32 AcceptedCount = 0;
    int32 RejectedCount = 0;
    float ResponseLatency = 0;
    FString Phase = TEXT("ready");
    FString Gait = TEXT("walk");
    FString Style = TEXT("normal");
    FString Stance = TEXT("stand");
    FString LookAt;
    FString MoveTarget;
    bool bMoving = false;
    double RequestTime = 0;
    double MovementStart = 0;
    double LastProgressTime = 0;
    float BestDistance = 0;
    float PollElapsed = 0;
};

UCLASS()
class ALSDIRECTOR_API ADirectorGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    ADirectorGameMode();
    virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
    virtual void StartPlay() override;
private:
    void BuildStage();
};
