using UnrealBuildTool;
public class ALSDirectorEditorTarget : TargetRules
{
    public ALSDirectorEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.V7;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_8;
        ExtraModuleNames.Add("ALSDirector");
    }
}
