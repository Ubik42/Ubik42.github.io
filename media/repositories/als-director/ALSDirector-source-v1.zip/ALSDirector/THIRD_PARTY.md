# 来源与分工

- ALS-Refactored：Sixze、Caleb Longmire、Doğa Can Yanıkoğlu 与贡献者；上游 https://github.com/Sixze/ALS-Refactored ，提交 `b754d6f0f2bb03741d301f8fb88077ebfe561e17`。角色、动画、叠加姿态、脚部处理和道具附着均来自 ALS，不作为本项目原创动画展示。上游 MIT 许可原文保留在 `Plugins/ALS/LICENSE.md`。
- Unreal Engine 5.8.1：Epic Games。引擎与引擎自带 BasicShapes 受其各自条款管理；源码下载包不包含引擎文件，依赖本机合法安装的 Unreal Engine。
- 本项目新增：结构化动作合同、当前对话桥、请求与会话隔离、执行队列、途中表现补丁、急停与复位、导演界面、摄影机、程序化测试场景、回归测试与录制工具。
- 语言理解来自当前 Codex 对话；协议回归使用人工指定的固定计划，运行界面标为“自动化测试夹具”。二者不混同，保存计划的回放也不冒充在线推理。
- 展示视频无第三方音乐、真人参考画面或生成效果图。画面来自本工程运行时渲染，按 30 fps 固定游戏步长捕获；不用于衡量真实推理等待时间或 GPU 性能。
