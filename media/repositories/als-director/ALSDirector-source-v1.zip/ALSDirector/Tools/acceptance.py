"""Live UE regression. Fixture plans are explicitly labelled as tests, never GPT calls."""
import argparse
import json
import time
from bridge import ROOT, read, write

def state():
    return read('state.json')

def wait(predicate, timeout=35):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        s = state()
        if predicate(s):
            return s
        time.sleep(0.1)
    raise AssertionError(state())

def control(name):
    write('input.json', {'session_id': state()['session_id'], 'text': '__' + name + '__'})
    wait(lambda s: not (ROOT / 'input.json').exists())
    time.sleep(0.2)

def request(text):
    previous = state()['pending_request']
    write('input.json', {'session_id': state()['session_id'], 'text': text})
    wait(lambda s: s['pending_request'] and s['pending_request'] != previous and s['last_text'] == text)
    return read('request.json')

def respond(req, steps, session=None):
    write(req['request_id']+'.response.json', {'request_id': req['request_id'], 'session_id': session or req['session_id'], 'source': 'test', 'plan': {'steps': steps}})

def apply(text, steps):
    req = request(text)
    respond(req, steps)
    return wait(lambda s: not s['pending_request'])

def hold(seconds=1.5):
    if state()['recording']:
        target = state()['recording_frames'] + int(seconds * 30)
        wait(lambda s: s['recording_frames'] >= target)
    else:
        time.sleep(seconds)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--record', action='store_true')
    args = parser.parse_args()
    results = []
    def passed(name, s=None):
        results.append({'name': name, 'passed': True, 'state': s or state()})
        print('PASS ' + name, flush=True)
        hold()
    if state()['recording']:
        control('RECORD_STOP')
        wait(lambda s: not s['recording'])
    control('RESET')
    wait(lambda s: s['phase'] == 'ready')
    if args.record:
        control('RECORD_START')
        wait(lambda s: s['recording'])
    try:
        s = state()
        assert s['animation_loaded'] and abs(s['x']+450)<5
        passed('01 / 角色、动画实例与复位')
        apply('测试 02：跑向青色箱子', [{'action':'move_to','target':'blue_box','gait':'run'}])
        s=wait(lambda s: s['moving'] and s['speed']>250)
        passed('02 / 真实跑步速度与位置更新',s)
        apply('测试 03：继续移动，蹲下来', [{'action':'adjust','stance':'crouch','gait':'walk'}])
        s=wait(lambda s: s['actual_stance']=='Als.Stance.Crouching')
        assert s['move_target']=='blue_box' and s['moving']
        passed('03 / 蹲伏且保留移动目标',s)
        apply('测试 04：停下，站起来并抱箱', [{'action':'stop','stance':'stand','style':'carrying'}])
        s=wait(lambda s: s['overlay']=='Als.OverlayMode.Box' and s['actual_stance']=='Als.Stance.Standing' and s['speed']<1)
        passed('04 / 抱箱叠加姿态与停止',s)
        apply('测试 05：受伤姿态，看向门口', [{'action':'adjust','style':'injured','look_at':'door'}])
        s=wait(lambda s: s['overlay']=='Als.OverlayMode.Injured' and s['look_at']=='door')
        passed('05 / 受伤叠加与注视目标',s)
        apply('测试 06：先到青箱，再到红柱，最后停下', [{'action':'move_to','target':'blue_box','gait':'run','style':'normal','look_at':'none'},{'action':'move_to','target':'red_target'},{'action':'stop'}])
        wait(lambda s: s['move_target']=='red_target')
        s=wait(lambda s: s['phase']=='stopped' and s['speed']<1)
        assert ((s['x']-600)**2+(s['y']-430)**2)**.5<190
        passed('06 / 多步骤顺序与到达判定',s)
        apply('测试 07：到门口，再到青箱', [{'action':'move_to','target':'door','gait':'walk'},{'action':'move_to','target':'blue_box'},{'action':'stop'}])
        apply('测试 07：途中改成抱箱，保留后续路线', [{'action':'adjust','style':'carrying'}])
        s=state()
        assert s['remaining_steps']==3 and s['move_target']=='door' and s['moving']
        passed('07 / 途中补丁保留完整队列',s)
        control('STOP')
        before=state()['rejected_count']
        apply('测试 08：拒绝不存在的动作', [{'action':'execute_code'}])
        s=wait(lambda s: s['rejected_count']==before+1)
        assert s['style']=='carrying' and not s['moving']
        passed('08 / 非法计划整体拒绝且不改角色',s)
        req=request('测试 09：拒绝旧会话回复')
        respond(req,[{'action':'move_to','target':'door'}],session='wrong-session')
        hold(1)
        s=state()
        assert s['pending_request']==req['request_id'] and not s['moving']
        passed('09 / 会话隔离',s)
        old=request('测试 10：这条旧指令将被覆盖')
        new=request('测试 10：用新指令替换旧指令')
        respond(old,[{'action':'move_to','target':'door'}])
        hold(0.5)
        assert state()['pending_request']==new['request_id'] and not state()['moving']
        respond(new,[{'action':'stop','style':'normal'}])
        wait(lambda s: not s['pending_request'] and s['style']=='normal')
        passed('10 / 新请求覆盖旧请求')
        req=request('测试 11：急停后，迟到的回复不得启动角色')
        control('STOP')
        respond(req,[{'action':'move_to','target':'door'}])
        hold(1)
        s=state()
        assert not s['moving'] and not s['pending_request'] and s['speed']<1
        passed('11 / 急停使迟到回复失效',s)
        control('RESET')
        s=wait(lambda s: s['phase']=='ready' and s['style']=='normal')
        assert abs(s['x']+450)<5 and abs(s['y']+300)<5
        passed('12 / 测试后复位与恢复')
    finally:
        if args.record:
            control('RECORD_STOP')
        write('acceptance-results.json', {'passed':len(results),'expected':12,'recording_directory':state()['recording_directory'],'results':results})
        control('STOP')
    assert len(results)==12
    print(json.dumps({'passed':12,'recording_directory':state()['recording_directory']},ensure_ascii=False),flush=True)

if __name__=='__main__':
    main()
