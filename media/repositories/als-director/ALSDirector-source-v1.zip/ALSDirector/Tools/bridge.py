"""Local transport only. Natural-language interpretation is done by the active Codex agent."""
import argparse
import json
import os
import time
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
CANDIDATES = [BASE / 'Saved/DirectorBridge', BASE / 'ALSDirector/Saved/DirectorBridge', BASE / 'Releases/v1/Windows/ALSDirector/Saved/DirectorBridge']
ROOT = Path(os.environ['ALS_DIRECTOR_BRIDGE']) if 'ALS_DIRECTOR_BRIDGE' in os.environ else max(CANDIDATES, key=lambda p: (p / 'state.json').stat().st_mtime if (p / 'state.json').exists() else 0)

def read(name):
    # UE's Windows replace can briefly hide the destination; tolerate that window.
    for attempt in range(20):
        try:
            return json.loads((ROOT / name).read_text(encoding='utf-8-sig'))
        except (FileNotFoundError, PermissionError, json.JSONDecodeError):
            if attempt == 19:
                raise
            time.sleep(0.025)

def write(name, data):
    path = ROOT / name
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    for attempt in range(20):
        try:
            os.replace(temporary, path)
            break
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(0.025)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    controls = {'stop': '__STOP__', 'capture': '__CAPTURE__', 'reset': '__RESET__', 'camera': '__CAMERA__', 'debug': '__DEBUG__', 'record-start': '__RECORD_START__', 'record-stop': '__RECORD_STOP__', 'quit': '__QUIT__'}
    parser.add_argument('command', choices=['state', 'read', 'request', 'respond', *controls])
    parser.add_argument('--source', choices=['codex','test','replay'], default='codex')
    parser.add_argument('--text')
    parser.add_argument('--plan', help='JSON object authored by the active agent, not a model API call')
    parser.add_argument('--request-id', help='Required response correlation: never answer a newer request accidentally')
    args = parser.parse_args()
    state = read('state.json')
    if time.time() - (ROOT / 'state.json').stat().st_mtime > 5:
        parser.error('Game state is stale. Wait for startup or restart the game.')
    if args.command == 'state':
        print(json.dumps(state, ensure_ascii=False, indent=2))
        return
    if not state.get('running'):
        parser.error('Game is not running')
    if args.command == 'request' or args.command in controls:
        text = controls.get(args.command, args.text)
        if not text or len(text) > 1000:
            parser.error('Provide 1-1000 characters with --text')
        write('input.json', {'session_id': state['session_id'], 'text': text})
    else:
        request = read('request.json')
        if request['session_id'] != state['session_id'] or request['request_id'] != state['pending_request']:
            parser.error('No matching pending request')
        if args.command == 'read':
            print(json.dumps(request, ensure_ascii=False, indent=2))
            return
        if not args.plan or args.request_id != request['request_id']:
            parser.error('Provide --plan and the exact --request-id returned by read')
        plan = json.loads(args.plan)
        if not isinstance(plan, dict):
            parser.error('Plan must be an object')
        envelope = {'session_id': request['session_id'], 'request_id': request['request_id'], 'plan': plan, 'source': args.source}
        write(request['request_id'] + '.response.json', envelope)
        print('Response sent; inspect state for game-side validation and execution.')

if __name__ == '__main__':
    main()
