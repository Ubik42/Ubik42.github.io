"""Recording transport. Does not interpret prompts or supply action plans."""
import argparse
import json
import time
from bridge import read, write

parser=argparse.ArgumentParser()
parser.add_argument('command',choices=['hold','control'])
parser.add_argument('value')
args=parser.parse_args()
if args.command=='control':
    s=read('state.json')
    write('input.json',{'session_id':s['session_id'],'text':'__'+args.value+'__'})
else:
    first=read('state.json')
    target=first['recording_frames']+int(args.value)
    deadline=time.monotonic()+55
    while time.monotonic()<deadline:
        s=read('state.json')
        if not s['recording']:
            raise RuntimeError('Recording is not active')
        if s['recording_frames']>=target:
            print(json.dumps(s,ensure_ascii=False))
            break
        time.sleep(.2)
    else:
        raise TimeoutError('Frame capture deadline exceeded')
