import unreal

levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if not levels.new_level('/Game/DirectorStage'):
    raise RuntimeError('Cannot create DirectorStage')
levels.save_current_level()
unreal.log('DIRECTOR_STAGE_SAVED')
