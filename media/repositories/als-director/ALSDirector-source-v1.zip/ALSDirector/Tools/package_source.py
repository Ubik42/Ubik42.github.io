"""Produce a source-only distribution; excludes engine, dependency assets, cache and machine settings."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
target = root / 'Releases/ALSDirector-source-v1.zip'
target.parent.mkdir(parents=True, exist_ok=True)
files = [root / n for n in ['ALSDirector.uproject','README.md','THIRD_PARTY.md','Launch.ps1']]
for folder in ['Source','Config','Tools','Docs']:
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.log'])
files.extend([root/'Content/DirectorStage.umap',root/'Content/DirectorMaterials/M_Stage.uasset'])
with ZipFile(target,'w',ZIP_DEFLATED) as z:
    for p in files:
        z.write(p,Path('ALSDirector')/p.relative_to(root))
print(target)
