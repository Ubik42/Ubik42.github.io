"""Archive the runnable build without PDBs, runtime logs or captured frames."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path(__file__).resolve().parents[1]
build=root/'Releases/v1/Windows'
out=root/'Releases/ALSDirector-Windows-v1.zip'
assert (build/'ALSDirector.exe').exists()
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=5) as z:
    for p in build.rglob('*'):
        if not p.is_file():
            continue
        rel=p.relative_to(build)
        if any(x in ['Saved','__pycache__'] for x in rel.parts) or p.suffix in ['.pdb','.log','.pyc'] or p.name.startswith('Manifest_'):
            continue
        z.write(p,Path('ALSDirector-Windows-v1')/rel)
print(out)
print(out.stat().st_size)
