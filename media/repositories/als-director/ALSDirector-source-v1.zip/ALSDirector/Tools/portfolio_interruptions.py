"""Record explicit fixture plans: moving patches, pending request, stop, late response."""
import json
import time
from pathlib import Path
from bridge import ROOT, read, write

def state():
    return read('state.json')

def wait(predicate, timeout=50):
    start = time.monotonic()
    while time.monotonic()-start < timeout:
        s = state()
        if predicate(s):
            return s
        time.sleep(.05)
    raise RuntimeError(json.dumps(state(), ensure_ascii=False))

def control(name):
    write('input.json', {'session_id': state()['session_id'], 'text': '__'+name+'__'})
    wait(lambda s: not (ROOT/'input.json').exists())

def request(text):
    previous = state()['pending_request']
    write('input.json', {'session_id': state()['session_id'], 'text': text})
    wait(lambda s: s['pending_request'] and s['pending_request'] != previous and s['last_text'] == text)
    return read('request.json')

def respond(req, steps):
    write(req['request_id']+'.response.json', {'session_id': req['session_id'], 'request_id': req['request_id'], 'source': 'test', 'plan': {'steps': steps}})

def apply(text, steps):
    before = state()['accepted_count']
    req = request(text)
    respond(req, steps)
    return wait(lambda s: not s['pending_request'] and s['accepted_count'] == before+1)

def hold(frames):
    target = state()['recording_frames'] + frames
    return wait(lambda s: s['recording_frames'] >= target)

if __name__ == '__main__':
    if not state()['running'] or time.time()-(ROOT/'state.json').stat().st_mtime > 5:
        raise RuntimeError('No fresh running instance')
    if state()['recording']:
        raise RuntimeError('Another recording is active; left untouched')
    result = {'source': 'Explicit regression fixtures; no model inference.', 'started_at': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'events': []}
    def mark(name, s=None, **extra):
        entry = {'name': name, 'state': s or state(), **extra}
        result['events'].append(entry)
        print(json.dumps({'event': name, 'frame': entry['state']['recording_frames']}, ensure_ascii=False), flush=True)
    control('RESET'); wait(lambda s: s['phase']=='ready' and s['animation_loaded'])
    control('RECORD_START'); wait(lambda s: s['recording'])
    result['recording_directory'] = state()['recording_directory']
    try:
        mark('ready'); hold(30)
        apply('测试：先慢慢走到红色标柱，再到青箱，最后停止。', [
            {'action':'move_to','target':'red_target','gait':'walk','style':'normal','stance':'stand','look_at':'none'},
            {'action':'move_to','target':'blue_box'}, {'action':'stop'}])
        s=wait(lambda s: s['moving'] and s['speed']>80)
        assert s['move_target']=='red_target' and s['remaining_steps']==3
        mark('moving',s); hold(30)
        apply('测试：保持路线，改成抱箱姿态，目光看向门口。', [{'action':'adjust','style':'carrying','look_at':'door'}])
        s=wait(lambda s: s['overlay']=='Als.OverlayMode.Box')
        assert s['moving'] and s['move_target']=='red_target' and s['remaining_steps']==3
        mark('carrying_patch',s); hold(60)
        apply('测试：继续沿原路线，蹲下来慢走。', [{'action':'adjust','stance':'crouch','gait':'walk'}])
        s=wait(lambda s: s['actual_stance']=='Als.Stance.Crouching')
        assert s['moving'] and s['move_target']=='red_target' and s['remaining_steps']==3
        mark('crouch_patch',s); hold(60)
        req=request('测试：改成跑向青箱。此回复暂缓，先执行急停。')
        s=state(); assert s['moving'] and s['move_target']=='red_target'
        mark('pending_request',s); hold(30)
        control('STOP')
        s=wait(lambda s: not s['moving'] and not s['pending_request'] and s['speed']<1)
        assert s['remaining_steps']==0
        mark('emergency_stop',s); hold(30)
        respond(req,[{'action':'move_to','target':'blue_box','gait':'run','stance':'stand','style':'normal'}])
        mark('late_response_injected',expired_request=req['request_id'])
        s=hold(90)
        stopped=result['events'][-2]['state']
        displacement=((s['x']-stopped['x'])**2+(s['y']-stopped['y'])**2)**.5
        assert not s['moving'] and not s['pending_request'] and s['speed']<1
        assert s['accepted_count']==stopped['accepted_count'] and s['remaining_steps']==0 and displacement<1
        assert (ROOT/(req['request_id']+'.response.json')).exists()
        mark('late_response_ignored',s,displacement_cm=displacement,old_file_unread=True)
        apply('测试：新指令恢复站立，正常步行去青箱。', [{'action':'move_to','target':'blue_box','gait':'walk','stance':'stand','style':'normal','look_at':'none'}])
        s=wait(lambda s: s['moving'] and s['actual_stance']=='Als.Stance.Standing' and s['speed']>80)
        mark('fresh_request_resumes',s); hold(75)
        result['passed']=True
    finally:
        control('RECORD_STOP')
        wait(lambda s: not s['recording'])
        result['final']=state()
        output=Path(result['recording_directory'])/'interruptions.json'
        output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        control('STOP')
        print(str(output),flush=True)
