"""Export a public, path-free acceptance summary from the live host report."""
import json
from pathlib import Path
from bridge import ROOT, read

report=read('acceptance-results.json')
assert report['passed']==report['expected']==12
out=Path(__file__).resolve().parents[1]/'Media'
out.mkdir(exist_ok=True)
offset=report['results'][0]['state']['recording_frames']
public={'application':'ALSDirector','engine':'Unreal Engine 5.8.1','host':'Packaged Windows Development','passed':12,'expected':12,'plan_source':'explicit regression fixtures, not model inference','video_fps':30,'source_frame_offset':offset,'cases':[]}
for item in report['results']:
    s=item['state']
    public['cases'].append({'name':item['name'],'passed':item['passed'],'video_seconds':round((s['recording_frames']-offset)/30,2),'observed':{k:s[k] for k in ['speed','x','y','moving','move_target','actual_gait','actual_stance','overlay','look_at','remaining_steps','animation_loaded','tick_seconds']}})
(out/'acceptance.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),encoding='utf-8')
print(out/'acceptance.json')
