"""Protocol regression fixtures, NOT a natural-language model or demo parser."""
import json
import time
from pathlib import Path
from bridge import read, write, ROOT

def wait_for(predicate, timeout=8):
    until = time.monotonic() + timeout
    while time.monotonic() < until:
        state = read('state.json')
        if predicate(state):
            return state
        time.sleep(0.15)
    raise AssertionError(read('state.json'))

def request(text):
    state = read('state.json')
    write('input.json', {'session_id': state['session_id'], 'text': text})
    wait_for(lambda s: s['last_text'] == text and s['pending_request'])
    return read('request.json')

def response(req, plan):
    write(req['request_id'] + '.response.json', {
        'session_id': req['session_id'], 'request_id': req['request_id'], 'plan': plan, 'source': 'test'})

results = []
req = request('[自动化协议测试] 移动夹具')
response(req, {'steps': [{'action': 'move_to', 'target': 'door', 'gait': 'walk', 'style': 'normal', 'look_at': 'none'}]})
state = wait_for(lambda s: s['moving'] and s.get('speed', 0) > 50)
results.append({'test': 'movement', 'state': state})
req = request('[自动化协议测试] 途中修改姿态')
response(req, {'steps': [{'action': 'adjust', 'style': 'injured', 'look_at': 'red_target'}]})
state = wait_for(lambda s: s.get('overlay') == 'Als.OverlayMode.Injured' and s['look_at'] == 'red_target')
assert state['moving'] and state['move_target'] == 'door'
results.append({'test': 'adjust_preserves_destination', 'state': state})
req = request('[自动化协议测试] 非法计划')
response(req, {'steps': [{'action': 'execute_code'}]})
state = wait_for(lambda s: not s['pending_request'])
assert '拒绝' in state['status'] and state['style'] == 'injured'
results.append({'test': 'reject_invalid_plan', 'state': state})
req = request('[自动化协议测试] 急停后旧回复')
write('input.json', {'session_id': req['session_id'], 'text': '__STOP__'})
wait_for(lambda s: not s['pending_request'] and not s['moving'])
response(req, {'steps': [{'action': 'move_to', 'target': 'blue_box'}]})
time.sleep(0.8)
state = read('state.json')
assert not state['moving'] and state['speed'] < 1
results.append({'test': 'stop_invalidates_late_reply', 'state': state})
write('runtime-test-results.json', {'passed': len(results), 'results': results})
print(json.dumps({'passed': len(results), 'tests': [r['test'] for r in results]}, indent=2))
