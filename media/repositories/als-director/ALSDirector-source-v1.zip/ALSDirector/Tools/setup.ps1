$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$pluginPath = Join-Path $projectRoot 'Plugins/ALS'
$revision = 'b754d6f0f2bb03741d301f8fb88077ebfe561e17'
if (-not (Test-Path -LiteralPath (Join-Path $pluginPath 'ALS.uplugin'))) {
    $cachePath = Join-Path $projectRoot 'Saved/DependencySetup'
    New-Item -ItemType Directory -Force -Path $cachePath | Out-Null
    $archivePath = Join-Path $cachePath 'ALS.zip'
    Invoke-WebRequest -Uri "https://codeload.github.com/Sixze/ALS-Refactored/zip/$revision" -OutFile $archivePath
    Expand-Archive -LiteralPath $archivePath -DestinationPath $cachePath -Force
    New-Item -ItemType Directory -Force -Path $pluginPath | Out-Null
    Get-ChildItem -LiteralPath (Join-Path $cachePath "ALS-Refactored-$revision") -Force | Copy-Item -Destination $pluginPath -Recurse -Force
}
$enginePath = if ($env:UE58_ROOT) { $env:UE58_ROOT } else { 'C:/Program Files/Epic Games/UE_5.8' }
& (Join-Path $enginePath 'Engine/Build/BatchFiles/Build.bat') ALSDirectorEditor Win64 Development "-Project=$projectRoot/ALSDirector.uproject" -WaitMutex -NoHotReloadFromIDE -NoUBA
if ($LASTEXITCODE -ne 0) { throw 'Unreal Editor build failed' }
