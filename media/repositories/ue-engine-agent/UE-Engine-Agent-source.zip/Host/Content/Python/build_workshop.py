"""Original material workshop, built once before model-directed MCP operations."""
import unreal

assets = unreal.EditorAssetLibrary
levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
materials = unreal.MaterialEditingLibrary
folder = '/Game/EngineAgent'
assert levels.new_level(folder + '/L_Workshop')
factory = unreal.AssetToolsHelpers.get_asset_tools()
base = factory.create_asset('M_Surface', folder, unreal.Material, unreal.MaterialFactoryNew())
for name, default, prop in [('Roughness', .08, unreal.MaterialProperty.MP_ROUGHNESS),
                            ('Metallic', .85, unreal.MaterialProperty.MP_METALLIC)]:
    node = materials.create_material_expression(base, unreal.MaterialExpressionScalarParameter)
    node.set_editor_property('parameter_name', name)
    node.set_editor_property('default_value', default)
    materials.connect_material_property(node, '', prop)
color = materials.create_material_expression(base, unreal.MaterialExpressionVectorParameter)
color.set_editor_property('parameter_name', 'Tint')
color.set_editor_property('default_value', unreal.LinearColor(.025, .24, .32, 1))
materials.connect_material_property(color, '', unreal.MaterialProperty.MP_BASE_COLOR)
materials.recompile_material(base)
assets.save_loaded_asset(base)

def instance(name, tint, roughness, metallic):
    mat = factory.create_asset(name, folder, unreal.MaterialInstanceConstant, unreal.MaterialInstanceConstantFactoryNew())
    materials.set_material_instance_parent(mat, base)
    materials.set_material_instance_vector_parameter_value(mat, 'Tint', unreal.LinearColor(*tint, 1))
    materials.set_material_instance_scalar_parameter_value(mat, 'Roughness', roughness)
    materials.set_material_instance_scalar_parameter_value(mat, 'Metallic', metallic)
    assets.save_loaded_asset(mat)
    return mat

target = instance('MI_Target', (.025, .24, .32), .08, .85)
floor = instance('MI_Floor', (.045, .055, .07), .7, .15)
trim = instance('MI_Trim', (.42, .24, .06), .3, .75)

def mesh(label, shape, pos, scale, material):
    actor = actors.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(*pos))
    actor.set_actor_label(label)
    actor.static_mesh_component.set_static_mesh(assets.load_asset('/Engine/BasicShapes/' + shape))
    actor.set_actor_scale3d(unreal.Vector(*scale))
    actor.static_mesh_component.set_material(0, material)
    return actor

mesh('Workshop floor', 'Cube', (0, 0, -15), (16, 13, .3), floor)
for i, x in enumerate([-240, 0, 240]):
    mesh('Pedestal ' + str(i), 'Cylinder', (x, 0, 35), (1.9, 1.9, .7), floor)
    mesh('Trim ' + str(i), 'Cylinder', (x, 0, 73), (1.94, 1.94, .08), trim)
mesh('Target sphere', 'Sphere', (-240, 0, 145), (1.4, 1.4, 1.4), target)
mesh('Target cylinder', 'Cylinder', (0, 0, 145), (1.2, 1.2, 1.4), target)
mesh('Target cube', 'Cube', (240, 0, 145), (1.3, 1.3, 1.3), target)
sun = actors.spawn_actor_from_class(unreal.DirectionalLight, unreal.Vector(0, 0, 500))
sun.set_actor_rotation(unreal.Rotator(pitch=-40, yaw=-35, roll=0), False)
sun.light_component.set_editor_property('intensity', 5)
sky = actors.spawn_actor_from_class(unreal.SkyLight, unreal.Vector(0, 0, 300))
sky.light_component.set_editor_property('source_type', unreal.SkyLightSourceType.SLS_SPECIFIED_CUBEMAP)
sky.light_component.set_editor_property('cubemap', assets.load_asset('/Engine/EngineResources/DefaultTextureCube'))
sky.light_component.set_editor_property('intensity', 2)
sky.light_component.recapture_sky()
location = unreal.Vector(650, -1000, 600)
rotation = unreal.MathLibrary.find_look_at_rotation(location, unreal.Vector(0, 0, 100))
key = unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
levels.set_level_viewport_camera_info(location, rotation, key)
levels.editor_set_game_view(True, key)
actors.set_selected_level_actors([])
levels.save_current_level()
unreal.log('ENGINE_AGENT_WORKSHOP_READY')
unreal.SystemLibrary.execute_console_command(None, 'QUIT_EDITOR')
