"""Presentation setup only; no task generation or asset writes."""
import unreal

_frames = 0
_handle = None

def _ready(dt):
    global _frames
    _frames += 1
    if _frames < 120:
        return
    levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    key = unreal.Name('FourPanes2x2.Viewport 1.Viewport1')
    levels.editor_set_game_view(True, key)
    unreal.unregister_slate_post_tick_callback(_handle)

_handle = unreal.register_slate_post_tick_callback(_ready)
