"""Owned-host fixture: mesh setup and actual SIE motion sampling, no graph edits."""
import json
import math
import time
import re
import hashlib
from datetime import datetime,timezone
from pathlib import Path
import unreal
unreal.EditorPythonScripting.set_keep_python_script_alive(True)

ROOT=Path(unreal.Paths.project_dir()).resolve().parent
match=re.search(r'-EngineAgentProbeId=([a-zA-Z0-9_-]+)',unreal.SystemLibrary.get_command_line())
probe_id=match.group(1) if match else 'legacy'
OUT=ROOT/'artifacts'/'platform-runtime' if probe_id=='legacy' else ROOT/'artifacts/platform-probes'/probe_id
OUT.mkdir(parents=True,exist_ok=True)
request=json.loads((OUT/'request.json').read_text(encoding='utf-8')) if (OUT/'request.json').exists() else {'center':120,'amplitude':80,'angular_speed':1.5,'duration':8}
center,amplitude,speed,duration=(request[k] for k in ('center','amplitude','angular_speed','duration'))
from editor_toolset.toolsets.blueprint import BlueprintTools
blueprint=unreal.load_asset('/Game/EngineAgent/BP_LiftPlatform')
graph=BlueprintTools.read_graph_dsl(BlueprintTools.get_graph(blueprint,'EventGraph'))
graph_hash=hashlib.sha256(graph.encode()).hexdigest()
asset_hash=hashlib.sha256((ROOT/'Host/Content/EngineAgent/BP_LiftPlatform.uasset').read_bytes()).hexdigest()
levels=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
worlds=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
cls=unreal.EditorAssetLibrary.load_blueprint_class('/Game/EngineAgent/BP_LiftPlatform')
if not cls: raise RuntimeError('Save BP_LiftPlatform before running the fixture')
matches=[a for a in actors.get_all_level_actors() if a.get_class()==cls]
actor=matches[0] if matches else actors.spawn_actor_from_class(cls,unreal.Vector(0,0,120))
actor.set_actor_label('Agent_LiftPlatform')
mesh=actor.get_component_by_class(unreal.StaticMeshComponent)
mesh.set_mobility(unreal.ComponentMobility.MOVABLE)
mesh.set_static_mesh(unreal.load_asset('/Engine/BasicShapes/Cube'))
mesh.set_material(0,unreal.load_asset('/Game/EngineAgent/MI_Trim'))
actor.set_actor_scale3d(unreal.Vector(2.6,1.6,0.18))
actor.set_actor_location(unreal.Vector(0,0,120),False,False)
levels.save_current_level()
state={'phase':'waiting','samples':[],'started':time.monotonic(),'last_sample':0,'shot':False}
handle=None

def tick(dt):
    try:
        if state['phase']=='waiting':
            if time.monotonic()-state['started']<3: return
            levels.editor_play_simulate()
            state['phase']='playing'
            return
        if state['phase']=='playing':
            world=worlds.get_game_world()
            if not world:
                if time.monotonic()-state['started']>30: raise RuntimeError('SIE world did not start')
                return
            seconds=unreal.GameplayStatics.get_time_seconds(world)
            if seconds-state['last_sample']<0.1: return
            targets=unreal.GameplayStatics.get_all_actors_of_class(world,cls)
            if len(targets)!=1: raise RuntimeError('Expected exactly one runtime lift')
            pos=targets[0].get_actor_location()
            expected=center+amplitude*math.sin(seconds*speed)
            state['samples'].append({'time':seconds,'x':pos.x,'y':pos.y,'z':pos.z,'expected_z':expected,'error_cm':abs(pos.z-expected)})
            state['last_sample']=seconds
            if seconds>1 and not state['shot']:
                unreal.AutomationLibrary.take_high_res_screenshot(1600,900,str(OUT/'platform-sie.png'))
                state['shot']=True
            if seconds<duration: return
            samples=state['samples']
            result={'mode':'UE Simulate In Editor','planner':'Independent API: deepseek-flash','fixture':'mesh setup and sampling only; no graph writes','samples':samples,'count':len(samples),'z_range':[min(x['z'] for x in samples),max(x['z'] for x in samples)],'max_error_cm':max(x['error_cm'] for x in samples)}
            result.update({'probe_id':probe_id,'request':request,'recorded_at':datetime.now(timezone.utc).isoformat(),'graph_sha256':graph_hash,'asset_sha256':asset_hash})
            result['passed']=len(samples)>=duration*4 and result['z_range'][1]-result['z_range'][0]>amplitude*1.8 and result['max_error_cm']<3 and all(abs(x['x'])<0.01 and abs(x['y'])<0.01 for x in samples)
            tmp=OUT/'readback.tmp'
            tmp.write_text(json.dumps(result,indent=2),encoding='utf-8')
            tmp.replace(OUT/'readback.json')
            levels.editor_request_end_play()
            state['phase']='done'
            unreal.unregister_slate_post_tick_callback(handle)
            unreal.log('ENGINE_AGENT_PLATFORM_PROBE_DONE')
    except Exception as exc:
        (OUT/'error.json').write_text(json.dumps({'error':str(exc),'samples':state['samples']},indent=2),encoding='utf-8')
        levels.editor_request_end_play()
        unreal.unregister_slate_post_tick_callback(handle)
        unreal.log_error(str(exc))

handle=unreal.register_slate_post_tick_callback(tick)
