# UE 引擎 Agent：原生工具调用与可恢复编辑

通过 UE 5.8 官方 MCP 连接编辑器，将用户意图转成有记录的工具步骤。当前支持材质参数编辑、展示组合重排和蓝图图逻辑生成，保存真实工具结果与模型执行记录。

## 引擎性能 Agent（开发中）

已接入 Lyra 原生采集、持久实验任务、指标比较与 CSV 邻帧下钻。独立模型完成一次 Baseline → PhysicsLOD 实验调用与结果读取。首组帧时间 P95 为 12.01 → 10.65 ms；负载变化和重复验证仍待处理，当前记录为单组观察。真实运行还暴露了不同计时列的上报偏移，已据此修正诊断工具和提示词。[运行入口、原始证据与后续工作](docs/性能采集与模型诊断.md)。

进一步接入 Unreal Insights 离线 CPU 事件查询，从一次 58.6 ms 的角色移动更新追到传送器重叠事件、GameplayCue 和 Niagara 准备路径，模型可以按时间区间读取实际嵌套事件。[完整调用链与调查记录](docs/Lyra传送特效卡顿调查.md)。

模型已启动固定 Niagara 对照，并在 SIE 游戏世界中完成三轮激活及时间序列采样。加载时准备让首次调用从约 29 / 26 ms 变为 0.82 / 0.41 ms，同时增加加载开销；真实角色和粒子画面、active 状态、原始模型调用均保存。[固定场景与 SIE 结果](docs/固定Niagara激活实验.md)。

[32 秒案例短片](https://ubik42.github.io/media/repositories/ue-engine-agent/showcase.mp4)：实际模型任务记录、蓝图结构示意、旧结果失效和真实 UE 运行复现。[视频制作源码与素材说明](video/README.md)。

## 200 角色的光追场景调查

模型用原生日志识别了对局阶段切换和大批生成失败，随后在固定视角PIE中完成受控对照。全程201角色；远角色全部退出光追时，动态几何GPU均值6.69→0.155 ms，整帧没有收益。原始数据、局限与真实图像随案例提供。[调查过程与固定镜头复测](docs/200角色光追场景调查.md)。

![固定视角下的真实角色负载](docs/images/crowd-fixed-baseline.png)

团队入口：[项目Skill](skills/ue-performance-investigation/SKILL.md)、[工具合同](docs/性能工具合同.md)、[实际工具Schema](docs/performance-tools.json)、[JD实现核对](docs/JD实现核对.md)。

复现入口：[Lyra 5.7性能适配器](integrations/lyra57/README.md)，提供插件源码、版本化接口补丁与安装工具。使用 `python -m engine_agent.environment` 查看本机各场景依赖。独立的源码安装、编译和运行结果分别记录，旧HeroArena场景仍需要自定义资产。

## 渲染对照与中文性能工作台

独立模型已完成 Lyra 角色 Custom Depth 对照：参与角色均值 10.00→3.69，GPU 阶段耗时未下降。保留原始数据和真实 PIE 画面，用于展示如何验证并否定优化预期。[案例与数据](docs/Lyra角色附加深度对照.md)。

![性能工作台](docs/images/performance-workbench.png)

`python -m engine_agent.workbench --port 8795` 后访问 `/performance.html`，查看真实采集、GPU 阶段图和基线对照，并提交模型分析。性能会话支持有预算的历史上下文和调用观测。[运行方式与长会话机制](docs/性能工作台与长会话.md)。

## 蓝图生成与真实运行

新增运行反馈迭代：模型读取旧采样，将平台运动改为 180±55 cm，识别旧结果已过期，再自动启动新一轮 UE 模拟。13 轮调用完成修改与验证，新采样共 82 个点，覆盖 10 秒，高度为 125.000–234.999 cm。运行截图与图身份一起返回模型。[完整过程与入口](docs/运行反馈与参数迭代.md)。

独立模型查询节点和引脚，用 18 轮调用创建周期升降平台蓝图，完成编译、保存和读回。重新加载后进入 UE 模拟运行，66 次位置采样覆盖超过 8 秒，平台在 40.033–199.959 cm 高度间运动，与目标公式一致。宿主夹具负责 Mesh 装配和采样，图逻辑由模型生成。

![真实模拟中的金色升降平台](docs/images/platform-sie.png)

[案例、运行入口与原始记录](docs/蓝图升降平台案例.md)。执行过程中保留了保存参数和工具层级错误；明确的图编译失败会读回剩余图，再交给模型修正。

![调整后的暖色哑光材质](docs/images/after.png)

## 工程知识检索

模型通过 search_knowledge 搜索，再用 read_knowledge 读取所选资料。当前收录 6 张人工核对的工程/引擎资料卡，覆盖材质、展示组合、恢复、蓝图接口、UE MCP 和协议版本。检索使用中文二元词与英文标识符的词项评分；每张卡带来源、核验日期和内容摘要。本地源码摘要变化会标记为需要复核。

本次模型先读取材质资料，再完成苔绿色哑光调整；读取当前值、修改、保存、截图与独立读回均完成。完整执行包含路径错误与后续修正，共 24 轮，不作为检索效率提升的证明。由此补入 find_assets → load_asset 资产定位入口，并用真实 UE 返回值确认包路径与 UObject 引用的区别。

![检索资料后完成的苔绿色陶瓷](docs/images/moss-ceramic.png)

```powershell
# 仅查资料，不连接编辑器
python -m engine_agent search "蓝图节点引脚编译"
python -m engine_agent research plans/knowledge-review.txt --session research-demo --output artifacts/research
```

资料问答使用 3 轮真实模型调用，区分本地源码能力、已接入能力与当前宿主状态。当前蓝图工具仅完成源码调研，写操作尚未接入。资料是有来源的操作参考，当前参数仍由引擎读回确认。

- [知识库说明](docs/工程知识检索.md)
- [真实资料问答](docs/evidence/knowledge/knowledge-001.json)
- [检索参与材质任务的调用记录](docs/evidence/knowledge/knowledge-material-001.json)

## 中文任务工作台

![任务工作台：真实 UE 画面与执行步骤](docs/images/workbench.png)

启动 UE Host 后运行 `python -m engine_agent.workbench`，打开 `http://127.0.0.1:8795`。可以提交自然语言任务，查看模型轮次、真实工具步骤、检查失败项与视口截图；中断任务可继续，写入结果不明确时可触发读回恢复。布局任务可勾选“保存布局基线”。同一工作台串行执行编辑器任务。

本次从网页提交紫色陶瓷调整，先验证编辑器离线后的继续入口，再完成 9 轮模型调用。模型猜错 BaseColor 后收到 UE 只读错误，改用实际参数 Tint；最终读回 RGB (0.24, 0.07, 0.32)、Roughness 0.32、Metallic 0，保存成功并显示真实截图。过程中修正了只读错误与未知写入状态的分类，完整记录保留在 [工作台任务记录](docs/evidence/workbench/task.json)。

工作台直接读取本机 artifacts 中的 SQLite 会话。运行数据库不随源码包分发；源码包内的 docs/evidence 提供已完成案例记录。页面仅监听本机，密钥通过服务端环境变量读取。

## 独立模型执行：冷蓝陶瓷

用户只提供材质目标，DeepSeek Flash 在 13 轮 API 调用中自行发现工具、读取参数、修改并保存共享材质，再根据返回的视口截图描述效果。运行器没有预填具体工具步骤。

![模型执行后的冷蓝陶瓷](docs/images/ceramic.png)

Roughness 从 0.65 改为 0.25，Metallic 从 0.05 改为 0，Tint 改为线性 RGB (0.035, 0.16, 0.42)。独立 MCP 读取确认三项参数。完成后恢复同一会话，直接读取完成记录，不增加模型调用或引擎写入。

会话保存模型标识、每轮工具请求、返回值、截图引用和用量。模型回复先落盘再执行；执行结果不明确时等待读回。连续三次参数拒绝会结束当前轮，避免重复消耗。首个调试会话因工具目录纯文本解析错误触及轮次上限；修正后完成上述运行，原记录保留在本地。

- [完整模型与工具记录](docs/evidence/autonomous/transcript.json)
- [独立参数读回](docs/evidence/autonomous/independent-readback.json)

设置环境变量 `DEEPSEEK_API_KEY` 后运行：

```powershell
python -m engine_agent agent plans/blue-ceramic-task.txt --session ceramic-demo --output artifacts/autonomous
```

当前开放材质参数、Actor 变换、场景查询、保存与视口捕获；布局规则限定自建展示台。

## 场景布局：对象关系与视觉反馈

将横排展示改成三角形组合，每组包含目标物、深色底座和金色顶盘。独立模型读取 Actor 标签与世界变换，修改位置并保存地图。运行器在每次变换前保存原值。

![最终三角形展示布局](docs/images/layout.png)

首次模型执行交换了相同外观底座的身份，并遗漏独立的金色顶盘；画面不足以确认原始配对。开发过程中加入了基于原始共址关系的检查工具 `verify_scene`。最终一轮中，模型自行读到三块顶盘错位，修正后再次检查，6 项配对与 9 项高度/旋转/缩放检查通过。记录包含前面的失败与修正会话。

这项检查针对自建展台的组合关系，不代表任意场景的质量评价。基线由修改前的真实变换生成；本次首轮尚未提供快照入口，基线从执行器保留的修改前记录和未修改顶盘读回补齐。

```powershell
# 新布局任务先捕获组合关系；同目录已有基线时拒绝覆盖
python -m engine_agent snapshot-layout --output artifacts/new-layout
python -m engine_agent agent plans/stage-layout-task.txt --session new-layout --output artifacts/new-layout --max-turns 24
```

- [最终 15 项读回检查](docs/evidence/layout-final-readback.json)
- [模型发现顶盘错位并修正的完整记录](docs/evidence/layout/layout-support-001.json)

## 写入后丢失回复的恢复

真实 UE 已执行材质写入后，测试客户端主动丢弃回复。执行器将步骤留为 uncertain。恢复入口重新读取参数，确认与目标一致后将步骤标记完成；继续会话时复用记录，原写入累计发送一次。

```powershell
python -m engine_agent recover --session YOUR_SESSION --output artifacts/YOUR_FOLDER
# 然后用原任务文件与相同会话恢复 agent
```

当前自动恢复支持材质标量和向量设置。读回不一致时保留未确定状态，其他写操作仍需单独核实。此故障注入使用明确的测试夹具，未调用外部模型；[真实宿主恢复记录](docs/evidence/recovery.json)与模型自主案例分别保存。

## 首次材质案例

在自建展台中，将三个共享材质的物体从青色金属改为暖色哑光涂层。此次计划由活动中的 Codex 对话根据工具返回值和视口截图编写；本地运行器负责执行与持久记录。

| 参数 | 修改前 | 重启后的读回 |
| --- | --- | --- |
| Roughness | 0.08 | 0.65 |
| Metallic | 0.85 | 0.05 |
| Tint | (0.025, 0.24, 0.32) | (0.46, 0.12, 0.035) |

![修改前的青色金属](docs/images/before.png)

两张图均来自 UE 原生视口。前图保留编辑器辅助图标，后图启用 Game View；材质参数变化另由独立读回确认。相同计划重复运行时，8 个已完成步骤直接取回记录，避免再次写入。

## 工程实现

- **按需发现工具**：先获取工具目录，再获取目标工具集的实际参数定义，执行前校验 JSON Schema。工具定义保存在运行记录中。
- **持久执行**：SQLite 保存计划摘要、步骤状态、请求、返回值和时间。相同运行编号不能替换成另一份计划。
- **明确处理未完成操作**：调用开始后先写入状态；结果不明确的步骤留待读回核实。首次截图调用缺少可选结构的内部字段，失败记录仍保留，后续用新计划补齐参数。
- **独立结果检查**：执行、读回、资产保存和视口图分开记录。重启编辑器后的读回验证保存结果。
- **限定当前案例的写入范围**：只允许已实现的材质操作与指定资产保存，目标位于自建的 `/Game/EngineAgent/` 中。

独立模型循环已接入 DeepSeek Flash。CLI 同时保留模型自主执行和计划复现两种入口；文档检索和更多场景操作继续开发。

## 本地运行

需要 UE 5.8、Python 3，以及引擎自带的 ModelContextProtocol、EditorToolset 和 PythonScriptPlugin。

```powershell
python -m pip install -r requirements.txt
# 首次生成自建展台
powershell -File scripts/start_host.ps1 -BuildScene
# 启动编辑器与本地 MCP
powershell -File scripts/start_host.ps1
python -m engine_agent discover
python -m engine_agent run examples/matte-paint.json
python -m engine_agent history matte-paint-001
powershell -File scripts/stop_host.ps1
```

引擎安装路径在启动脚本中配置。项目素材通过 `Host/Content/Python/build_workshop.py` 重建，使用引擎基础形体；分发包不包含 UE 本体。

## 研究与推进

- [2026 下半年 Agent 技术调研](docs/2026下半年Agent技术调研.md)
- [长期开发目标](docs/CODEX_GOAL.md)
- [当前进度](docs/PROGRESS.md)

参考重点是工具发现、上下文组织、持续执行和结果反馈，各项能力以本项目运行结果说明。调研中的外部框架能力与后续计划分别标注。


## 性能 Agent 开发阶段（2026-11-03）

[岗位与技术输入](docs/inputs/2026-11-03/引擎Agent岗位JD-文字.md)、[设计与取舍](docs/性能Agent设计.md)、[长期目标](docs/CODEX_GOAL.md)。首批已有历史 CSV 导入与统计：

```powershell
python -m engine_agent.performance --csv <capture.csv> --manifest <manifest.json> --output artifacts/performance/import
```

输出保留原件、摘要、逐项指标与实验状态。当前已支持持久采集任务、CPU Trace 查询、GPU 阶段对照、独立模型诊断及基线归档。已有 Niagara 首次激活、CustomDepth 无收益对照和 200 角色光追裁剪案例，结果见 docs 中的案例记录。

性能场景依赖带 PerformanceLab 插件的 Lyra 工程及匹配的编译产物；普通官方 Lyra 无法直接生成这些自定义指标。源码包不包含外部 Lyra 或 UE。环境变量 `ENGINE_AGENT_LYRA_PROJECT` 和 `ENGINE_AGENT_LYRA_EDITOR` 分别指定 uproject 和 UnrealEditor.exe 的绝对路径，在启动服务前设置。

```powershell
python -m engine_agent.workbench --port 8796
# 打开 http://127.0.0.1:8796/performance.html
python -m engine_agent.capture start mixed-baseline-001 --variant CrowdRenderingBaseline --view-profile mixed
python -m engine_agent.capture observe mixed-baseline-001
```

`overview` 是远景俯视；`mixed` 用于近远角色混合观察。等待任务结束后使用同一视角采集 `RayTracingLOD`。比较会校验视角、脚本与构建指纹；已有任务保留冻结设置。
