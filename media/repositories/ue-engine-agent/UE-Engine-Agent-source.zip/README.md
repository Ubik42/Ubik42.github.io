# UE 引擎 Agent：原生工具调用与可恢复编辑

通过 UE 5.8 官方 MCP 连接编辑器，将用户意图转成有记录的工具步骤。当前完成材质参数编辑：读取真实工具定义和场景参数，调整材质，保存资产，重启编辑器后重新读取并截图。

![调整后的暖色哑光材质](docs/images/after.png)

## 已运行的案例

在自建展台中，将三个共享材质的物体从青色金属改为暖色哑光涂层。此次计划由活动中的 Codex 对话根据工具返回值和视口截图编写；本地运行器负责执行与持久记录。

| 参数 | 修改前 | 重启后的读回 |
| --- | --- | --- |
| Roughness | 0.08 | 0.65 |
| Metallic | 0.85 | 0.05 |
| Tint | (0.025, 0.24, 0.32) | (0.46, 0.12, 0.035) |

![修改前的青色金属](docs/images/before.png)

两张图均来自 UE 原生视口。前图保留编辑器辅助图标，后图启用 Game View；材质参数变化另由独立读回确认。相同计划重复运行时，8 个已完成步骤直接取回记录，避免再次写入。

## 工程实现

- **按需发现工具**：先获取工具目录，再获取目标工具集的实际参数定义，执行前校验 JSON Schema。工具定义保存在运行记录中。
- **持久执行**：SQLite 保存计划摘要、步骤状态、请求、返回值和时间。相同运行编号不能替换成另一份计划。
- **明确处理未完成操作**：调用开始后先写入状态；结果不明确的步骤留待读回核实。首次截图调用缺少可选结构的内部字段，失败记录仍保留，后续用新计划补齐参数。
- **独立结果检查**：执行、读回、资产保存和视口图分开记录。重启编辑器后的读回验证保存结果。
- **限定当前案例的写入范围**：只允许已实现的材质操作与指定资产保存，目标位于自建的 `/Game/EngineAgent/` 中。

当前模型决策入口为 Codex 对话，CLI 提供计划执行与复现。独立模型循环、文档检索和更多场景操作列入后续开发。

## 本地运行

需要 UE 5.8、Python 3，以及引擎自带的 ModelContextProtocol、EditorToolset 和 PythonScriptPlugin。

```powershell
python -m pip install -r requirements.txt
# 首次生成自建展台
powershell -File scripts/start_host.ps1 -BuildScene
# 启动编辑器与本地 MCP
powershell -File scripts/start_host.ps1
python -m engine_agent discover
python -m engine_agent run examples/matte-paint.json
python -m engine_agent history matte-paint-001
powershell -File scripts/stop_host.ps1
```

引擎安装路径在启动脚本中配置。项目素材通过 `Host/Content/Python/build_workshop.py` 重建，使用引擎基础形体；分发包不包含 UE 本体。

## 研究与推进

- [2026 下半年 Agent 技术调研](docs/2026下半年Agent技术调研.md)
- [长期开发目标](docs/CODEX_GOAL.md)
- [当前进度](docs/PROGRESS.md)

参考重点是工具发现、上下文组织、持续执行和结果反馈，各项能力以本项目运行结果说明。调研中的外部框架能力与后续计划分别标注。
