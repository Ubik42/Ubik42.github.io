# UE 引擎 Agent：原生工具调用与可恢复编辑

通过 UE 5.8 官方 MCP 连接编辑器，将用户意图转成有记录的工具步骤。当前完成材质参数编辑：读取真实工具定义和场景参数，调整材质，保存资产，重启编辑器后重新读取并截图。

![调整后的暖色哑光材质](docs/images/after.png)

## 独立模型执行：冷蓝陶瓷

用户只提供材质目标，DeepSeek Flash 在 13 轮 API 调用中自行发现工具、读取参数、修改并保存共享材质，再根据返回的视口截图描述效果。运行器没有预填具体工具步骤。

![模型执行后的冷蓝陶瓷](docs/images/ceramic.png)

Roughness 从 0.65 改为 0.25，Metallic 从 0.05 改为 0，Tint 改为线性 RGB (0.035, 0.16, 0.42)。独立 MCP 读取确认三项参数。完成后恢复同一会话，直接读取完成记录，不增加模型调用或引擎写入。

会话保存模型标识、每轮工具请求、返回值、截图引用和用量。模型回复先落盘再执行；执行结果不明确时等待读回。连续三次参数拒绝会结束当前轮，避免重复消耗。首个调试会话因工具目录纯文本解析错误触及轮次上限；修正后完成上述运行，原记录保留在本地。

- [完整模型与工具记录](docs/evidence/autonomous/transcript.json)
- [独立参数读回](docs/evidence/autonomous/independent-readback.json)

设置环境变量 `DEEPSEEK_API_KEY` 后运行：

```powershell
python -m engine_agent agent plans/blue-ceramic-task.txt --session ceramic-demo --output artifacts/autonomous
```

当前只开放材质编辑等已实现能力；图像检查来自模型对真实视口的观察。更广泛的场景编辑仍在开发。

## 首次材质案例

在自建展台中，将三个共享材质的物体从青色金属改为暖色哑光涂层。此次计划由活动中的 Codex 对话根据工具返回值和视口截图编写；本地运行器负责执行与持久记录。

| 参数 | 修改前 | 重启后的读回 |
| --- | --- | --- |
| Roughness | 0.08 | 0.65 |
| Metallic | 0.85 | 0.05 |
| Tint | (0.025, 0.24, 0.32) | (0.46, 0.12, 0.035) |

![修改前的青色金属](docs/images/before.png)

两张图均来自 UE 原生视口。前图保留编辑器辅助图标，后图启用 Game View；材质参数变化另由独立读回确认。相同计划重复运行时，8 个已完成步骤直接取回记录，避免再次写入。

## 工程实现

- **按需发现工具**：先获取工具目录，再获取目标工具集的实际参数定义，执行前校验 JSON Schema。工具定义保存在运行记录中。
- **持久执行**：SQLite 保存计划摘要、步骤状态、请求、返回值和时间。相同运行编号不能替换成另一份计划。
- **明确处理未完成操作**：调用开始后先写入状态；结果不明确的步骤留待读回核实。首次截图调用缺少可选结构的内部字段，失败记录仍保留，后续用新计划补齐参数。
- **独立结果检查**：执行、读回、资产保存和视口图分开记录。重启编辑器后的读回验证保存结果。
- **限定当前案例的写入范围**：只允许已实现的材质操作与指定资产保存，目标位于自建的 `/Game/EngineAgent/` 中。

独立模型循环已接入 DeepSeek Flash。CLI 同时保留模型自主执行和计划复现两种入口；文档检索和更多场景操作继续开发。

## 本地运行

需要 UE 5.8、Python 3，以及引擎自带的 ModelContextProtocol、EditorToolset 和 PythonScriptPlugin。

```powershell
python -m pip install -r requirements.txt
# 首次生成自建展台
powershell -File scripts/start_host.ps1 -BuildScene
# 启动编辑器与本地 MCP
powershell -File scripts/start_host.ps1
python -m engine_agent discover
python -m engine_agent run examples/matte-paint.json
python -m engine_agent history matte-paint-001
powershell -File scripts/stop_host.ps1
```

引擎安装路径在启动脚本中配置。项目素材通过 `Host/Content/Python/build_workshop.py` 重建，使用引擎基础形体；分发包不包含 UE 本体。

## 研究与推进

- [2026 下半年 Agent 技术调研](docs/2026下半年Agent技术调研.md)
- [长期开发目标](docs/CODEX_GOAL.md)
- [当前进度](docs/PROGRESS.md)

参考重点是工具发现、上下文组织、持续执行和结果反馈，各项能力以本项目运行结果说明。调研中的外部框架能力与后续计划分别标注。
