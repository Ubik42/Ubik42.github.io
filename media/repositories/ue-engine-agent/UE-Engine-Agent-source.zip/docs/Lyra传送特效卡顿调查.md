# 从移动热点追到传送特效准备路径

2026-11-03，独立运行 `physics-trace-20261103-001`。UE 5.7.4、D3D12、9 AI、300 刚体目标，记录 CPU / Frame / Bookmark Trace。最终 CSV 有 1937 个有效样本；Insights 分析约 5257 万个 CPU 作用域，完整会话 57.45 秒。

## 实际定位结果

在 Trace 的 53.141616–53.200201 秒区间找到一次角色移动更新，包含 941 个 GameThread 事件。开始/结束时间与 Depth 显示如下嵌套路径：

| 实际作用域 | 深度 | 包含子调用的耗时 |
|---|---:|---:|
| UCharacterMovementComponent_TickComponent | 15 | 58.583 ms |
| EndScopedMovementUpdate Time | 20 | 58.459 ms |
| USceneComponent::UpdateOverlaps | 21 | 58.387 ms |
| BeginComponentOverlap | 24 | 58.381 ms |
| B_Teleport 重叠事件 | 25 | 58.359 ms |
| ExecuteGameplayCueOnActor | 28 | 58.067 ms |
| ExecuteUbergraph_GCNL_Teleporter_Activate | 35 | 57.777 ms |
| SpawnSystemAttached | 36 | 29.484 ms |
| UNiagaraSystem::RequestCompile | 38 | 29.245 ms |

这次移动热点包含了同步执行的传送玩法与特效准备。直接优化移动积分或降低 AI 更新频率，未必能处理这条路径。`RequestCompile` 的名称与计时提示应调查 Niagara 准备过程；它尚不能证明这 29 ms 全部用于实际编译，也未证明只在首次激活出现。GCN 其余约 28 ms 的子路径仍待展开。

以上是嵌套耗时，不能相加。调查区间根据 Trace 时间选择，未建立 CSV 行号与 Trace 帧 ID 的精确映射。此次是编辑器 `-game` 开发运行，Shipping 成本需要独立验证。

## 子调用展开与编译时机实验

![真实 Trace 中两段 Niagara 准备调用](images/teleport-trace.png)

完整展开 941 个事件后，找到了两次 `RequestCompile`，分别为 27.95 / 29.25 ms。内部两次 `NiagaraAsyncTask_DigestSystem` 包含耗时为 25.43 / 26.50 ms；扣除已记录子调用后为 16.83 / 15.51 ms。该差值包含未插桩工作和等待，不能视为纯 CPU 指令执行。事件树扣除核对总计 58.5826 ms，与根事件一致。

GCN 资产的静态字符串引用包含 `NS_CharacterPortalDissolve` 和 `NS_WallPortalEnter`。这是资源定位线索，尚未在实时宿主中逐节点读回引用关系。

UE 5.7 `NiagaraSystem.cpp:204` 定义 `fx.Niagara.OnDemandCompileEnabled`，默认 2；第 818 行在值为 0 时选择加载期间发起编译。使用独立进程参数 `-DPCVars=fx.Niagara.OnDemandCompileEnabled=0` 运行候选，日志确认设置生效，未修改原工程资产与配置。

| 观察项 | 默认按需编译 | 加载时发起编译 |
|---|---:|---:|
| 调查到的运行期传送 GCN 包含耗时 | 57.7765 ms | 0.8872 ms |
| 35 秒后 RequestCompile 次数 | 2 | 0 |
| 全会话 RequestCompile 次数 | 21 | 30 |
| 全会话 RequestCompile 包含耗时合计 | 792.70 ms | 1105.59 ms |
| 最后一次 RequestCompile 结束时刻 | 53.200 s | 28.134 s |

35 秒是调查分界，未当作严格对齐的测量阶段。两次运行均出现运行期传送 GCN，候选的编译请求集中在较早阶段。这支持编译准备成本前移的解释，也显示总准备成本没有随之消失。全会话总数不同，还需核对加载集合与实际画面。

候选 `niagara-onload-trace-20261103-001` 完成 1885 帧采集，但平均刚体数 255.65，低于物理预设 285 的要求，负载有效性失败。该组只保留局部事件与编译时机观察，不能作为整帧收益。接口已分开 `capture_complete`、`workload_valid` 与 `usable_for_regression`。

原始模型回答保留在 [对照记录](evidence/performance/niagara-compile-placement)。其中“CSV 慢帧与传送事件时间不同”的说法缺少跨数据源帧映射，未采纳；后续提示词已要求保留这一未知关系。

新增 `read_trace_window` 缓存最多一秒的原始事件，返回扣除已观察子调用的热点；`read_trace_episodes` 返回完整出现次数及有限的最大事件。完整原件保留，模型上下文按窗口和事件类型逐步展开。

## Agent 已可使用

`start_capture(trace=true)` 启动独立采集；`export_trace` 用本机 Unreal Insights 离线导出；`read_trace` 按时间区间及计时器名称过滤，返回最大的 24 个事件。查询结果依据 Trace SHA、导出文件身份和参数缓存，重复问题无需重扫约 1.92 GB 的 CSV。独立 DeepSeek 两轮完成实际工具查询和路径解释，记录见 [原始证据](evidence/performance/physics-trace-001)。

```powershell
python -m engine_agent.capture start physics-trace-new --trace
python -m engine_agent.capture observe physics-trace-new
# 等同一 UE 进程退出后导出
python -m engine_agent.trace start physics-trace-new
python -m engine_agent.trace observe physics-trace-new
python -m engine_agent.trace summarize physics-trace-20261103-001 --start-time 53.141616 --end-time 53.200201
python -m engine_agent performance-agent examples/trace-movement.txt --session trace-movement-001 --output artifacts/performance/agent-trace-movement-001
```

Trace 与普通采集不能直接比较收益，工具会拒绝不同采集开关的比较。原始 `.utrace`、引擎日志和 1.92 GB 导出保存在 `artifacts/performance/jobs/physics-trace-20261103-001`，源码仓只保存摘要和模型记录。

## 本机接口核验与修复

- 参数来自 UE 5.7 `TraceInsights/Private/Insights/Tests/FunctionalTests/ExportCommandsTests.cpp`：`-NoUI -AutoQuit -ExecOnAnalysisCompleteCmd=@=...`。
- `TimingProfilerManager.cpp` 支持线程、计时器、时间范围和列筛选。命令解析使用转义规则，响应文件路径必须用 `/`。首轮错误导出的日志已归档；确认进程退出后才使用原 Trace 重新导出。
- `SceneComponent.cpp:1237` 的 `EndScopedMovementUpdate` 是对应引擎入口。后续应结合真实子调用和实现排查。
- Insights 同时报告了 MemAlloc Invalid Tag。当前只使用成功导出的 CPU 事件；这份 Trace 未证明内存分析能力。

## 下一项实验

建立适合传送场景的隔离测试入口，固定触发次数、位置和资源集合，读回实际 Niagara 引用并采集画面。继续比较首次、重复触发与加载时准备，同时记录启动开销；保持传送逻辑、特效和碰撞行为。物理案例保留原负载要求另行复测。之后推进渲染案例。
