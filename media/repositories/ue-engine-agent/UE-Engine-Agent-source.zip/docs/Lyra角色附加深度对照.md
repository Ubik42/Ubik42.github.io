# Lyra 角色附加深度裁减：一次未取得 GPU 收益的实验

Agent 读取基线、选择已有的 Custom Depth 距离策略、启动隔离候选，并读取对照结果。策略减少了参与角色数量，本次 GPU 耗时未下降。这一案例保留了被数据否定的优化预期。

## 场景与动作

UE 5.7.4、RTX 4080、D3D12、1280×720。HeroArena 固定 9 个 AI，初始视角锁定，预热 15 秒、采集 30 秒。源工程只读，运行数据使用本工程的独立 UserDir。

基线 `rendering-baseline-20261103-001` 取得 3392 帧；独立 DeepSeek API 通过工具启动 `agent-9984994981bc224e51b8`，取得 3421 帧。构建、工程文件、地图、分辨率、随机种子及采样设置一致；两次原生负载检查通过。对局中的行走、交战与重生过程仍会变化。

候选使用已有编译实现 `-LyraCharacterCustomDepthLOD`。角色超过 2400 uu 后退出 Custom Depth，距离回滞为 300 uu；主渲染和阴影保持。接口读取的是实际参与计数，尚未建立逐像素的描边质量判断。

## 实际结果

| 指标 | 基线 | 候选 |
|---|---:|---:|
| Custom Depth 角色均值 | 10.00 | 3.69 |
| Custom Depth GPU 均值 | 0.2257 ms | 0.2456 ms |
| Custom Depth GPU P95 | 0.3423 ms | 0.3456 ms |
| GPU 总时间 P95 | 6.3288 ms | 6.5358 ms |
| 整帧 P95 | 10.5476 ms | 10.2254 ms |
| 投影角色 P95 | 10 | 10 |

参与角色显著减少，Custom Depth 耗时基本持平，GPU 总时间略升。因此本组数据不支持性能收益。整帧 P95 的下降也不能归因于该策略。

CSV 阶段计时中的零值可能包含采集或上报差异。各阶段可能重叠，不能相加为 GPU 总时间。后续优先使用负载更明确的渲染场景，避免围绕这组小开销反复采样。

## 真实画面与范围

以下画面来自独立 PIE 对局中的 SceneCapture，分别在 20、25、30 秒采集。截图运行与性能运行分开，避免截图改变性能数据。它们证明实际场景、角色与特效可运行；镜头和战况不同，不能用来证明视觉等价或细小描边无损。

![基线独立 PIE 画面](images/rendering-baseline.png)

![候选独立 PIE 画面](images/rendering-candidate.png)

首次 SIE 尝试的玩家相机停在原点，画面穿入几何，已保留在本地原始任务中。改用 `EditorRequestBeginPlay` 进入真实 PIE，读取玩家相机，连续累积 SceneCapture 曝光后完成展示。

## 入口与记录

```powershell
python -m engine_agent.capture start my-render-baseline --variant RenderingBaseline
python -m engine_agent performance-agent examples/rendering-custom-depth.txt --session my-render-agent --output artifacts/performance/my-render-agent --max-turns 5
python -m engine_agent.workbench --port 8795
```

示例提示词使用已归档案例 ID；复现新任务时将其中基线 ID 改为 `my-render-baseline`。模型收到运行中状态后结束本轮，稍后以同一 run_id 读取。

[evidence/performance/rendering-custom-depth](evidence/performance/rendering-custom-depth) 保存两次完整原生摘要、压缩原始 CSV、任务命令与输入指纹、模型调用、对照指标及画面采样状态。首次模型分析曾把零值解释为 Pass 未执行，随后提示词与独立复核已纠正；保留原始模型答复以便审阅。
