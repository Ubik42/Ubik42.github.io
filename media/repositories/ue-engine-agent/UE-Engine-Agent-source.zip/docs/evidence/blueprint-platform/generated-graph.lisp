(event EventTick
  (bind t (Utilities|Time|GetGameTimeInSeconds))
  (bind angle (* t 1.5))
  (bind s (Math|Trig|Sin(Radians) angle))
  (bind z (+ 120.0 (* 80.0 s)))
  (bind loc (Math|Vector|MakeVector :X 0.0 :Y 0.0 :Z z))
  (Transformation|SetActorLocation :self self :NewLocation loc :bSweep false :bTeleport true))
