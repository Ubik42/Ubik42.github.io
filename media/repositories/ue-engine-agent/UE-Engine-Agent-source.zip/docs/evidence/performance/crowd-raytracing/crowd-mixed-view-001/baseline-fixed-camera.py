"""Transient fixed-view PIE harness. Native CSV ends before screenshot export."""
import json,os,time,traceback
from pathlib import Path
import unreal
folder=Path(os.environ['ENGINE_AGENT_FIXED_CAPTURE'])
job=json.loads((folder/'job.json').read_text(encoding='utf-8'))
result_path=Path(job['result_directory'])/'summary.json'
report={'state':'starting','camera':job['fixed_camera'],'events':[]};step=0;busy=False;started=time.monotonic();fixed=False
location=unreal.Vector(*job['fixed_camera']['location'])
target_point=unreal.Vector(*job['fixed_camera']['target'])
rotation=unreal.MathLibrary.find_look_at_rotation(location,target_point)

def save():
    (folder/'view-evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
def finish(error=None):
    report['state']='failed' if error else 'completed'
    if error:report['error']=error
    save();unreal.unregister_slate_post_tick_callback(handle)
    unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_end_play()
    unreal.EditorPythonScripting.set_keep_python_script_alive(False)

def tick(delta):
    global step,busy,fixed
    if busy:return
    busy=True
    try:
        if time.monotonic()-started>150:raise RuntimeError('Fixed-view capture timeout')
        if step==0:
            actor=unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.SceneCapture2D,location,rotation)
            actor.set_actor_label('AgentPostMeasurementCapture')
            c=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
            c.set_editor_property('capture_every_frame',False);c.set_editor_property('capture_on_movement',False)
            unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_begin_play()
            step=1;return
        world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_game_world()
        if not world:return
        seconds=unreal.GameplayStatics.get_time_seconds(world)
        pc=unreal.GameplayStatics.get_player_controller(world,0)
        if not pc:return
        view=pc.get_view_target()
        if view and isinstance(view,unreal.CameraActor) and not fixed:
            view.set_actor_location_and_rotation(location,rotation,False,True)
            view.get_component_by_class(unreal.CameraComponent).set_field_of_view(job['fixed_camera']['fov'])
            fixed=True
            report['events'].append({'kind':'fixed_view_applied','game_time':seconds,'actor':view.get_path_name(),'location':str(location),'rotation':str(rotation)})
            report['state']='measuring';save()
        if not result_path.exists():return
        data=json.loads(result_path.read_text(encoding='utf-8-sig'))
        if not data.get('artifactsFinalized'):return
        if not fixed:raise RuntimeError('Native locked CameraActor was never found')
        report['measurement_result']={k:data.get(k) for k in ('final','valid','sampleCount','warmupSeconds','measurementSeconds')}
        actors=unreal.GameplayStatics.get_all_actors_of_class(world,unreal.SceneCapture2D)
        actor=next(a for a in actors if a.get_actor_label()=='AgentPostMeasurementCapture')
        capture=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
        target=unreal.RenderingLibrary.create_render_target2d(world,1280,720,unreal.TextureRenderTargetFormat.RTF_RGBA8)
        capture.set_editor_property('texture_target',target)
        capture.set_editor_property('capture_source',unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR)
        capture.set_editor_property('fov_angle',job['fixed_camera']['fov'])
        capture.capture_scene()
        unreal.RenderingLibrary.export_render_target(world,target,str(folder),'after-measurement.png')
        report['events'].append({'kind':'image_after_csv_finalized','game_time':seconds,'image':'after-measurement.png'})
        report['characters']=[{'actor':a.get_path_name(),'location':str(a.get_actor_location()),'raytracing':a.mesh.get_editor_property('visible_in_ray_tracing'),'shadow':a.mesh.get_editor_property('cast_shadow')} for a in unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Character)]
        finish()
    except Exception:finish(traceback.format_exc())
    finally:busy=False

unreal.EditorPythonScripting.set_keep_python_script_alive(True)
handle=unreal.register_slate_post_tick_callback(tick)
