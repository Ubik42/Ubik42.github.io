"""Transient fixed-view PIE harness. Native CSV ends before screenshot export."""
import json,os,time,traceback
from pathlib import Path
import unreal
folder=Path(os.environ['ENGINE_AGENT_FIXED_CAPTURE'])
job=json.loads((folder/'job.json').read_text(encoding='utf-8'))
result_path=Path(job['result_directory'])/'summary.json'
report={'state':'starting','camera':job['fixed_camera'],'events':[]};step=0;busy=False;started=time.monotonic();fixed=False
screenshot_ticks=0;render_target=None
visual_phase='measured';body_states=[]
location=unreal.Vector(*job['fixed_camera']['location'])
target_point=unreal.Vector(*job['fixed_camera']['target'])
rotation=unreal.MathLibrary.find_look_at_rotation(location,target_point)

def save():
    (folder/'view-evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
def finish(error=None):
    report['state']='failed' if error else 'completed'
    if error:report['error']=error
    save();unreal.unregister_slate_post_tick_callback(handle)
    unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_end_play()
    unreal.EditorPythonScripting.set_keep_python_script_alive(False)

def tick(delta):
    global step,busy,fixed,screenshot_ticks,render_target,visual_phase,body_states
    if busy:return
    busy=True
    try:
        if time.monotonic()-started>150:raise RuntimeError('Fixed-view capture timeout')
        if step==0:
            if job.get('view_profile') in ('reflection','reflection_diagnostic'):
                subsystem=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
                panel=subsystem.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector(0,0,52))
                panel.set_actor_label('AgentTransientReflectionSurface')
                panel.set_actor_scale3d(unreal.Vector(20,20,1))
                mesh=panel.get_component_by_class(unreal.StaticMeshComponent)
                mesh.set_static_mesh(unreal.load_asset('/Engine/BasicShapes/Plane'))
                mesh.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
                material=unreal.load_asset('/Engine/TemplateResources/MI_Template_BaseGray_Metal')
                mesh.set_material(0,material)
                names=unreal.MaterialEditingLibrary.get_scalar_parameter_names(material)
                dynamic=mesh.create_dynamic_material_instance(0)
                values={}
                for name in names:
                    key=str(name)
                    values[key]=unreal.MaterialEditingLibrary.get_material_instance_scalar_parameter_value(material,name)
                    if 'roughness' in key.lower():dynamic.set_scalar_parameter_value(name,0.05)
                    if 'metallic' in key.lower():dynamic.set_scalar_parameter_value(name,1.0)
                report['surface']={'material':material.get_path_name(),'source_scalar_parameters':values,'location':[0,0,52],'scale':[20,20,1],'collision':False}
                save()
            actor=unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.SceneCapture2D,location,rotation)
            actor.set_actor_label('AgentPostMeasurementCapture')
            c=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
            c.set_editor_property('capture_every_frame',False);c.set_editor_property('capture_on_movement',False)
            if job.get('view_profile') in ('reflection','reflection_diagnostic'):
                c.set_editor_property('always_persist_rendering_state',True)
                c.set_editor_property('use_ray_tracing_if_enabled',True)
                settings=c.get_editor_property('post_process_settings')
                settings.set_editor_property('override_dynamic_global_illumination_method',True)
                settings.set_editor_property('dynamic_global_illumination_method',unreal.DynamicGlobalIlluminationMethod.LUMEN)
                settings.set_editor_property('override_reflection_method',True)
                settings.set_editor_property('reflection_method',unreal.ReflectionMethod.LUMEN)
                if job.get('view_profile')=='reflection_diagnostic':
                    settings.set_editor_property('override_lumen_reflections_screen_traces',True)
                    settings.set_editor_property('lumen_reflections_screen_traces',False)
                    settings.set_editor_property('override_lumen_ray_lighting_mode',True)
                    settings.set_editor_property('lumen_ray_lighting_mode',unreal.LumenRayLightingModeOverride.HIT_LIGHTING_FOR_REFLECTIONS)
                    report['visual_diagnostic']='SceneCapture only: screen traces disabled, hit lighting enabled; native measurement settings unchanged'
                c.set_editor_property('post_process_settings',settings)
                report['screenshot_rendering']={'lumen_gi':True,'lumen_reflections':True,'persistent_state':True,'use_ray_tracing_if_enabled':c.get_editor_property('use_ray_tracing_if_enabled'),'post_measurement_warmup_captures':16}
            unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_begin_play()
            step=1;return
        world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_game_world()
        if not world:return
        seconds=unreal.GameplayStatics.get_time_seconds(world)
        if 'render_settings' not in report:
            report['render_settings']={name:unreal.SystemLibrary.get_console_variable_int_value(name) for name in ('r.RayTracing','r.Lumen.HardwareRayTracing','r.ReflectionMethod','r.Lumen.Reflections.ScreenTraces','r.Lumen.Reflections.HardwareRayTracing')}
        pc=unreal.GameplayStatics.get_player_controller(world,0)
        if not pc:return
        view=pc.get_view_target()
        if view and isinstance(view,unreal.CameraActor) and not fixed:
            view.set_actor_location_and_rotation(location,rotation,False,True)
            view.get_component_by_class(unreal.CameraComponent).set_field_of_view(job['fixed_camera']['fov'])
            fixed=True
            report['events'].append({'kind':'fixed_view_applied','game_time':seconds,'actor':view.get_path_name(),'location':str(location),'rotation':str(rotation)})
            report['state']='measuring';save()
        if not result_path.exists():return
        data=json.loads(result_path.read_text(encoding='utf-8-sig'))
        if not data.get('artifactsFinalized'):return
        if not fixed:raise RuntimeError('Native locked CameraActor was never found')
        report['measurement_result']={k:data.get(k) for k in ('final','valid','sampleCount','warmupSeconds','measurementSeconds')}
        actors=unreal.GameplayStatics.get_all_actors_of_class(world,unreal.SceneCapture2D)
        actor=next(a for a in actors if a.get_actor_label()=='AgentPostMeasurementCapture')
        capture=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
        if render_target is None:
            if job.get('view_profile') in ('reflection','reflection_diagnostic'):
                paused=unreal.GameplayStatics.set_game_paused(world,True)
                report['visual_world_paused']=bool(paused)
                if not paused:raise RuntimeError('Unable to freeze visual comparison')
                body_states=[(a.mesh,bool(a.mesh.get_editor_property('visible_in_ray_tracing'))) for a in unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Character)]
                report['characters']=[{'actor':a.get_path_name(),'location':str(a.get_actor_location()),'raytracing':a.mesh.get_editor_property('visible_in_ray_tracing'),'shadow':a.mesh.get_editor_property('cast_shadow')} for a in unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Character)]
            render_target=unreal.RenderingLibrary.create_render_target2d(world,1280,720,unreal.TextureRenderTargetFormat.RTF_RGBA8)
        capture.set_editor_property('texture_target',render_target)
        capture.set_editor_property('capture_source',unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR)
        capture.set_editor_property('fov_angle',job['fixed_camera']['fov'])
        capture.capture_scene()
        screenshot_ticks+=1
        if job.get('view_profile') in ('reflection','reflection_diagnostic') and screenshot_ticks<16:return
        filename='after-measurement.png' if visual_phase=='measured' else 'body-raytracing-restored.png'
        unreal.RenderingLibrary.export_render_target(world,render_target,str(folder),filename)
        report['events'].append({'kind':'image_after_csv_finalized','game_time':seconds,'image':filename,'phase':visual_phase})
        if job.get('view_profile') in ('reflection','reflection_diagnostic') and job['experiment_variant']=='RayTracingLOD' and visual_phase=='measured':
            for mesh,enabled in body_states:mesh.set_visible_in_ray_tracing(True)
            report['body_visibility_after_restore']=sum(bool(mesh.get_editor_property('visible_in_ray_tracing')) for mesh,enabled in body_states)
            visual_phase='body_restored';screenshot_ticks=0
            report['visual_intervention']='Restore character body ray-tracing visibility after CSV only; attachments unchanged; paused world and same camera'
            return
        for mesh,enabled in body_states:mesh.set_visible_in_ray_tracing(enabled)
        if not body_states:
            report['characters']=[{'actor':a.get_path_name(),'location':str(a.get_actor_location()),'raytracing':a.mesh.get_editor_property('visible_in_ray_tracing'),'shadow':a.mesh.get_editor_property('cast_shadow')} for a in unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Character)]
        finish()
    except Exception:finish(traceback.format_exc())
    finally:busy=False

unreal.EditorPythonScripting.set_keep_python_script_alive(True)
handle=unreal.register_slate_post_tick_callback(tick)
