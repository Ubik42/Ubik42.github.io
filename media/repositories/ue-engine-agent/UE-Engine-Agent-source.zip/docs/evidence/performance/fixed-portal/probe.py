"""Runs inside UE Python. Transient effects only; never saves source assets/maps."""
import json
import os
from pathlib import Path
import time
import traceback
import unreal

folder=Path(os.environ['ENGINE_AGENT_NIAGARA_PROBE'])
report={'provenance':'Codex-authored fixed native UE fixture; not a model-generated action plan',
        'asset_loads':[],'activations':[],'state':'starting'}
assets=[];components=[];meshes=[];step=0;due=0;busy=False;capture=None;target=None;pending_repeat=None

def save():
    (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

def finish(error=None):
    if error:report['error']=error
    report['state']='failed' if error else 'completed'
    save()
    unreal.unregister_slate_post_tick_callback(handle)
    unreal.EditorPythonScripting.set_keep_python_script_alive(False)

def tick(delta):
    global step,due,components,busy,capture,target,pending_repeat
    if busy:return
    busy=True
    try:
        if time.monotonic()<due:return
        if pending_repeat is not None:
            repeat=pending_repeat;pending_repeat=None
            capture.capture_scene()
            world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
            unreal.RenderingLibrary.export_render_target(world,target,str(folder),f'repeat-{repeat}.png')
            report.setdefault('screenshots',[]).append({'repeat':repeat,'file':f'repeat-{repeat}.png','active':[c.is_active() for c in components]})
            save();due=time.monotonic()+4
            return
        if step==0:
            world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
            report['world']=world.get_path_name()
            actors=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
            mesh=unreal.load_asset('/Engine/BasicShapes/Cube')
            character=unreal.load_asset('/Game/Characters/Heroes/Mannequin/Meshes/SKM_Manny')
            for x in (0,300):
                pedestal=actors.spawn_actor_from_class(unreal.StaticMeshActor,unreal.Vector(x,0,0))
                pedestal.static_mesh_component.set_static_mesh(mesh)
                pedestal.set_actor_scale3d(unreal.Vector(2,2,.2))
                actor=actors.spawn_actor_from_class(unreal.SkeletalMeshActor,unreal.Vector(x,0,10))
                sk=actor.get_component_by_class(unreal.SkeletalMeshComponent)
                sk.set_skeletal_mesh_asset(character)
                meshes.append(sk)
            light=actors.spawn_actor_from_class(unreal.DirectionalLight,unreal.Vector(0,0,400),unreal.Rotator(pitch=-45,yaw=-30,roll=0))
            light.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
            light.light_component.set_intensity(30)
            location=unreal.Vector(450,-650,260)
            rotation=unreal.MathLibrary.find_look_at_rotation(location,unreal.Vector(150,0,100))
            light.set_actor_rotation(rotation,False)
            camera=actors.spawn_actor_from_class(unreal.SceneCapture2D,location,rotation)
            capture=camera.get_component_by_class(unreal.SceneCaptureComponent2D)
            target=unreal.RenderingLibrary.create_render_target2d(world,1280,720,unreal.TextureRenderTargetFormat.RTF_RGBA8)
            capture.set_editor_property('texture_target',target)
            capture.set_editor_property('capture_source',unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR)
            capture.set_editor_property('capture_every_frame',False)
            capture.set_editor_property('capture_on_movement',False)
            report['camera']={'location':str(camera.get_actor_location()),'rotation':str(camera.get_actor_rotation())}
            for path in ['/Game/Effects/Particles/Environmental/NS_WallPortalEnter',
                         '/Game/Effects/Particles/Environmental/NS_CharacterPortalDissolve']:
                t=time.perf_counter();asset=unreal.load_asset(path)
                if not asset:raise RuntimeError('Missing asset '+path)
                assets.append(asset)
                report['asset_loads'].append({'path':asset.get_path_name(),'load_ms':(time.perf_counter()-t)*1000})
            unreal.EditorLevelLibrary.set_level_viewport_camera_info(unreal.Vector(700,-1000,400),unreal.Rotator(-15,120,0))
            report['state']='running';save();step=1;due=time.monotonic()+5
        elif step in (1,3,5):
            for component in components:component.destroy_component(component)
            components=[]
            world=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
            for i,asset in enumerate(assets):
                t=time.perf_counter()
                component=unreal.NiagaraFunctionLibrary.spawn_system_at_location(world,asset,unreal.Vector(i*300,0,10),auto_destroy=False,auto_activate=False,pre_cull_check=False)
                if not component:raise RuntimeError('Spawn returned no component')
                component.set_force_solo(True)
                unreal.NiagaraFunctionLibrary.override_system_user_variable_skeletal_mesh_component(component,'User.SkeletalMesh',meshes[i])
                component.set_variable_float('User.PortalWidth',200)
                component.set_variable_float('User.PortalHeight',300)
                component.set_variable_vec3('User.TeleporterPosition',unreal.Vector(i*300,0,10))
                if i==0:component.set_variable_vec3('User.TeleporterPlaneDirection',unreal.Vector(0,-1,0))
                component.activate(True)
                components.append(component)
                report['activations'].append({'repeat':(step+1)//2,'asset':asset.get_path_name(),'spawn_call_ms':(time.perf_counter()-t)*1000,'component':component.get_path_name(),'active':component.is_active()})
            save();step+=1;due=time.monotonic()+2
        elif step in (2,4,6):
            repeat=step//2
            for component in components:
                component.activate(True)
                component.advance_simulation(6,1/60)
            pending_repeat=repeat
            step+=1;due=time.monotonic()+.25
        else:finish()
    except Exception:finish(traceback.format_exc())
    finally:busy=False

unreal.EditorPythonScripting.set_keep_python_script_alive(True)
handle=unreal.register_slate_post_tick_callback(tick)
