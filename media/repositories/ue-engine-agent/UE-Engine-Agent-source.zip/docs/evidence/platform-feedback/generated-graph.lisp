(event EventBeginPlay)

(event EventTick (DeltaSeconds)
  (Transformation|SetActorLocation self (Math|Vector|MakeVector 0.0 0.0 (+ 180.0 (* 55.0 (Math|Trig|Sin(Radians) (* (Utilities|Time|GetGameTimeInSeconds) 1.0))))) false true))

(event Collision|EventActorBeginOverlap (OtherActor))

