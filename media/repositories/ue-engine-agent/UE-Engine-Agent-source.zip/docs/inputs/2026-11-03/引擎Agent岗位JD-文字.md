# 游戏引擎工程师（AI Agent方向）

来源：用户提供岗位截图，2026-11-03 人工核对转录。原图保留在同目录。

## 岗位职责

1. AI 工具链开发：将引擎和性能调试工具中的底层能力抽象为 AI 可调用的结构化工具，包括 MCP Server / 引擎插件 / CLI，设计 AI 工具的调用规范，确保大模型能准确高效调用，并具备一定的扩展能力。
2. 设计并落地围绕引擎性能优化的 AI Agent 工作流：例如 CPU/GPU/内存/发热/奔溃/渲染异常等问题定位-原因分析-优化建议-回归测试-基线归档等自动化流水线。
3. 搭建 Prompt 管理、模型评测、工具调用日志等基础设施，保障 AI 工具链的稳定性和可扩展性。建立团队内部的 AI 辅助开发资产库：标准化 Markdown 提示词模板、Skill 定义文件、工具使用文档，使全团队能够复用 AI 能力。
4. 持续跟踪 AI 技术发展（例如 MCP 演进、AI Agent 框架、多模态识别等），评估并引入适合引擎场景的新技术。

## 岗位要求

1. 本科及以上，理工科背景；
2. 熟悉主流大模型 API（Claude、GPT、DeepSeek 等）的调用，具备 Harness 工程开发经验（包括但不限于 Prompt Engineering/RAG/MCP/Skill 等）。
3. 深度使用 AI 编程工具（Codex、Claud Code、Copilot、deepseek），有二次开发经验或者插件编写经验。
4. 具备游戏引擎的使用经验，包括 UnrealEngine、Unity 等引擎的开发流程和核心模块。
5. 了解 CPU、GPU、内存等性能问题的分析方法以及相关性能工具的使用（包括但不限于 Unreal Insights、RenderDoc、Visual Studio Profiler、PIX、XCode）。

转录保留截图中的“奔溃”“Claud Code”拼写；工程文档使用“崩溃”“Claude Code”。
