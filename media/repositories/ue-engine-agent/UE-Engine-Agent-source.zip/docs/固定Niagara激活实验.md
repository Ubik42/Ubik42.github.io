# 固定 Niagara 激活实验

使用 Lyra 两个原始资源，在独立 UE 5.7 编辑器进程中固定加载、参数绑定、三轮激活和画面采集。原工程资产保持只读；定位台、灯光、Manny 与 SceneCapture 只存在于内存中，退出时不保存。

![固定场景真实渲染](images/portal-fixed-scene.png)

左侧使用 NS_WallPortalEnter，右侧使用 NS_CharacterPortalDissolve。两者绑定 Manny SkeletalMeshComponent，以及传送位置、方向、宽度和高度。图中角色和定位台可辨识；当前静态截图尚不能确认完整传送/溶解时序与两项特效的独立贡献。

## 测量口径

每轮销毁旧 Niagara 组件，创建新组件，设置参数，然后调用 Activate。记录的是这段 Python→UE 调用的墙钟耗时，包括绑定工作。异步编译完成时间与整帧时间均不包含在这个数值中。

等待后，为固定画面再次重置激活并推进 6 个 1/60 秒模拟步；再隔一个回调采集 SceneCapture。每个资源有三次计时调用和三次用于画面准备的重置调用。截图中的 active 状态来自准备完成后，首轮计时结束时的 inactive 可与后续 active 同时成立。

基线 `portal-fixed-baseline-007` 的两项资源：首轮 31.105 / 30.283 ms，第二轮 0.456 / 0.244 ms，第三轮 0.766 / 0.418 ms。原始数据在 [固定实验记录](evidence/performance/fixed-portal)。

独立模型启动的候选 `probe-71c1ccb362bf52cdd562` 已完成，冻结脚本、uproject 与两个资源的 SHA-256 和基线一致。首次调用为 0.738 / 0.350 ms，后续两轮为 0.427 / 0.244 ms、0.438 / 0.243 ms。资源加载耗时从 84.29 / 121.45 ms 增至 145.35 / 165.71 ms。这是一次匹配夹具的观察，支持准备成本前移；尚未形成独立重复实验的分布。

![候选第三轮真实画面](images/portal-fixed-onload.png)

两组第三轮画面均可辨识角色、定位台和蓝色粒子。这确认了所选时刻存在渲染内容；完整生命周期、传送游戏逻辑、角色材质溶解与视觉等价仍待验证。模型另用两轮实际调用读取候选和比较结果，原始记录一并归档。

## 运行和 Agent 接口

```powershell
python -m engine_agent.niagara_probe start portal-baseline-new
python -m engine_agent.niagara_probe observe portal-baseline-new
# 同一进程退出后，再启动候选
python -m engine_agent.niagara_probe start portal-onload-new --onload
```

`start_niagara_probe` 由模型选择编译时机，生成稳定运行 ID；`read_niagara_probe` 读取状态、测量和实际 PNG，并将图像传回模型。每次启动冻结脚本、记录脚本与资源 SHA-256。独立 DeepSeek 已实际读取基线并启动 `probe-71c1ccb362bf52cdd562`，不会将固定脚本包装成模型自行生成的引擎逻辑。

## 实施记录

- 首轮截图接口重入 Slate 回调，造成重复步骤；增加 busy 保护及提前推进状态。首轮原记录保留。
- 视口截图全黑后改用 SceneCapture。修正 Python 未暴露的 C++ getter，使用按类获取组件。
- 使用动态灯光、明确的 LookAt 相机、骨骼网格绑定，并将模拟推进与渲染采集分到不同回调。真实截图由 UE 输出。
- `fixture_complete` 仅表示流程和文件齐全；图像非黑、组件 active 均不能单独证明特效正确。

下一步进入真实模拟/游戏世界，验证粒子时序和传送交互，记录编译完成与可见结果的时刻；当前编辑器夹具用于隔离组件准备开销。共享 DDC 状态、资源加载集合和启动代价需要随复测一起记录。

## SIE 实际时间推进（2026-11-03）

新增 `--simulate`，进入 `/Engine/Maps/UEDPIE_0_Entry.Entry` 并查找运行时角色与相机副本。组件在真实游戏世界中计时和更新，截图过程不重置、不手动推进模拟。每轮在请求后约 0.05 / 0.2 / 0.5 / 1 秒记录画面，每约 0.05 游戏秒观察一次 active 状态；保存实际采样时间。

基线 `portal-sie-baseline-001` 完成 193 个状态样本和 12 张时序图。独立模型读取它后启动 `probe-125b430148737ebd5cf7`，随后另一个持久会话读取和比较完成结果。两组冻结输入一致。

| 观察 | 默认按需编译 | 加载时编译 |
|---|---:|---:|
| 两资产首次调用 | 29.06 / 26.44 ms | 0.82 / 0.41 ms |
| 首次调用返回时 active | false / false | true / true |
| 两资产加载调用 | 83.40 / 110.34 ms | 107.89 / 140.71 ms |
| 后两轮调用 | 0.24–0.42 ms | 0.24–0.44 ms |

基线首次请求后约 136 ms 首次采样到 active。候选在调用返回时已经 active，后续 63 ms 的定期采样时刻不能当作其实际就绪延迟。这是进程内首次使用实验，共享 DDC 未清空，不称为冷 DDC 测试。

![SIE 候选约0.5秒的实际画面](images/portal-sie-candidate.png)

两组时序图可辨识角色、平台与蓝色粒子，基线首张状态仍为 inactive，后续出现 active。记录支持组件准备成本向加载阶段转移；它没有覆盖打包游戏、完整传送交互或总帧时间收益。首次激活序列、全部状态样本、模型调用及比较结果见 [SIE 原始证据](evidence/performance/sie-portal)。

```powershell
python -m engine_agent.niagara_probe start portal-sie-new --simulate
# 待同一进程退出，再启动候选
python -m engine_agent.niagara_probe start portal-sie-onload-new --simulate --onload
```

本条 CPU 案例已有调查、调整、同脚本 SIE 复测和实际画面。下一批进入独立渲染瓶颈案例；完整传送交互作为能力扩展，不继续用静态编辑器重复调用替代 GPU 案例。
