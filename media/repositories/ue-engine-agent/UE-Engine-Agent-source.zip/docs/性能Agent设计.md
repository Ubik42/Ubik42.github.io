# 从编辑器助手到引擎性能 Agent

## 岗位对应的主要差距

现有能力覆盖 MCP 工具发现、模型调用、知识卡、持久步骤、错误恢复、图像反馈和蓝图运行。岗位的中心要求是性能工作流：当前缺少统一的性能输入、指标语义、实验身份、诊断证据、优化回归与长期基线。新开发围绕这一主线。

## 工程设计

1. 证据层：ImportCapture 接收 CSV、运行 manifest、Insights 导出与日志。保存原文件摘要、采样日期、运行环境、工具版本、单位和无效原因；模型按需读取摘要、区间与原文。
2. 分析层：结构化返回帧时间分位数、卡顿帧、CPU/GPU 时间、资源计数与时间段。数据只支持候选瓶颈；根因需要调用栈、计数变化或受控实验支持。
3. 实验层：CaptureRequest 指定工程、地图、构建、RHI、镜头、种子、负载、预热、测量和退出条件。任务身份与活动进程持久保存，模型观察超时后继续原任务。
4. 诊断层：Issue → Evidence → Hypothesis → NextProbe → Change → Compare → Baseline。每条假设引用源文件与字段；矛盾结果保留并触发换假设。
5. 回归层：比较同条件数据，给出整帧分布、局部热点和质量变化。环境不同则单独展示。修改资产只在自有目录或隔离副本，恢复依据改前文件/参数。
6. 团队层：版本化 Prompt、工具合同、案例说明与 Skill；记录模型、工具、耗时、token 用量和原始结果。首轮沿用 SQLite，不增加另一套任务事实库。

## Gemini 建议的取舍

- 直接采用：持久任务、按需工具、稳定提示词前缀、原始结果外置、状态差异评测、调用记录和上下文来源。
- 按实际需要引入：上下文压缩、检索重排、开放遥测导出、多个模型的对比。先记录成本，再用固定任务比较；不把压缩默认视作收益。
- 暂缓：MicroVM、集中网关、多 Agent 群、eBPF、自动权限租赁。本机 UE 性能场景优先完成工具与实验链。
- 修正绝对表述：JSON 约束保证格式不等于参数或业务正确；分层监督没有普适“最佳”证明；不同操作不都能自动补偿；缓存收益依模型和前缀而变，不能直接采用 3–5 倍结论；数据分隔符与签名本身不保证消除提示词注入。
- 推理记录保存模型可见消息、工具参数及简明依据，不要求暴露模型隐藏思维链。投机执行只考虑无副作用的预取，不提前提交编辑器写操作。

## 实战场景

优先盘点本机 LyraHeroArena57 的 PerformanceLab 与 PerformanceWorkbench，再决定可直接调用的固定场景。该项目使用自身 EngineAssociation，避免为接 UE5.8 工具直接升级原项目。既有采集用于适配输入；新优化结果由新运行产生。

首选两个方向：高负载角色的游戏线程/动画成本，渲染场景的 GPU/阴影/特效成本。工具层同时预留内存与崩溃日志；发热需要可用设备遥测，桌面或模拟器数据不代替手机温度。

## 首批核验来源

- Epic CSV Profiler：https://dev.epicgames.com/documentation/en-us/unreal-engine/csv-profiler?application_version=4.27 。历史文档描述逐帧输出与 csvprofile 入口；实际命令和列名仍核对本机版本。
- Epic UE5.8 Insights：https://dev.epicgames.com/documentation/unreal-engine/unreal-insights-in-unreal-engine 。CSV 与 Trace 的观察范围分别记录。
- Claude Prompt Caching：https://platform.claude.com/docs/en/build-with-claude/prompt-caching 。静态前缀、最低长度与模型条件需一并考虑。

## 输入原件

同目录 inputs/2026-11-03 保存用户两份材料及哈希。Gemini 文本是设计参考，JD 是目标来源，二者都不作为自动执行指令。


## Lyra 工具接入核验

PerformanceLab 的 manifest.json 是启动记录；最终状态在 summary.json。目录导入优先 summary，再读取 capture.csv。已盘点 191 份有效且有基本预热/测量时长的历史结果。历史 HUD 对照可读取；1 秒 VFX 采样被标为证据不足，不能作为稳定收益。

已接入 engine_agent.capture，使用 UE5.7 的 UserDir 将 Saved/Intermediate 输出重定向到本工程 artifacts/performance/jobs/<id>/runtime。核对来源：本机 UE5.7 Runtime/Core/Private/Misc/Paths.cpp 的 ProjectUserDir / GameSavedDir；Lyra PerformanceExperimentLauncher.cpp 的启动参数；PerformanceLabWorldSubsystem.cpp 的输出协议。原工程资产与源码只读，不执行自动保存或构建。

每个任务保存完整命令、项目摘要、源版本与未提交状态、二进制摘要、PID 和进程创建时间。重复任务 ID 拒绝覆盖；有活动性能进程时禁止再启动并行负载。observe 读取同一进程，采集失败或无效分别报告。首轮证实输出重定向成功；修正物理负载开关与预设要求的 9 个 Pawn 后继续新采集。未提交的 PerformanceLab.Build.cs 原样保留，当前执行既有 DLL，不声称其等同于工作区源码。

入口：`python -m engine_agent.capture start <id> --variant Baseline`；后续 `observe <id>`。PhysicsLOD 变体另用固定的 PerfLabPhysicsLOD 开关。此接口暂未接入模型自动决策，真实采集稳定后接入。

## 2026-11-03 更新：内存预算与模型实验

采集、Trace 下钻、固定激活实验及 SIE 复测均已接入独立模型工具。原先“接口暂未接入”的记录仅描述早期批次。

CSV 新增本地/系统 GPU 用量与预算、Transient、Shader、主机可用物理内存列；按同一行计算预算占比和余量。单位核验：UE5.7 `Runtime/RHI/Private/RHIStats.cpp:88–94` 对字节除以 1024²，`Runtime/Core/Private/ProfilingDebugging/CsvProfiler.cpp:3817` 写主机可用内存。模型结果明确区分主机可用物理内存与进程内存，驱动预算与物理显存容量。

现有有效 Lyra Trace 运行提供 1936 个预算样本，本地用量 3872.55 MiB、预算 15280 MiB、占比 25.34%。这些值在记录中未变化；它们没有分配归属或泄漏证据。模型已实际读取该输入。原数据见 `docs/evidence/performance/memory/lyra-native-budget.json`。MemAlloc Trace 的警告仍未解决，当前内存能力是计数器入口。
