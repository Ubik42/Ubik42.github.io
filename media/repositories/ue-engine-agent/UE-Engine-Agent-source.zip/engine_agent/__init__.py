"""UE Engine Agent: local tool discovery and durable execution."""
