import argparse
import json
from pathlib import Path
from .mcp import Client, text
from .runtime import Runtime

p = argparse.ArgumentParser()
p.add_argument('command', choices=['discover', 'describe', 'run', 'history'])
p.add_argument('value', nargs='?')
p.add_argument('--endpoint', default='http://127.0.0.1:18086/mcp')
p.add_argument('--output', type=Path, default=Path('artifacts/session'))
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)
if a.command == 'history':
    result = Runtime(a.output, None).export(a.value)
else:
    client = Client(a.endpoint)
    hello = client.initialize()
    if a.command == 'discover':
        result = {'server': hello, 'catalog': client.tool('list_toolsets')}
    elif a.command == 'describe':
        result = client.tool('describe_toolset', {'toolset_name': a.value})
    else:
        result = Runtime(a.output, client).execute(json.loads(Path(a.value).read_text(encoding='utf-8-sig')))
name = a.command + '.json'
(a.output / name).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
