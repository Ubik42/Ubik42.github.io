import sys
if hasattr(sys.stdout,"reconfigure"):sys.stdout.reconfigure(encoding="utf-8")
import argparse
import json
from pathlib import Path
from .mcp import Client, text
from .runtime import Runtime

p = argparse.ArgumentParser()
p.add_argument('command', choices=['discover', 'describe', 'run', 'history', 'agent', 'recover', 'snapshot-layout', 'research', 'search', 'performance-agent'])
p.add_argument('value', nargs='?')
p.add_argument('--endpoint', default='http://127.0.0.1:18086/mcp')
p.add_argument('--output', type=Path, default=Path('artifacts/session'))
p.add_argument('--session', default='autonomous-001')
p.add_argument('--model', default='deepseek-flash')
p.add_argument('--max-turns', type=int, default=18)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)
if a.command == 'search':
    from .knowledge import search
    result = search(a.value)
elif a.command == 'performance-agent':
    from .agent import Agent
    result = Agent(a.output,None,a.model,performance_only=True).run(a.session,Path(a.value).read_text(encoding='utf-8-sig'),a.max_turns)
elif a.command == 'research':
    from .agent import Agent
    result = Agent(a.output,None,a.model,knowledge_only=True).run(a.session,Path(a.value).read_text(encoding='utf-8-sig'),a.max_turns)
elif a.command == 'history':
    result = Runtime(a.output, None).export(a.value)
else:
    client = Client(a.endpoint)
    hello = client.initialize()
    if a.command == 'discover':
        result = {'server': hello, 'catalog': client.tool('list_toolsets')}
    elif a.command == 'describe':
        result = client.tool('describe_toolset', {'toolset_name': a.value})
    elif a.command == 'snapshot-layout':
        from .layout import snapshot
        result = snapshot(a.output,client)
    elif a.command == 'recover':
        from .agent import Agent
        result = Agent(a.output, client, a.model).recover(a.session)
    elif a.command == 'agent':
        from .agent import Agent
        result = Agent(a.output, client, a.model).run(a.session, Path(a.value).read_text(encoding='utf-8-sig'), a.max_turns)
    else:
        result = Runtime(a.output, client).execute(json.loads(Path(a.value).read_text(encoding='utf-8-sig')))
name = a.command + '.json'
(a.output / name).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
