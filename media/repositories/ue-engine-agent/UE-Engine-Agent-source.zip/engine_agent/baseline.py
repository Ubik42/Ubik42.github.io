"""Immutable, self-contained comparison archives with raw capture hashes."""
import gzip,hashlib,json,shutil,tempfile,time
from pathlib import Path
from .capture import ROOT,validate_id,observe,write
from .performance_tools import read_capture,compare_jobs

def archive(case_id,baseline_id,candidate_id,assessment,session='manual'):
    validate_id(case_id);validate_id(baseline_id);validate_id(candidate_id)
    if not 1<=len(assessment)<=4000:raise ValueError('Assessment must contain 1–4000 characters')
    parent=ROOT/'artifacts/performance/baselines';parent.mkdir(parents=True,exist_ok=True)
    dest=parent/case_id
    request={'case_id':case_id,'baseline_id':baseline_id,'candidate_id':candidate_id,'assessment':assessment,'author_session':session}
    if dest.exists():
        saved=json.loads((dest/'manifest.json').read_text(encoding='utf-8'))
        if saved['request']!=request:raise ValueError('Archived case identity differs; choose a new case ID')
        return saved
    report=compare_jobs(baseline_id,candidate_id)
    if report.get('pending'):return {'pending':True,'case_id':case_id,'comparison':report}
    scratch=Path(tempfile.mkdtemp(prefix=case_id+'-',dir=parent))
    try:
        for label,run in [('baseline',baseline_id),('candidate',candidate_id)]:
            job=observe(run);source=Path(job['result_directory'])
            write(scratch/(label+'-job.json'),job)
            write(scratch/(label+'-metrics.json'),read_capture(run))
            raw=(source/'capture.csv').read_bytes()
            with gzip.open(scratch/(label+'-capture.csv.gz'),'wb') as out:out.write(raw)
            shutil.copyfile(source/'summary.json',scratch/(label+'-summary.json'))
            job_folder=ROOT/'artifacts/performance/jobs'/run
            for name in ('fixed-camera.py','view-evidence.json','after-measurement.png','body-raytracing-restored.png'):
                if (job_folder/name).exists():shutil.copyfile(job_folder/name,scratch/(label+'-'+name))
        write(scratch/'comparison.json',report)
        files={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in scratch.iterdir()}
        result={'schema':'performance-baseline-archive@1','request':request,'created_at':time.time(),
                'comparison_qualified':report['comparable'],'directory':str(dest),'files':files,
                'meaning':'Immutable observation archive. Assessment is attributed text; archiving does not certify benefit or causality.'}
        write(scratch/'manifest.json',result)
        scratch.rename(dest)
        return result
    finally:
        if scratch.exists():
            if not scratch.resolve().is_relative_to(parent.resolve()):raise RuntimeError("Archive cleanup escaped baseline directory")
            shutil.rmtree(scratch)
