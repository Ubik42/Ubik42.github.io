"""Owned Lyra performance jobs: start once, observe persisted identity."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import tempfile
import threading
import psutil
ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get("ENGINE_AGENT_LYRA_PROJECT", "D:/3D/UE Projects/LyraHeroArena57/LyraStarterGame.uproject"))
EDITOR=Path(os.environ.get("ENGINE_AGENT_LYRA_EDITOR", "C:/Program Files/Epic Games/UE_5.7/Engine/Binaries/Win64/UnrealEditor.exe"))

_WRITE_LOCK=threading.RLock()

def write(path,data):
    # HTTP readers can observe the same job concurrently. Each atomic write owns its temp file.
    with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=path.parent,suffix=".tmp",delete=False) as stream:
        temp=Path(stream.name)
        json.dump(data,stream,ensure_ascii=False,indent=2)
    try:
        with _WRITE_LOCK:
            for attempt in range(6):
                try:
                    os.replace(temp,path)
                    break
                except PermissionError:
                    if attempt==5:raise
                    time.sleep(.01*(attempt+1))
    finally:temp.unlink(missing_ok=True)

def validate_id(run_id):
    if not run_id or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in run_id):raise ValueError("Invalid run ID")

VARIANTS = ("Baseline", "PhysicsLOD", "NiagaraCompileOnLoad", "RenderingBaseline", "CustomDepthLOD", "CrowdRenderingBaseline", "RayTracingLOD")

VIEW_PROFILES = {
    "overview": {"location": [-2600,-3000,1800], "target": [0,0,150], "fov": 90},
    "mixed": {"location": [-1100,-1500,650], "target": [350,400,100], "fov": 90},
    "reflection": {"location": [-1100,-1500,650], "target": [350,400,100], "fov": 90, "surface": "engine-metal-plane@1"},
    "reflection_diagnostic": {"location": [-1100,-1500,650], "target": [350,400,100], "fov": 90, "surface": "engine-metal-plane@1", "visual_diagnostic": "no-screen-traces-hit-lighting"},
}

def source_identity(project):
    root=project.parent.resolve()
    try:
        gitroot=Path(subprocess.check_output(['git','-C',str(root),'rev-parse','--show-toplevel'],stderr=subprocess.DEVNULL,text=True).strip()).resolve()
        if gitroot!=root:return {'source_revision':'unversioned','source_status':'Project is nested in another repository; no source revision assigned'}
        return {'source_revision':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),
                'source_status':subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True)}
    except (OSError,subprocess.CalledProcessError):
        return {'source_revision':'unversioned','source_status':'No project Git revision; binary and project hashes remain recorded'}

def start(run_id,variant="Baseline",trace=False,view_profile="overview"):
    if view_profile not in VIEW_PROFILES:raise ValueError("Unknown view profile")
    if view_profile != "overview" and variant not in ("CrowdRenderingBaseline","RayTracingLOD"):raise ValueError("View profile requires crowd capture")
    validate_id(run_id)
    from .rendering_probe import observe as observe_render
    for previous in (ROOT/"artifacts/performance/render-probes").glob("*/job.json"):
        if observe_render(previous.parent.name).get("alive"):raise RuntimeError("An owned rendering probe is active")
    if variant not in VARIANTS:raise ValueError("Unknown capture variant")
    from .niagara_probe import observe as observe_probe
    for previous in (ROOT/"artifacts/performance/niagara-probes").glob("*/job.json"):
        if observe_probe(previous.parent.name).get("alive"):raise RuntimeError("An owned Niagara probe is active; observe it before starting another")
    for previous in (ROOT/"artifacts/performance/jobs").glob("*/job.json"):
        if observe(previous.parent.name).get("alive"):raise RuntimeError("An owned performance job is active; observe it before starting another")
    directory=ROOT/"artifacts/performance/jobs"/run_id
    directory.mkdir(parents=True,exist_ok=False)
    run_dir=directory/"runtime/Saved/PerformanceLab/Runs"/run_id
    command=[str(EDITOR),str(PROJECT),"/ShooterMaps/Maps/L_Convolution_Blockout?NumBots=9",
        "-game","-Experience=B_HeroArena_ControlPoints","-PerfLab","-PerfLabPresetId=hero-arena-physics",
        "-PerfLabDimension=Physics","-PerfLabVariant="+("Baseline" if variant=="NiagaraCompileOnLoad" else variant),"-PerfLabAgents=9","-PerfLabPhysicsBodies=300",
        "-PerfLabPhysicsLoad","-PerfLabSeed=1337","-PerfLabWarmup=10","-PerfLabDuration=20","-PerfLabReadyTimeout=90",
        "-PerfLabRunId="+run_id,"-PerfLabAutoExit","-windowed","-ResX=1280","-ResY=720",
        "-csvGpuStats","-RenderOffscreen","-NoSound","-Unattended","-NoSplash","-NoCrashDialog",
        "-UserDir="+str(directory/"runtime")+"/","-abslog="+str(directory/"engine.log")]
    if variant in ("RenderingBaseline", "CustomDepthLOD"):
        replacements = {
            "-PerfLabPresetId=hero-arena-physics": "-PerfLabPresetId=hero-arena-character-rendering",
            "-PerfLabDimension=Physics": "-PerfLabDimension=Rendering",
            "-PerfLabVariant="+variant: "-PerfLabVariant="+("Optimized" if variant=="CustomDepthLOD" else "Baseline"),
            "-PerfLabWarmup=10": "-PerfLabWarmup=15",
            "-PerfLabDuration=20": "-PerfLabDuration=30",
        }
        command=[replacements.get(arg,arg) for arg in command if arg not in ("-PerfLabPhysicsBodies=300", "-PerfLabPhysicsLoad")]
        if variant=="CustomDepthLOD":command.append("-LyraCharacterCustomDepthLOD")
    if variant in ("CrowdRenderingBaseline", "RayTracingLOD"):
        replacements = {
            "/ShooterMaps/Maps/L_Convolution_Blockout?NumBots=9": "/ShooterCore/Maps/L_ShooterPerf?NumBots=200",
            "-Experience=B_HeroArena_ControlPoints": "-Experience=B_ShooterGame_Perf",
            "-PerfLabDimension=Physics": "-PerfLabDimension=RenderingLOD",
            "-PerfLabVariant="+variant: "-PerfLabVariant="+("Optimized" if variant=="RayTracingLOD" else "Baseline"),
            "-PerfLabAgents=9": "-PerfLabAgents=200",
            "-PerfLabWarmup=10": "-PerfLabWarmup=5",
            "-PerfLabDuration=20": "-PerfLabDuration=15",
        }
        # Empty preset ID selects native MakeCrowd200, preserving its original guards.
        command=[replacements.get(arg,arg) for arg in command if arg not in ("-PerfLabPresetId=hero-arena-physics", "-PerfLabPhysicsBodies=300", "-PerfLabPhysicsLoad")]
        command.extend(["-PerfLabCrowdStateMachine","-PerfLabNavigationLoad"])
        if variant=="RayTracingLOD":command.append("-LyraCharacterRayTracingLOD")
    if variant=="PhysicsLOD":command.append("-PerfLabPhysicsLOD")
    if variant=="NiagaraCompileOnLoad":command.append("-DPCVars=fx.Niagara.OnDemandCompileEnabled=0")
    if trace:
        command.extend(["-trace=cpu,frame,bookmark", "-statnamedevents", "-tracefile="+str(directory/"capture.utrace")])
    env=os.environ.copy()
    fixture={}
    if variant in ("CrowdRenderingBaseline","RayTracingLOD"):
        script=directory/"fixed-camera.py"
        script.write_bytes((ROOT/"scripts/ue_fixed_camera_capture.py").read_bytes())
        command=[arg.split("?",1)[0] if arg.startswith("/ShooterCore/Maps/") else arg for arg in command if arg not in ("-game","-PerfLabAutoExit")]
        command.append("-NumBots=200")
        command.extend(["-EnablePlugins=PythonScriptPlugin,EditorScriptingUtilities","-ExecutePythonScript="+str(script)])
        env["ENGINE_AGENT_FIXED_CAPTURE"]=str(directory)
        fixture={"capture_mode":"fixed-view-PIE@1","fixture_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),
                 "view_profile":view_profile,"fixed_camera":VIEW_PROFILES[view_profile]}
    binaries=[PROJECT.parent/"Binaries/Win64/UnrealEditor-LyraGame.dll",PROJECT.parent/"Plugins/PerformanceLab/Binaries/Win64/UnrealEditor-PerformanceLab.dll"]
    record={"binary_sha256":{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in binaries},"schema":"engine-performance-job@1","run_id":run_id,"state":"launching","created_at":time.time(),
        "command":command,"experiment_variant":variant,"trace_enabled":trace,"result_directory":str(run_dir),"project":str(PROJECT),
        "project_sha256":hashlib.sha256(PROJECT.read_bytes()).hexdigest(),
        **source_identity(PROJECT)}
    record.update(fixture)
    command.append("-PerfLabSourceRevision="+record["source_revision"])
    write(directory/"job.json",record)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    try:
        process=subprocess.Popen(command,cwd=PROJECT.parent,env=env,startupinfo=startup,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        record.update(state="running",pid=process.pid,process_created_at=psutil.Process(process.pid).create_time())
    except Exception as error:
        record.update(state="launch_failed",error=str(error));write(directory/"job.json",record);raise
    write(directory/"job.json",record)
    return record

def observe(run_id):
    validate_id(run_id)
    directory=ROOT/"artifacts/performance/jobs"/run_id
    path=directory/"job.json";record=json.loads(path.read_text(encoding="utf-8"))
    if record.get("pid"):
        try:p=psutil.Process(record["pid"]);alive=p.create_time()==record["process_created_at"] and p.is_running()
        except psutil.NoSuchProcess:alive=False
    else:alive=False
    summary=Path(record["result_directory"])/"summary.json"
    result=None
    if summary.exists():
        try:result=json.loads(summary.read_text(encoding="utf-8-sig"))
        except (OSError,ValueError):pass
    record["alive"]=alive
    if alive:record["state"]="running"
    elif result and result.get("final"):
        record["state"]="completed" if result.get("valid") else "completed_invalid"
    elif record["state"] not in ("launching","launch_failed"):record["state"]="exited_without_final_result"
    if result:record["result_status"]={k:result.get(k) for k in ("runId","final","valid","sampleCount","rhiName")}
    record["observed_at"]=time.time();write(path,record);return record

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("command",choices=["start","observe"])
    parser.add_argument("run_id");parser.add_argument("--variant",choices=VARIANTS,default="Baseline")
    parser.add_argument("--trace",action="store_true")
    parser.add_argument("--view-profile",choices=VIEW_PROFILES,default="overview")
    a=parser.parse_args();result=start(a.run_id,a.variant,a.trace,a.view_profile) if a.command=="start" else observe(a.run_id)
    print(json.dumps(result,ensure_ascii=False,indent=2))
