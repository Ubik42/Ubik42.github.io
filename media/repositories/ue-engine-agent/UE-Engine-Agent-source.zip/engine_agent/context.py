"""Bound request history without modifying the durable transcript."""
import hashlib
import json


def request_context(messages, tools, max_chars=100_000):
    """Keep system+intent and complete recent assistant/tool groups.

    Character budget is deterministic, not a claim of exact tokenizer usage.
    Images count as references here; transport separately limits image history.
    """
    def size(value):
        return len(json.dumps(value, ensure_ascii=False, separators=(',', ':')))
    tools_size=size(tools)
    full=size(messages)+tools_size
    meta={'policy':'complete-turn-window@1','original_chars':full,'max_chars':max_chars,
          'omitted_messages':0,'transcript_sha256':hashlib.sha256(json.dumps(messages,ensure_ascii=False).encode()).hexdigest()}
    if full<=max_chars:
        meta['request_chars']=full
        return messages,meta
    prefix=messages[:2]
    starts=[i for i in range(2,len(messages)) if messages[i]['role']=='assistant']
    if not starts:
        raise ValueError('Initial intent exceeds context budget; shorten it or reference a local artifact')
    for start in starts:
        if start==2:continue
        note={'role':'user','content':f'历史上下文已按完整工具轮次收起 {start-2} 条消息；完整记录仍保存在当前会话数据库。需要旧结果时使用 read_history，或按已知 run_id 重新读取证据。不得把收起的内容当成未执行。'}
        candidate=prefix+[note]+messages[start:]
        count=size(candidate)+tools_size
        if count<=max_chars:
            meta.update(request_chars=count,omitted_messages=start-2)
            return candidate,meta
    raise ValueError('Latest complete tool turn exceeds context budget; use bounded artifact queries')
