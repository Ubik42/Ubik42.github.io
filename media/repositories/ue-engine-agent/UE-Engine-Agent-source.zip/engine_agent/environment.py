"""Read-only discovery of configured hosts and scenario-specific dependencies."""
import json
from pathlib import Path
from .capture import PROJECT, EDITOR


def inspect(project=PROJECT, editor=EDITOR):
    project,editor=Path(project),Path(editor)
    root=project.parent
    groups={
        'crowd_raytracing':[
            'Binaries/Win64/UnrealEditor-LyraGame.dll',
            'Plugins/PerformanceLab/Binaries/Win64/UnrealEditor-PerformanceLab.dll',
            'Plugins/GameFeatures/ShooterCore/Content/Maps/L_ShooterPerf.umap',
            'Plugins/GameFeatures/ShooterCore/Content/Experiences/B_ShooterGame_Perf.uasset'],
        'niagara_activation':[
            'Binaries/Win64/UnrealEditor-LyraGame.dll',
            'Content/Effects/Particles/Environmental/NS_WallPortalEnter.uasset',
            'Content/Effects/Particles/Environmental/NS_CharacterPortalDissolve.uasset'],
        'hero_arena_experiments':[
            'Binaries/Win64/UnrealEditor-LyraGame.dll',
            'Plugins/PerformanceLab/Binaries/Win64/UnrealEditor-PerformanceLab.dll',
            'Plugins/GameFeatures/HeroArena/Content/Experiences/B_HeroArena_ControlPoints.uasset',
            'Plugins/GameFeatures/ShooterMaps/Content/Maps/L_Convolution_Blockout.umap'],
    }
    common=[str(p) for p in (project,editor) if not p.is_file()]
    scenarios={name:{'files_present':not common and all((root/p).is_file() for p in paths),
                     'missing':common+[str(root/p) for p in paths if not (root/p).is_file()]}
               for name,paths in groups.items()}
    return {'project':str(project),'editor':str(editor),'scenarios':scenarios,
            'meaning':'File discovery only. Build compatibility and runtime validity are established by actual runs.',
            'setup':'integrations/lyra57/README.md'}


if __name__=='__main__':
    print(json.dumps(inspect(),ensure_ascii=False,indent=2))
