"""Bounded native log evidence for owned captures."""
import hashlib
from .capture import ROOT,validate_id

def read_log(run_id,contains,limit=20):
    validate_id(run_id)
    if not 1<=len(contains)<=120 or not 1<=limit<=30:raise ValueError('Expected a bounded literal log query')
    path=ROOT/'artifacts/performance/jobs'/run_id/'engine.log';raw=path.read_bytes()
    matches=[{'line':index,'text':line[:1400]} for index,line in enumerate(raw.decode('utf-8',errors='replace').splitlines(),1) if contains.casefold() in line.casefold()]
    first=(limit+1)//2;last=limit-first
    selected=matches if len(matches)<=limit else matches[:first]+(matches[-last:] if last else [])
    return {'run_id':run_id,'query':contains,'source_sha256':hashlib.sha256(raw).hexdigest(),'matching_lines':len(matches),
            'lines':selected,'truncated':len(matches)>limit,'source':str(path),
            'interpretation':'Literal native log excerpts. Line timestamps and messages are evidence; causal interpretation remains separate.'}
