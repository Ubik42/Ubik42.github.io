import json
import urllib.request
from urllib.parse import urlparse


class McpError(RuntimeError):
    pass


class Client:
    """Small synchronous Streamable HTTP client for the local Unreal server."""
    def __init__(self, endpoint, timeout=90):
        parsed = urlparse(endpoint)
        if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost'):
            raise ValueError('Use a local Unreal MCP endpoint')
        self.endpoint, self.timeout, self.session, self.seq = endpoint, timeout, '', 0
        self.protocol = '2025-11-25'

    def request(self, method, params=None, notification=False):
        self.seq += 1
        payload = {'jsonrpc': '2.0', 'method': method}
        if not notification:
            payload['id'] = self.seq
        if params is not None:
            payload['params'] = params
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        if self.session:
            headers.update({'Mcp-Session-Id': self.session, 'Mcp-Protocol-Version': self.protocol})
        req = urllib.request.Request(self.endpoint, json.dumps(payload).encode(), headers)
        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            self.session = response.headers.get('Mcp-Session-Id', self.session)
            body = response.read().decode('utf-8-sig')
            kind = response.headers.get('Content-Type', '')
        if not body.strip():
            return {}
        if 'event-stream' in kind:
            candidates = []
            for event in body.replace('\r\n', '\n').split('\n\n'):
                data = '\n'.join(line[5:].lstrip() for line in event.splitlines() if line.startswith('data:'))
                if data:
                    candidates.append(json.loads(data))
            result = next((x for x in candidates if x.get('id') == payload.get('id')), None)
            if result is None:
                raise McpError('No matching JSON-RPC response in SSE')
        else:
            result = json.loads(body)
        if result.get('error'):
            raise McpError(str(result['error']))
        return result.get('result', {})

    def initialize(self):
        result = self.request('initialize', {'protocolVersion': self.protocol, 'capabilities': {},
                              'clientInfo': {'name': 'UE-Engine-Agent', 'version': '0.1.0'}})
        self.protocol = result.get('protocolVersion', self.protocol)
        self.request('notifications/initialized', notification=True)
        return result

    def tool(self, name, arguments=None):
        result = self.request('tools/call', {'name': name, 'arguments': arguments or {}})
        if result.get('isError'):
            raise McpError(json.dumps(result, ensure_ascii=False))
        return result

    def call(self, toolset, tool, arguments):
        return self.tool('call_tool', {'toolset_name': toolset, 'tool_name': tool, 'arguments': arguments})


def text(result):
    return '\n'.join(x.get('text', '') for x in result.get('content', []) if x.get('type') == 'text')
