"""Bounded, source-addressable memory changes from native CSV counters."""
import csv
import hashlib
import io
import math
from pathlib import Path
from .performance import COLUMNS


def analyze(path):
    raw=Path(path).read_bytes()
    reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    headers=reader.fieldnames or []
    names=['frame_ms','live_characters','gpu_local_used_mb','gpu_local_budget_mb',
           'gpu_system_used_mb','gpu_system_budget_mb','transient_used_mb','shader_memory_mb','host_free_memory_mb']
    columns={k:next((c for c in COLUMNS[k] if c in headers),None) for k in names}
    rows=[]
    for line,row in enumerate(reader,2):
        values={'csv_line':line}
        for key,column in columns.items():
            try:value=float(row[column])
            except (TypeError,ValueError,KeyError):continue
            if math.isfinite(value) and value>=0:values[key]=value
        if values.get('frame_ms',0)<=0:continue
        rows.append(values)
    metrics={}
    for key in names:
        if not key.endswith('_mb'):continue
        series=[r for r in rows if key in r]
        if not series:continue
        changes=[{'from_csv_line':a['csv_line'],'to_csv_line':b['csv_line'],
                  'delta_mib':b[key]-a[key],'before':a,'after':b} for a,b in zip(series,series[1:])]
        metrics[key]={'column':columns[key],'unit':'MiB','samples':len(series),
                      'first':series[0][key],'last':series[-1][key],
                      'net_change':series[-1][key]-series[0][key],
                      'minimum':min(r[key] for r in series),'maximum':max(r[key] for r in series),
                      'largest_growth':max((r for r in changes if r['delta_mib']>0),key=lambda r:r['delta_mib'],default=None),
                      'largest_release':min((r for r in changes if r['delta_mib']<0),key=lambda r:r['delta_mib'],default=None)}
    pressure={}
    for pool in ('local','system'):
        used,budget='gpu_'+pool+'_used_mb','gpu_'+pool+'_budget_mb'
        valid=[r for r in rows if used in r and r.get(budget,0)>0]
        if valid:
            peak=max(valid,key=lambda r:r[used]/r[budget])
            pressure[pool]={'paired_samples':len(valid),'peak_ratio':peak[used]/peak[budget],
                            'peak_csv_line':peak['csv_line'],'used_mib':peak[used],'budget_mib':peak[budget],
                            'first_paired_csv_line':valid[0]['csv_line'],'last_paired_csv_line':valid[-1]['csv_line'],
                            'paired_used_net_change_mib':valid[-1][used]-valid[0][used],
                            'zero_budget_samples':sum(r.get(budget)==0 for r in rows),
                            'samples_at_or_above_90pct':sum(r[used]>=r[budget]*.9 for r in valid)}
    indices=sorted({round(i*(len(rows)-1)/31) for i in range(32)}) if rows else []
    return {'schema':'memory-timeline@1','source':str(path),'sha256':hashlib.sha256(raw).hexdigest(),
            'sample_count':len(rows),'metrics':metrics,'budget_pressure':pressure,
            'sampled_timeline':[rows[i] for i in indices],
            'interpretation':{'time_axis':'CSV record order; no claimed wall-clock or Trace alignment',
                'growth':'Counter growth can reflect resources, caching or allocator retention; it does not identify a leak',
                'missing_interval':'Null growth/release means no corresponding counter change was observed',
                'host_free_memory':'System-wide available memory, not memory allocated by this process',
                'zero_budget':'Pressure ratios exclude zero budgets. Raw metrics preserve those records; zero does not establish an initialization cause. Paired net change and raw net change are different statistics.',
                'allocation_attribution':'Unavailable in these counters; requires allocation/call-stack tracing'}}


def read(run_id):
    from .capture import observe,validate_id
    validate_id(run_id)
    job=observe(run_id)
    if job['state'] not in ('completed','completed_invalid'):
        return {'run_id':run_id,'pending':True,'state':job['state']}
    from .performance_tools import read_capture
    capture=read_capture(run_id)['capture']
    return {'run_id':run_id,'usable_for_regression':capture['usable_for_regression'],
            'quality_cautions':capture['quality_cautions'],
            **analyze(Path(job['result_directory'])/'capture.csv')}
