"""Isolated native-editor activation fixture using source Lyra assets read-only."""
import argparse
import hashlib
import json
import os
import subprocess
import time
import psutil
from .capture import ROOT,EDITOR,PROJECT,validate_id,write,observe as observe_capture

def observe(run_id):
    validate_id(run_id)
    folder=ROOT/'artifacts/performance/niagara-probes'/run_id
    job=json.loads((folder/'job.json').read_text(encoding='utf-8'))
    if not job.get('pid'):return job
    try:
        p=psutil.Process(job['pid']);alive=p.is_running() and p.create_time()==job['process_created_at']
    except psutil.NoSuchProcess:alive=False
    job['alive']=alive
    result=folder/'result.json'
    if result.exists():job['result']=json.loads(result.read_text(encoding='utf-8'))
    job['state']='running' if alive else job.get('result',{}).get('state','exited_without_result')
    write(folder/'job.json',job);return job

def start(run_id,onload=False,simulate=False):
    validate_id(run_id)
    from .rendering_probe import observe as observe_render
    for previous in (ROOT/"artifacts/performance/render-probes").glob("*/job.json"):
        if observe_render(previous.parent.name).get("alive"):raise RuntimeError("An owned rendering probe is active")
    parent=ROOT/'artifacts/performance/niagara-probes'
    for path in parent.glob('*/job.json'):
        if observe(path.parent.name)['alive']:raise RuntimeError('An existing probe is running')
    for path in (ROOT/'artifacts/performance/jobs').glob('*/job.json'):
        if observe_capture(path.parent.name)['alive']:raise RuntimeError('A performance capture is running')
    folder=parent/run_id;folder.mkdir(parents=True,exist_ok=False)
    script=folder/'probe.py'
    script.write_bytes((ROOT/'scripts/ue_niagara_probe.py').read_bytes())
    command=[str(EDITOR),str(PROJECT),'/Engine/Maps/Entry',
             '-EnablePlugins=PythonScriptPlugin,EditorScriptingUtilities',
             '-ExecutePythonScript='+str(script),
             '-UserDir='+str(folder/'runtime')+'/', '-abslog='+str(folder/'engine.log'),
             '-Unattended','-NoSound','-NoSplash','-NoCrashDialog','-RenderOffscreen',
             '-trace=cpu,frame,bookmark','-statnamedevents','-tracefile='+str(folder/'capture.utrace'),
             '-DPCVars=fx.Niagara.OnDemandCompileEnabled='+('0' if onload else '2')]
    env=os.environ.copy();env['ENGINE_AGENT_NIAGARA_PROBE']=str(folder)
    env['ENGINE_AGENT_NIAGARA_SIMULATE']='1' if simulate else '0'
    job={'run_id':run_id,'onload':onload,'simulate':simulate,'command':command,'created_at':time.time(),'state':'launching'}
    inputs=[script,PROJECT,
            PROJECT.parent/'Content/Effects/Particles/Environmental/NS_WallPortalEnter.uasset',
            PROJECT.parent/'Content/Effects/Particles/Environmental/NS_CharacterPortalDissolve.uasset']
    job['input_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    write(folder/'job.json',job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    try:
        process=subprocess.Popen(command,cwd=folder,env=env,startupinfo=startup,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except OSError as error:
        job.update(state='launch_failed',error=str(error));write(folder/'job.json',job);raise
    job.update(pid=process.pid,process_created_at=psutil.Process(process.pid).create_time(),state='running')
    write(folder/'job.json',job);return job

def read(run_id):
    job=observe(run_id)
    result={'run_id':run_id,'state':job['state'],'alive':job.get('alive',False),'onload':job['onload'],
            'result':dict(job.get('result') or {}),'images':[]}
    samples=result['result'].pop('samples',[])
    if samples:result['result']['sample_summary']={'count':len(samples),'game_time_range':[samples[0]['game_time'],samples[-1]['game_time']]}
    if result['alive']:return result
    from PIL import Image, ImageStat
    folder=ROOT/'artifacts/performance/niagara-probes'/run_id
    for image in sorted(folder.glob('repeat-*.png'))[:3]:
        with Image.open(image) as frame:
            rgb=frame.convert('RGB'); extrema=rgb.getextrema()
            result['images'].append({'path':str(image),'size':list(frame.size),
                                     'nonblack':any(high>0 for low,high in extrema),
                                     'mean_rgb':ImageStat.Stat(rgb).mean})
    report=result.get('result') or {}
    result['activation_count']=len(report.get('activations',[]))
    result['fixture_complete']=job['state']=='completed' and result['activation_count']==6 and len(result['images'])==3
    result['visual_review_required']=True
    return result

def compare(baseline_id,candidate_id):
    left=read(baseline_id);right=read(candidate_id)
    a=observe(baseline_id);b=observe(candidate_id)
    from pathlib import Path
    identities=[{Path(k).name:v for k,v in j.get('input_sha256',{}).items()} for j in (a,b)]
    matched=bool(identities[0]) and identities[0]==identities[1] and a.get('simulate',False)==b.get('simulate',False)
    rows=[]
    for x,y in zip((left.get('result') or {}).get('activations',[]),(right.get('result') or {}).get('activations',[])):
        if (x['repeat'],x['asset'])!=(y['repeat'],y['asset']):matched=False
        row={'repeat':x['repeat'],'asset':x['asset'],'baseline_call_ms':x['spawn_call_ms'],'candidate_call_ms':y['spawn_call_ms'],
             'baseline_active_at_return':x['active'],'candidate_active_at_return':y['active']}
        for label,entry in [('baseline',x),('candidate',y)]:
            if 'first_active_game_time' in entry and 'request_game_time' in entry:
                row[label+'_first_active_sample_delay_s']=entry['first_active_game_time']-entry['request_game_time']
        rows.append(row)
    return {'run_ids':[baseline_id,candidate_id],'frozen_inputs_match':matched,
            'fixtures_complete':left.get('fixture_complete',False) and right.get('fixture_complete',False),
            'activation_calls':rows,'asset_loads':{'baseline':(left.get('result') or {}).get('asset_loads',[]),
                                                  'candidate':(right.get('result') or {}).get('asset_loads',[])},
            'interpretation':'Editor Python call elapsed times, including parameter binding and Activate request. This excludes async completion and is not frame time. Shared DDC and visual equivalence need separate review.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['start','observe']);p.add_argument('run_id');p.add_argument('--onload',action='store_true');p.add_argument('--simulate',action='store_true');a=p.parse_args()
    print(json.dumps(start(a.run_id,a.onload,a.simulate) if a.command=='start' else observe(a.run_id),ensure_ascii=False,indent=2))
