"""Read-only ingestion of recorded PerformanceLab CSV evidence."""
import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path

COLUMNS = {
    "raytracing_excluded_characters": ["PerformanceLab/RayTracingExcludedCharacters"],
    "raytracing_excluded_attachments": ["PerformanceLab/RayTracingExcludedAttachedPrimitives"],
    "live_characters": ["PerformanceLab/LyraCharacters"],
    "moving_agents": ["PerformanceLab/NavMovingAgents"],
    "gpu_dynamic_geometry_ms": ["GPU/RayTracingDynamicGeometry"],
    "custom_depth_characters": ["PerformanceLab/CustomDepthCharacters"],
    "shadow_casting_characters": ["PerformanceLab/ShadowCastingCharacters"],
    "gpu_custom_depth_ms": ["GPU/CustomDepth"],
    "gpu_shadow_depths_ms": ["GPU/ShadowDepths"],
    "gpu_base_pass_ms": ["GPU/BasePass"],
    "gpu_raytracing_scene_ms": ["GPU/RayTracingScene"],
    "gpu_lumen_gather_ms": ["GPU/LumenScreenProbeGather"],
    "gpu_translucency_ms": ["GPU/Translucency"],
    "gpu_local_used_mb": ["GPUMem/LocalUsedMB"],
    "gpu_local_budget_mb": ["GPUMem/LocalBudgetMB"],
    "gpu_system_used_mb": ["GPUMem/SystemUsedMB"],
    "gpu_system_budget_mb": ["GPUMem/SystemBudgetMB"],
    "transient_used_mb": ["TransientMemoryUsedMB"],
    "shader_memory_mb": ["Shaders/ShaderMemoryMB"],
    "host_free_memory_mb": ["MemoryFreeMB"],
    "frame_ms": ["PerformanceLab/FrameTimeMs", "FrameTime"],
    "game_thread_ms": ["PerformanceLab/GameThreadTimeMs", "GameThreadTime"],
    "render_thread_ms": ["PerformanceLab/RenderThreadTimeMs", "RenderThreadTime"],
    "gpu_ms": ["PerformanceLab/GPUTimeMs", "GPUTime"],
    "draw_calls": ["PerformanceLab/DrawCalls", "RHI/DrawCalls"],
    "animation_ms": ["Exclusive/GameThread/Animation"],
    "movement_ms": ["Exclusive/GameThread/CharacterMovement"],
    "physics_ms": ["Exclusive/GameThread/Physics"],
    "physics_workers_ms": ["Exclusive/AllWorkers/Physics"],
    "end_physics_wait_ms": ["Exclusive/GameThread/EventWait/EndPhysics"],
    "start_physics_wait_ms": ["Exclusive/GameThread/EventWait/StartPhysics"],
    "ui_ms": ["Exclusive/GameThread/UI"],
    "tick_actors_ms": ["Exclusive/GameThread/TickActors"],
}

def percentile(values, fraction):
    ordered = sorted(values)
    index = (len(ordered)-1)*fraction
    lower = math.floor(index); upper = math.ceil(index)
    return ordered[lower]+(ordered[upper]-ordered[lower])*(index-lower)

def analyze_capture(csv_path, manifest_path):
    raw = csv_path.read_bytes()
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw.decode("utf-8-sig"))
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    headers = reader.fieldnames or []
    selected = {key:next((v for v in aliases if v in headers),None) for key,aliases in COLUMNS.items()}
    if not selected["frame_ms"]:
        raise ValueError("No supported frame-time column; supply an explicit adapter")
    gpu_series={column:[] for column in headers if column.startswith("GPU/")}
    series = {key:[] for key in selected}; skipped=0; frames=[]
    for csv_line,row in enumerate(reader,start=2):
        try:
            frame=float(row[selected["frame_ms"]])
            if not math.isfinite(frame) or frame<=0: raise ValueError()
        except (ValueError,TypeError,KeyError):
            skipped+=1;continue
        aligned={"csv_line":csv_line}
        for key,column in selected.items():
            try:value=float(row[column])
            except (ValueError,TypeError,KeyError):continue
            if math.isfinite(value) and value>=0:
                series[key].append(value);aligned[key]=value
        for column,values in gpu_series.items():
            try:value=float(row[column])
            except (ValueError,TypeError,KeyError):continue
            if math.isfinite(value) and value>=0:values.append(value)
        frames.append(aligned)
    metrics={}
    for key,values in series.items():
        if not values:continue
        metrics[key]={"column":selected[key],"unit":"MiB" if key.endswith('_mb') else ("ms" if key.endswith('_ms') else "count"),"count":len(values),"positive_count":sum(v>0 for v in values),
            "mean":sum(values)/len(values),"p50":percentile(values,.5),"p95":percentile(values,.95),
            "p99":percentile(values,.99),"max":max(values)}
    reasons=[]
    for key in ("final","valid","artifactsFinalized"):
        if manifest.get(key) is not True:reasons.append("manifest."+key+" is not true")
    if not series["frame_ms"]:reasons.append("No usable frame samples")
    gpu=metrics.get("gpu_ms")
    gpu_available=bool(gpu and gpu["positive_count"] and manifest.get("normalRHI") is True and manifest.get("rhiName","").lower()!="null")
    cautions=[]
    if manifest.get("warmupSeconds",0)<5:cautions.append("Warmup below 5 seconds; startup effects may dominate")
    if manifest.get("measurementSeconds",0)<10:cautions.append("Measurement below 10 seconds; insufficient for a stable performance claim")
    if len(series["frame_ms"])<120:cautions.append("Fewer than 120 frame samples")
    load_stability={}
    if manifest.get('dimension')=='RenderingLOD' and series.get('live_characters'):
        values=series['live_characters'];target=manifest.get('targetAgentCount',0)
        below=sum(value<target*.9 for value in values)
        load_stability={'metric':'live_characters','target':target,'minimum':min(values),'maximum':max(values),
                        'first':values[0],'last':values[-1],'below_90pct_target_samples':below,
                        'below_target_fraction':below/len(values)}
        if below:
            cautions.append(f"Crowd load fell below 90% target in {below}/{len(values)} records; phase changes require a new controlled capture")
    frame=series["frame_ms"]
    pressure=[]
    for record in frames:
        used=record.get('gpu_local_used_mb');budget=record.get('gpu_local_budget_mb')
        if used is not None and budget is not None and budget>0:
            pressure.append({'csv_line':record['csv_line'],'used_mib':used,'budget_mib':budget,
                             'budget_fraction':used/budget,'headroom_mib':budget-used})
    memory={'gpu_local_budget_available':bool(pressure) and manifest.get('normalRHI') is True,
            'samples':len(pressure),'interpretation':'RHI-reported memory usage and dynamic driver budget, in MiB. Host free memory is system-wide. Budget pressure is an observation; these counters do not identify allocation owners or prove a leak.'}
    if pressure:
        memory.update(peak_budget_fraction=max(pressure,key=lambda x:x['budget_fraction']),
                      minimum_headroom=min(pressure,key=lambda x:x['headroom_mib']),
                      first=pressure[0],last=pressure[-1])
    hitches={"over_33_33ms":sum(v>1000/30 for v in frame),"over_50ms":sum(v>50 for v in frame),
             "over_100ms":sum(v>100 for v in frame)}
    return {"schema":"engine-performance-capture@1","provenance":"Imported historical host capture; not a new benchmark",
        "inputs":{"csv_sha256":hashlib.sha256(raw).hexdigest(),"manifest_sha256":hashlib.sha256(manifest_raw).hexdigest()},
        "identity":{k:manifest.get(k) for k in ("runId","sessionId","startedUtc","sourceRevision","map","variant","dimension","rhiName","processRole","environment","seed","targetAgentCount","presetId","initialViewLocked","warmupSeconds","measurementSeconds")},
        "load_facts":{k:manifest.get(k) for k in ("characterRayTracingLODEnabled","rayTracingExcludedCharacterCount","characterRayTracingMaxDistance","characterRayTracingDistanceHysteresis","characterCustomDepthLODEnabled","customDepthCharacterCount","characterCustomDepthMaxDistance","characterCustomDepthDistanceHysteresis","shadowCastingCharacterCount","minCharacterViewDistance","maxCharacterViewDistance","physicsLoadEnabled","physicsLODEnabled","targetPhysicsBodyCount","physicsBodyCount","physicsAwakeBodyCount","physicsSimulatedBodyCount","physicsLODDisabledBodyCount","possessedAIPawnCount")},
        "gpu_phases":{"top_p95":[{"column":column,"unit":"ms","count":len(values),"positive_count":sum(v>0 for v in values),"mean":sum(values)/len(values),"p95":percentile(values,.95)} for column,values in sorted(((k,v) for k,v in gpu_series.items() if v),key=lambda item:percentile(item[1],.95),reverse=True)[:12]],
                      "interpretation":"CSV GPU scopes may overlap; zero is an observed counter value, not proof the pass did not execute. The list is a bounded ranking, not a decomposition of total GPU time."},
        "load_stability":load_stability,
        "memory_observations":memory,
        "slow_frames":sorted(frames,key=lambda f:f["frame_ms"],reverse=True)[:8],
        "guards":manifest.get("guards",[]),"metrics":metrics,"hitch_counts":hitches,"quality_cautions":cautions,"skipped_rows":skipped,"gpu_measurement_available":gpu_available,
        "capture_complete":manifest.get("final") is True and manifest.get("artifactsFinalized") is True and bool(frame),
        "workload_valid":manifest.get("valid") is True,
        "usable_for_regression":not reasons and not cautions,"invalid_reasons":reasons,
        "interpretation":"Recorded timing statistics. CPU/GPU overlap and waits prevent identifying a root cause from these totals alone."}

def inspect_run(directory):
    directory=Path(directory)
    result_path=directory/"summary.json"
    if not result_path.exists():result_path=directory/"manifest.json"
    result=analyze_capture(directory/"capture.csv",result_path)
    result["source_directory"]=str(directory.resolve())
    result["result_document"]=result_path.name
    return result


def inspect_frame(csv_path, csv_line, radius=2):
    """Return bounded raw counters around a requested CSV record, without cause labels."""
    if csv_line < 2 or not 0 <= radius <= 5:
        raise ValueError("Expected a data row and radius between 0 and 5")
    raw = Path(csv_path).read_bytes()
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    rows = []
    for line, row in enumerate(reader, start=2):
        if line > csv_line + radius:
            break
        if line < csv_line - radius:
            continue
        values = {}
        for column, text in row.items():
            try:
                value = float(text)
            except (ValueError, TypeError):
                continue
            if column and math.isfinite(value):
                values[column] = value
        if values:
            scopes = sorted(((k, v) for k, v in values.items()
                             if k.startswith("Exclusive/") and v > 0),
                            key=lambda item: item[1], reverse=True)[:16]
            counters = {k: v for k, v in values.items()
                        if k.startswith("PerformanceLab/") or k in ("FrameTime", "GameThreadTime", "RenderThreadTime", "GPUTime")}
            rows.append({"csv_line": line, "top_exclusive_scopes": dict(scopes),
                         "counters": counters})
    if not any(row["csv_line"] == csv_line for row in rows):
        raise ValueError("Requested CSV record has no numeric data")
    return {"csv_sha256": hashlib.sha256(raw).hexdigest(), "requested_line": csv_line,
            "rows": rows, "interpretation": "Counters share a CSV record, not necessarily the same execution interval. Thread/GPU reporting may lag; scopes can overlap or omit work. Use a trace to establish critical-path causality."}


def compare_captures(baseline,candidate):
    differences=[]
    keys=("sourceRevision","map","dimension","rhiName","processRole","environment","seed",
          "targetAgentCount","presetId","initialViewLocked","warmupSeconds","measurementSeconds")
    for key in keys:
        left=baseline["identity"].get(key);right=candidate["identity"].get(key)
        if left is None or right is None or left!=right:
            differences.append({"field":key,"baseline":left,"candidate":right})
    errors=[]
    for label,data in [("baseline",baseline),("candidate",candidate)]:
        errors.extend(label+": "+x for x in data["invalid_reasons"]+data["quality_cautions"])
    comparable=not differences and not errors
    metrics={}
    for name,left in baseline["metrics"].items():
        if name not in candidate["metrics"]:continue
        right=candidate["metrics"][name]
        if (name=="gpu_ms" or (name.startswith("gpu_") and name.endswith("_ms"))) and not (baseline["gpu_measurement_available"] and candidate["gpu_measurement_available"]):continue
        metrics[name]={"baseline_p95":left["p95"],"candidate_p95":right["p95"],
                       "delta_p95":right["p95"]-left["p95"]}
    return {"schema":"engine-performance-comparison@1","comparable":comparable,
            "capture_context":{label:{"identity":data['identity'],"load_stability":data.get('load_stability',{}),
                                      "load_facts":data.get('load_facts',{})} for label,data in [('baseline',baseline),('candidate',candidate)]},
            "identity_differences":differences,"quality_cautions":errors,"observed_deltas":metrics,
            "conclusion":"Comparable observations; verify causality with repeat experiments and quality checks" if comparable else "Comparison not qualified; observed differences are not an optimization result"}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv",type=Path)
    parser.add_argument("--run-dir",type=Path)
    parser.add_argument("--compare-run-dir",type=Path)
    parser.add_argument("--manifest",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    if args.run_dir:
        args.csv=args.run_dir/"capture.csv"
        args.manifest=args.run_dir/"summary.json"
        if not args.manifest.exists():args.manifest=args.run_dir/"manifest.json"
        result=inspect_run(args.run_dir)
    else:
        if not args.csv or not args.manifest:parser.error("Provide --run-dir or both --csv and --manifest")
        result=analyze_capture(args.csv,args.manifest)
    args.output.mkdir(parents=True,exist_ok=True)
    # Preserve exact source bytes in a content-addressed input directory.
    frozen=args.output/"inputs"/result["inputs"]["csv_sha256"]
    frozen.mkdir(parents=True,exist_ok=True)
    for src,name in [(args.csv,"capture.csv"),(args.manifest,"manifest.json")]:
        target=frozen/name
        if target.exists() and target.read_bytes()!=src.read_bytes():raise ValueError("Input identity collision")
        target.write_bytes(src.read_bytes())
    (args.output/"capture-summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    if args.compare_run_dir:
        candidate=inspect_run(args.compare_run_dir)
        (args.output/"candidate-summary.json").write_text(json.dumps(candidate,ensure_ascii=False,indent=2),encoding="utf-8")
        (args.output/"comparison.json").write_text(json.dumps(compare_captures(result,candidate),ensure_ascii=False,indent=2),encoding="utf-8")
        candidate_frozen=args.output/"inputs"/candidate["inputs"]["csv_sha256"]
        candidate_frozen.mkdir(parents=True,exist_ok=True)
        for name in ("capture.csv",candidate["result_document"]):
            (candidate_frozen/name).write_bytes((args.compare_run_dir/name).read_bytes())
    print(json.dumps({"output":str(args.output),"usable_for_regression":result["usable_for_regression"],"invalid_reasons":result["invalid_reasons"],"gpu_measurement_available":result["gpu_measurement_available"]},ensure_ascii=False))

if __name__=="__main__":main()
