"""Model-facing performance tools over owned, persistent capture jobs."""
import hashlib
import json
from .capture import ROOT, observe, start, validate_id, write
from .performance import inspect_run, compare_captures, inspect_frame

def read_frame(run_id, csv_line, radius=2):
    validate_id(run_id)
    job = observe(run_id)
    if job["state"] not in ("completed", "completed_invalid"):
        return {"pending": True, "run_id": run_id, "state": job["state"]}
    from pathlib import Path
    report = inspect_frame(Path(job["result_directory"])/"capture.csv", csv_line, radius)
    report["run_id"] = run_id
    return report

def read_capture(run_id):
    validate_id(run_id)
    job=observe(run_id)
    result={k:job.get(k) for k in ("run_id","state","alive","result_status")}
    result["record_path"]=str(ROOT/"artifacts/performance/jobs"/run_id/"job.json")
    if job["state"] in ("completed","completed_invalid"):
        capture=inspect_run(job["result_directory"])
        requested_map=job['command'][2].split('?',1)[0].rsplit('/',1)[-1]
        if not str(capture['identity'].get('map','')).endswith(requested_map):
            capture['quality_cautions'].append('Actual map differs from requested map: '+requested_map)
            capture['usable_for_regression']=False
        capture["provenance"]="Owned native UE capture launched by this project; see job record and source directory"
        capture["identity"]["binary_sha256"]=job.get("binary_sha256")
        capture["identity"]["project_sha256"]=job.get("project_sha256")
        for key in ('capture_mode','fixture_sha256','fixed_camera'):
            capture['identity'][key]=job.get(key)
        view_path=ROOT/'artifacts/performance/jobs'/run_id/'view-evidence.json'
        if job.get('capture_mode'):
            view=json.loads(view_path.read_text(encoding='utf-8')) if view_path.exists() else {}
            characters=view.pop('characters',[])
            view['character_summary']={'count':len(characters),'raytracing_enabled':sum(bool(c.get('raytracing')) for c in characters),'shadow_enabled':sum(bool(c.get('shadow')) for c in characters)}
            view['record_path']=str(view_path)
            capture['view_evidence']=view
            if view.get('state')!='completed':
                capture['quality_cautions'].append('Fixed-view harness did not complete; inspect view-evidence.json')
                capture['usable_for_regression']=False
        capture["identity"]["trace_enabled"]=job.get("trace_enabled",False)
        capture["identity"]["experiment_variant"]=job.get("experiment_variant",capture["identity"]["variant"])
        summary=ROOT/"artifacts/performance/jobs"/run_id/"capture-summary.json"
        write(summary,capture)
        result["capture"]=capture
    if result.get("alive"):result["next_action"]="Return pending and resume later with the same run_id; do not start a replacement."
    return result

def start_capture(session,turn,index,variant,trace=False):
    run_id="agent-"+hashlib.sha256(f"{session}:{turn}:{index}".encode()).hexdigest()[:20]
    path=ROOT/"artifacts/performance/jobs"/run_id/"job.json"
    if path.exists():
        job=json.loads(path.read_text(encoding="utf-8"))
        frozen=job.get("experiment_variant")
        if (frozen is not None and frozen!=variant) or (frozen is None and "-PerfLabVariant="+variant not in job["command"]):raise ValueError("Frozen capture request differs")
        if job.get("trace_enabled",False)!=trace:raise ValueError("Frozen trace setting differs")
        return read_capture(run_id)
    try:start(run_id,variant,trace)
    except RuntimeError as error:return {"started":False,"reason":str(error)}
    return read_capture(run_id)

def compare_jobs(baseline_id,candidate_id):
    a=read_capture(baseline_id);b=read_capture(candidate_id)
    if "capture" not in a or "capture" not in b:return {"pending":True,"baseline":a,"candidate":b}
    report=compare_captures(a["capture"],b["capture"])
    for key in ("binary_sha256","project_sha256"):
        left=a["capture"]["identity"].get(key);right=b["capture"]["identity"].get(key)
        if not left or left!=right:
            report["identity_differences"].append({"field":key,"baseline":left,"candidate":right})
            report["comparable"]=False
    for key in ('capture_mode','fixture_sha256','fixed_camera'):
        left=a['capture']['identity'].get(key);right=b['capture']['identity'].get(key)
        if left!=right:
            report['identity_differences'].append({'field':key,'baseline':left,'candidate':right});report['comparable']=False
    if a["capture"]["identity"]["trace_enabled"] != b["capture"]["identity"]["trace_enabled"]:
        report["identity_differences"].append({"field":"trace_enabled","baseline":a["capture"]["identity"]["trace_enabled"],"candidate":b["capture"]["identity"]["trace_enabled"]})
        report["comparable"]=False
    if not report["comparable"]:report["conclusion"]="Unqualified comparison; do not claim optimization benefit"
    report["run_ids"]=[baseline_id,candidate_id]
    return report
