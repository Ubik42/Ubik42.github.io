"""Fixed lift-platform experiment in this repository's owned UE host."""
import hashlib
import json
import subprocess
import time
from pathlib import Path

from .mcp import text
from .runtime import BLUEPRINT,ASSET,SCENE

ROOT=Path(__file__).resolve().parents[1]
BLUEPRINT_PATH='/Game/EngineAgent/BP_LiftPlatform.BP_LiftPlatform'

def graph_hash(client):
    result=client.call(BLUEPRINT,'read_graph_dsl',{'graph':{'refPath':BLUEPRINT_PATH+':EventGraph'}})
    return hashlib.sha256(json.loads(text(result))['returnValue'].encode()).hexdigest()

def summarize(report,current_hash):
    fresh=report.get('graph_sha256')==current_hash
    return {k:report[k] for k in ('probe_id','request','recorded_at','count','z_range','max_error_cm','graph_sha256','asset_sha256','passed') if k in report} | {
        'current_graph_sha256':current_hash,'fresh':fresh,
        'verified_current_graph':fresh and report.get('passed') is True,
        'scope':'Fixed lift motion in Simulate In Editor; no collision, rider, networking or variable-frame-rate coverage'}

def read(client):
    pointer=ROOT/'artifacts/platform-probes/latest.json'
    if not pointer.exists(): return {'available':False,'reason':'No versioned runtime probe yet'}
    probe_id=json.loads(pointer.read_text(encoding='utf-8'))['probe_id']
    import re
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',probe_id): raise ValueError('Invalid local probe ID')
    report=json.loads((pointer.parent/probe_id/'readback.json').read_text(encoding='utf-8'))
    return {'available':True,**summarize(report,graph_hash(client))}

def run(client,probe_id,request):
    import re
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',probe_id): raise ValueError('Invalid probe ID')
    folder=ROOT/'artifacts/platform-probes'/probe_id
    folder.mkdir(parents=True,exist_ok=True)
    active=folder.parent/'active.json'
    if active.exists():
        previous=json.loads(active.read_text(encoding='utf-8'))['probe_id']
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',previous): raise ValueError('Invalid active probe ID')
        prior=folder.parent/previous
        if (prior/'readback.json').exists() or (prior/'error.json').exists():
            active.unlink()
        else:
            return {'status':'pending','probe_id':previous,'message':'A probe has no terminal result. Inspect its process/logs before starting another; the host was not restarted.'}
    request_path=folder/'request.json'
    if request_path.exists():
        if json.loads(request_path.read_text(encoding='utf-8'))!=request: raise ValueError('Probe identity changed')
        if (folder/'readback.json').exists():
            report=json.loads((folder/'readback.json').read_text(encoding='utf-8'))
            return {'reused':True,**summarize(report,graph_hash(client))}
        return {'status':'incomplete','probe_id':probe_id,'message':'An earlier probe started without a terminal result. Inspect its owned host and logs; automatic restart was not attempted.'}
    if client.endpoint!='http://127.0.0.1:18086/mcp': raise ValueError('Runtime experiment requires the owned local host on port 18086')
    level=json.loads(text(client.call(SCENE,'get_current_level',{})))['returnValue']
    if level.split('.')[0]!='/Game/EngineAgent/L_Workshop': raise ValueError('Expected the owned workshop level')
    # Verify process identity and listener before saving or stopping anything.
    verify=r'''$ErrorActionPreference='Stop'; $m=Get-Content artifacts/host-process.json -Raw|ConvertFrom-Json; $p=Get-Process -Id $m.pid; if($p.StartTime.ToUniversalTime().ToString('o') -ne $m.started){throw 'Owned process identity changed'}; $l=Get-NetTCPConnection -LocalPort 18086 -State Listen; if($l.OwningProcess -ne $m.pid){throw 'Listener belongs to another process'}'''
    subprocess.run(['powershell','-NoProfile','-Command',verify],cwd=ROOT,check=True,capture_output=True,text=True)
    current=graph_hash(client)
    client.call(ASSET,'save_assets',{'asset_paths':[BLUEPRINT_PATH]})
    request_path.write_text(json.dumps(request,indent=2),encoding='utf-8')
    (folder/'before.json').write_text(json.dumps({'graph_sha256':current}),encoding='utf-8')
    active.write_text(json.dumps({'probe_id':probe_id}),encoding='utf-8')
    for script,args in [('stop_host.ps1',[]),('start_host.ps1',['-ProbePlatform','-ProbeId',probe_id])]:
        command=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'scripts'/script),*args]
        result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=120)
        (folder/(script+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        if result.returncode: raise RuntimeError(f'{script} failed; see {folder}')
    client.session=''
    client.initialize()
    deadline=time.monotonic()+60
    while time.monotonic()<deadline:
        if (folder/'error.json').exists():
            active.unlink(missing_ok=True)
            return {'status':'host_error','probe_id':probe_id,'error':json.loads((folder/'error.json').read_text(encoding='utf-8'))}
        if (folder/'readback.json').exists():
            report=json.loads((folder/'readback.json').read_text(encoding='utf-8'))
            (folder.parent/'latest.json').write_text(json.dumps({'probe_id':probe_id}),encoding='utf-8')
            active.unlink(missing_ok=True)
            return {'status':'completed',**summarize(report,graph_hash(client))}
        time.sleep(.25)
    return {'status':'pending','probe_id':probe_id,'message':'No terminal result within observation window. Inspect this probe before starting another.'}
