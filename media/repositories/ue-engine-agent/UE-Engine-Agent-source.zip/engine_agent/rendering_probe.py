"""Persisted visual-only PIE runs using read-only Lyra source assets."""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
import psutil
from .capture import ROOT,PROJECT,EDITOR,validate_id,write
PARENT=ROOT/'artifacts/performance/render-probes'

def observe(run_id):
    validate_id(run_id);folder=PARENT/run_id
    job=json.loads((folder/'job.json').read_text(encoding='utf-8'))
    try:
        process=psutil.Process(job['pid']);alive=process.is_running() and process.create_time()==job['process_created_at']
    except (psutil.NoSuchProcess,KeyError):alive=False
    job['alive']=alive
    if (folder/'result.json').exists():job['result']=json.loads((folder/'result.json').read_text(encoding='utf-8'))
    job['state']='running' if alive else job.get('result',{}).get('state','exited_without_result')
    write(folder/'job.json',job);return job

def start(run_id,optimized=False,crowd=False):
    from .capture import observe as capture_observe
    from .niagara_probe import observe as niagara_observe
    validate_id(run_id)
    for root,reader in [(PARENT,observe),(ROOT/'artifacts/performance/jobs',capture_observe),(ROOT/'artifacts/performance/niagara-probes',niagara_observe)]:
        for path in root.glob('*/job.json'):
            if reader(path.parent.name).get('alive'):raise RuntimeError('Owned UE process is active; observe before starting another')
    folder=PARENT/run_id;folder.mkdir(parents=True,exist_ok=False)
    script=folder/'probe.py';script.write_bytes((ROOT/'scripts/ue_rendering_probe.py').read_bytes())
    command=[str(EDITOR),str(PROJECT),'/ShooterMaps/Maps/L_Convolution_Blockout',
             '-Experience=B_HeroArena_ControlPoints','-NumBots=9',
             '-EnablePlugins=PythonScriptPlugin,EditorScriptingUtilities','-ExecutePythonScript='+str(script),
             '-UserDir='+str(folder/'runtime')+'/', '-abslog='+str(folder/'engine.log'),
             '-Unattended','-NoSound','-NoSplash','-NoCrashDialog','-RenderOffscreen']
    if crowd:
        command=[{'/ShooterMaps/Maps/L_Convolution_Blockout':'/ShooterCore/Maps/L_ShooterPerf',
                  '-Experience=B_HeroArena_ControlPoints':'-Experience=B_ShooterGame_Perf','-NumBots=9':'-NumBots=200'}.get(x,x) for x in command]
        command.extend(['-PerfLab','-PerfLabAgents=200','-PerfLabDimension=RenderingLOD','-PerfLabCrowdStateMachine',
                        '-PerfLabNavigationLoad','-PerfLabWarmup=5','-PerfLabDuration=60','-PerfLabRunId='+run_id])
    if optimized:command.append('-LyraCharacterRayTracingLOD' if crowd else '-LyraCharacterCustomDepthLOD')
    job={'run_id':run_id,'optimized':optimized,'crowd':crowd,'command':command,'created_at':time.time(),'state':'launching',
         'purpose':'Separate visual-only PIE run; not a benchmark frame',
         'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
    write(folder/'job.json',job)
    env=os.environ.copy();env['ENGINE_AGENT_RENDER_PROBE']=str(folder);env['ENGINE_AGENT_RENDER_CROWD']='1' if crowd else '0'
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    try:process=subprocess.Popen(command,cwd=folder,env=env,startupinfo=startup,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except OSError as exc:
        job.update(state='launch_failed',error=str(exc));write(folder/'job.json',job);raise
    job.update(pid=process.pid,process_created_at=psutil.Process(process.pid).create_time(),state='running')
    write(folder/'job.json',job);return job

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['start','observe']);p.add_argument('run_id');p.add_argument('--optimized',action='store_true');p.add_argument('--crowd',action='store_true');a=p.parse_args()
    print(json.dumps(start(a.run_id,a.optimized,a.crowd) if a.command=='start' else observe(a.run_id),ensure_ascii=False,indent=2))
