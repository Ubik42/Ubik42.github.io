"""Durable step execution. Uncertain writes require a readback before continuation."""
import hashlib
import json
import sqlite3
import base64
import jsonschema
from datetime import datetime, timezone
from pathlib import Path

from .mcp import text

PREFIX = '/Game/EngineAgent/'
MATERIAL = 'editor_toolset.toolsets.material_instance.MaterialInstanceTools'
ASSET = 'editor_toolset.toolsets.asset.AssetTools'
SCENE = 'editor_toolset.toolsets.scene.SceneTools'
EDITOR = 'EditorToolset.EditorAppToolset'
READS = {(MATERIAL, n) for n in ('list_parameters', 'get_scalar_parameter', 'get_vector_parameter')}
READS |= {(SCENE, 'get_current_level'), (SCENE, 'find_actors'), (EDITOR, 'CaptureViewport')}
WRITES = {(MATERIAL, 'set_scalar_parameter'), (MATERIAL, 'set_vector_parameter'), (ASSET, 'save_assets')}


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def validate(step):
    if set(step) != {'id', 'toolset', 'tool', 'arguments', 'reason'}:
        raise ValueError('Step needs id/toolset/tool/arguments/reason')
    pair = step['toolset'], step['tool']
    if pair not in READS | WRITES:
        raise ValueError('Tool is outside the implemented capability set')
    if not isinstance(step['arguments'], dict) or not step['id'] or not step['reason']:
        raise ValueError('Invalid step')
    if pair in WRITES or pair[0] == MATERIAL:
        args = step['arguments']
        paths = args.get('asset_paths', [args.get('instance', args.get('material', ''))])
        if not isinstance(paths, list) or not paths:
            raise ValueError('Explicit target assets are required')
        paths = [p.get('refPath', '') if isinstance(p, dict) else p for p in paths]
        if any(not isinstance(p, str) or not p.startswith(PREFIX) or '..' in p or '\\' in p for p in paths):
            raise ValueError('Asset is outside /Game/EngineAgent/')
    encode(step)


class Runtime:
    def __init__(self, folder, client):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.client = client
        self.schemas = {}
        self.db = sqlite3.connect(self.folder / 'runs.sqlite', timeout=5)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, plan_hash TEXT, plan TEXT);
        CREATE TABLE IF NOT EXISTS steps(run TEXT, id TEXT, state TEXT, request TEXT, result TEXT,
          PRIMARY KEY(run,id));
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY, time TEXT, run TEXT, step TEXT,
          kind TEXT, detail TEXT);
        ''')
        self.db.commit()

    def event(self, run, step, kind, detail):
        self.db.execute('INSERT INTO events(time,run,step,kind,detail) VALUES(?,?,?,?,?)',
                        (datetime.now(timezone.utc).isoformat(), run, step, kind, encode(detail)))

    def validate_schema(self, step):
        ts = step['toolset']
        if ts not in self.schemas:
            descriptor = json.loads(text(self.client.tool('describe_toolset', {'toolset_name': ts})))
            self.schemas[ts] = {x['name'].rsplit('.', 1)[-1]: x['inputSchema'] for x in descriptor['tools']}
            path = self.folder / ('schema-' + hashlib.sha256(ts.encode()).hexdigest()[:12] + '.json')
            path.write_text(encode(descriptor), encoding='utf-8')
        jsonschema.validate(step['arguments'], self.schemas[ts][step['tool']])

    def externalize(self, value):
        if isinstance(value, list):
            return [self.externalize(x) for x in value]
        if isinstance(value, dict):
            if value.get('mimeType') == 'image/png' and value.get('data'):
                data = base64.b64decode(value['data'], validate=True)
                digest = hashlib.sha256(data).hexdigest()
                path = self.folder / (digest + '.png')
                path.write_bytes(data)
                return {'mimeType': 'image/png', 'artifact': path.name, 'sha256': digest, 'bytes': len(data)}
            # Structured tool output is often repeated as JSON in a text content block.
            if value.get('type') == 'text':
                try:
                    structured = json.loads(value['text'])
                except (ValueError, KeyError):
                    pass
                else:
                    return {'type': 'text', 'text': encode(self.externalize(structured))}
            return {k: self.externalize(v) for k, v in value.items()}
        return value

    def execute(self, plan):
        if set(plan) != {'run_id', 'intent', 'planner', 'steps'} or not isinstance(plan['steps'], list):
            raise ValueError('Expected run_id, intent, planner and steps')
        if not plan['steps'] or len(plan['steps']) > 30:
            raise ValueError('A run must have 1–30 steps')
        ids = [s['id'] for s in plan['steps']]
        if len(ids) != len(set(ids)):
            raise ValueError('Duplicate step IDs')
        for step in plan['steps']:
            validate(step)
            self.validate_schema(step)
        if any((s['toolset'], s['tool']) in WRITES for s in plan['steps']):
            host_level = json.loads(text(self.client.call(SCENE, 'get_current_level', {}))).get('returnValue', '')
            if not host_level.startswith(PREFIX):
                raise ValueError('Connected editor is not in the EngineAgent work area')
        frozen = encode(plan)
        digest = hashlib.sha256(frozen.encode()).hexdigest()
        run = plan['run_id']
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO runs VALUES(?,?,?)', (run, digest, frozen))
            if self.db.execute('SELECT plan_hash FROM runs WHERE id=?', (run,)).fetchone()[0] != digest:
                raise ValueError('Existing run has a different plan; use a new run ID')
        receipts = []
        for step in plan['steps']:
            sid = step['id']
            # Atomic claim prevents two local runners sending the same step concurrently.
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute('SELECT state,result FROM steps WHERE run=? AND id=?', (run, sid)).fetchone()
            if row:
                self.db.commit()
                if row[0] == 'completed':
                    receipts.append({'id': sid, 'state': 'reused', 'result': json.loads(row[1])})
                    continue
                raise RuntimeError(f'{sid}: {row[0]}; inspect host state before creating a recovery plan')
            self.db.execute('INSERT INTO steps VALUES(?,?,?,?,?)', (run, sid, 'started', encode(step), '{}'))
            self.event(run, sid, 'started', step)
            self.db.commit()
            try:
                result = self.externalize(self.client.call(step['toolset'], step['tool'], step['arguments']))
            except Exception as exc:
                with self.db:
                    self.db.execute('UPDATE steps SET state=?,result=? WHERE run=? AND id=?',
                                    ('uncertain', encode({'error': str(exc)}), run, sid))
                    self.event(run, sid, 'uncertain', {'error': str(exc)})
                raise
            with self.db:
                self.db.execute('UPDATE steps SET state=?,result=? WHERE run=? AND id=?',
                                ('completed', encode(result), run, sid))
                self.event(run, sid, 'completed', result)
            receipts.append({'id': sid, 'state': 'completed', 'result': result})
        return {'run_id': run, 'plan_hash': digest, 'planner': plan['planner'], 'steps': receipts}

    def export(self, run):
        return [{'time': t, 'step': s, 'kind': k, 'detail': json.loads(d)} for t, s, k, d in
                self.db.execute('SELECT time,step,kind,detail FROM events WHERE run=? ORDER BY seq', (run,))]
