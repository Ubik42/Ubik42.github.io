"""Persistent offline Unreal Insights export over an owned, finished capture."""
import argparse
import csv
import hashlib
import heapq
import json
from pathlib import Path
import subprocess
import time
import psutil
from .capture import ROOT, EDITOR, observe as observe_capture, validate_id, write


def observe(run_id):
    validate_id(run_id)
    folder = ROOT/'artifacts/performance/jobs'/run_id/'insights'
    path = folder/'export.json'
    job = json.loads(path.read_text(encoding='utf-8'))
    if not job.get('pid'):
        return job
    try:
        process = psutil.Process(job['pid'])
        alive = process.create_time() == job['process_created_at'] and process.is_running()
    except psutil.NoSuchProcess:
        alive = False
    job['alive'] = alive
    if alive:
        job['state'] = 'running'
    else:
        outputs = {name: (folder/name).stat().st_size if (folder/name).exists() else 0
                   for name in ('threads.csv', 'timers.csv', 'events.csv')}
        job['outputs'] = outputs
        job['state'] = 'exported' if all(outputs.values()) else 'export_failed'
    write(path, job)
    return job


def start(run_id, retry=False):
    validate_id(run_id)
    capture = observe_capture(run_id)
    if capture['alive']:
        raise ValueError('Observe the running capture before exporting its trace')
    folder = ROOT/'artifacts/performance/jobs'/run_id/'insights'
    if (folder/'export.json').exists():
        previous = observe(run_id)
        if not retry or previous['state'] != 'export_failed':
            return previous
        archive = folder/('failed-'+str(time.time_ns()))
        archive.mkdir()
        for name in ('export.json','export.rsp','insights.log'):
            source = folder/name
            if source.exists(): source.rename(archive/name)
    trace = folder.parent/'capture.utrace'
    if not trace.exists() or not trace.stat().st_size:
        raise ValueError('Capture has no trace file')
    folder.mkdir(exist_ok=True)
    response = folder/'export.rsp'
    response.write_text('\n'.join([
        f'TimingInsights.ExportThreads "{(folder / "threads.csv").as_posix()}"',
        f'TimingInsights.ExportTimers "{(folder / "timers.csv").as_posix()}"',
        f'TimingInsights.ExportTimingEvents "{(folder / "events.csv").as_posix()}" -columns=ThreadId,ThreadName,TimerId,TimerName,StartTime,EndTime,Duration,Depth -threads=GameThread -timers=*',
    ])+'\n', encoding='utf-8')
    command = [str(EDITOR.with_name('UnrealInsights.exe')), '-OpenTraceFile='+str(trace),
               '-AutoQuit', '-NoUI', '-ExecOnAnalysisCompleteCmd=@='+str(response),
               '-abslog='+str(folder/'insights.log')]
    with trace.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    job = {'run_id': run_id, 'state': 'launching', 'command': command,
           'trace_sha256': digest,
           'created_at': time.time()}
    write(folder/'export.json', job)
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    try:
        process = subprocess.Popen(command, cwd=folder, startupinfo=startup,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as error:
        job.update(state='launch_failed',error=str(error))
        write(folder/'export.json',job)
        raise
    job.update(pid=process.pid, process_created_at=psutil.Process(process.pid).create_time(), state='running')
    write(folder/'export.json', job)
    return job


def summarize(run_id, start_time=0, end_time=None, timer_contains=''):
    if start_time < 0 or (end_time is not None and end_time <= start_time):
        raise ValueError('Expected a positive interval in trace seconds')
    job = observe(run_id)
    if job['state'] != 'exported':
        return job
    path = ROOT/'artifacts/performance/jobs'/run_id/'insights/events.csv'
    identity = [job['trace_sha256'], path.stat().st_size, path.stat().st_mtime_ns,
                start_time, end_time, timer_contains]
    cache_key = hashlib.sha256(json.dumps(identity).encode()).hexdigest()
    cached = path.parent/('query-'+cache_key+'.json')
    if cached.exists():
        return json.loads(cached.read_text(encoding='utf-8'))
    largest = []
    count = 0
    with path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        headers = next(reader)
        for values in reader:
            if timer_contains.casefold() not in values[3].casefold():
                continue
            if float(values[4]) < start_time or (end_time is not None and float(values[5]) > end_time):
                continue
            row = dict(zip(headers, values))
            begin = float(row['StartTime']); end = float(row['EndTime'])
            if begin < start_time or (end_time is not None and end > end_time):
                continue
            if timer_contains.casefold() not in row['TimerName'].casefold():
                continue
            count += 1
            item = (float(row['Duration']), count, row)
            if len(largest) < 24: heapq.heappush(largest, item)
            elif item[0] > largest[0][0]: heapq.heapreplace(largest, item)
    report = {'run_id': run_id, 'trace_sha256': job['trace_sha256'], 'events': count,
              'interval_seconds': [start_time, end_time],
              'timer_contains': timer_contains,
              'largest_inclusive_events': [x[2] for x in sorted(largest, reverse=True)],
              'interpretation': 'GameThread inclusive durations in trace seconds. Parent and child scopes overlap. Default interval includes startup; select measurement bounds before diagnosing steady-state performance.'}
    write(cached, report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['start', 'observe', 'summarize'])
    parser.add_argument('run_id')
    parser.add_argument('--start-time', type=float, default=0)
    parser.add_argument('--end-time', type=float)
    parser.add_argument('--retry', action='store_true')
    parser.add_argument('--timer-contains', default='')
    args = parser.parse_args()
    result = summarize(args.run_id, args.start_time, args.end_time,args.timer_contains) if args.command == 'summarize' else (start(args.run_id,args.retry) if args.command == 'start' else observe(args.run_id))
    print(json.dumps(result, ensure_ascii=False, indent=2))
