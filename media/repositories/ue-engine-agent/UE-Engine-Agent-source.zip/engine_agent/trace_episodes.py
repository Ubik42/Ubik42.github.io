"""Complete scope occurrence records with bounded model-facing summaries."""
import csv
import json
from .capture import ROOT, write
from .trace import observe

NAMES={'UNiagaraSystem::RequestCompile','ExecuteUbergraph_GCNL_Teleporter_Activate',
       'NiagaraAsyncTask_DigestSystem','SpawnSystemAttached','SpawnSystemAtLocation'}


def collect(run_id):
    job=observe(run_id)
    if job['state']!='exported': return job
    folder=ROOT/'artifacts/performance/jobs'/run_id/'insights'
    output=folder/'episodes.json'
    if output.exists():
        cached=json.loads(output.read_text(encoding='utf-8'))
        if cached['trace_sha256']==job['trace_sha256']:return cached
    result={name:[] for name in sorted(NAMES)}
    with (folder/'events.csv').open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.reader(stream);next(reader)
        for row in reader:
            if row[3] in NAMES:
                result[row[3]].append({'start':float(row[4]),'end':float(row[5]),
                                      'duration_ms':float(row[6])*1000,'depth':int(row[7])})
    data={'run_id':run_id,'trace_sha256':job['trace_sha256'],'scope_occurrences':result,
          'interpretation':'All exported GameThread occurrences, including startup. Costs are inclusive. Time ranges are trace-relative seconds.'}
    write(output,data)
    return data


def read_episodes(run_id, start_time=0):
    data=collect(run_id)
    if 'scope_occurrences' not in data:return data
    report={'run_id':run_id,'trace_sha256':data['trace_sha256'],'start_time':start_time,
            'scopes':{},'interpretation':'Scope statistics after the requested trace time. Inclusive costs overlap; windows are not synchronized across runs. Count changes or missing events alone do not establish equivalent workloads.'}
    for name,all_rows in data['scope_occurrences'].items():
        rows=[r for r in all_rows if r['start']>=start_time]
        report['scopes'][name]={'count':len(rows),'sum_inclusive_ms':sum(r['duration_ms'] for r in rows),
                              'largest':sorted(rows,key=lambda r:r['duration_ms'],reverse=True)[:8]}
    return report
