"""Bounded, cached trace windows with observed child-time subtraction."""
import csv
import hashlib
import json
import math
from .capture import ROOT, write
from .trace import observe


def read_window(run_id, start_time, end_time):
    if not all(math.isfinite(v) for v in (start_time,end_time)) or start_time < 0 or not 0 < end_time-start_time <= 1:
        raise ValueError('Select a finite trace interval of at most one second')
    job=observe(run_id)
    if job['state']!='exported': return job
    source=ROOT/'artifacts/performance/jobs'/run_id/'insights/events.csv'
    identity=[job['trace_sha256'],source.stat().st_size,source.stat().st_mtime_ns,start_time,end_time]
    key=hashlib.sha256(json.dumps(identity).encode()).hexdigest()
    cache=source.parent/('window-'+key+'.json')
    if cache.exists():
        data=json.loads(cache.read_text(encoding='utf-8'))
    else:
        events=[]; count=0
        with source.open(encoding='utf-8-sig',newline='') as stream:
            reader=csv.reader(stream); next(reader)
            for row in reader:
                begin=float(row[4]); end=float(row[5])
                if begin < start_time or end > end_time: continue
                count+=1
                if len(events)<100000:
                    events.append({'thread_id':row[0],'timer_id':row[2],'name':row[3],
                                   'start':begin,'end':end,'depth':int(row[7])})
        data={'trace_sha256':job['trace_sha256'],'interval_seconds':[start_time,end_time],
              'matching_events':count,'truncated':count>len(events),'events':events}
        write(cache,data)
    if data['truncated']:
        return {'run_id':run_id,'truncated':True,'matching_events':data['matching_events'],
                'next_action':'Choose a narrower interval; child-time calculation omitted.'}
    events=sorted(data['events'],key=lambda e:(e['start'],-e['end'],e['depth']))
    stack=[]; children={}; parents={}
    for index,event in enumerate(events):
        while stack:
            parent=events[stack[-1]]
            if parent['thread_id']==event['thread_id'] and parent['depth']<event['depth'] and parent['start']<=event['start'] and parent['end']>=event['end']: break
            stack.pop()
        if stack:
            parents[index]=stack[-1]
            children.setdefault(stack[-1],[]).append(index)
        stack.append(index)
    ranked=[]
    for index,event in enumerate(events):
        # Union direct child intervals: never double subtract overlapping siblings.
        spans=sorted((events[i]['start'],events[i]['end']) for i in children.get(index,[]))
        covered=0; right=event['start']
        for begin,end in spans:
            covered+=max(0,end-max(begin,right));right=max(right,end)
        duration=event['end']-event['start']
        ranked.append(dict(event,inclusive_ms=duration*1000,
            observed_self_ms=max(0,duration-covered)*1000,
            parent=events[parents[index]]['name'] if index in parents else None,
            direct_children=len(spans)))
    return {'run_id':run_id,'trace_sha256':data['trace_sha256'],
            'interval_seconds':data['interval_seconds'],'matching_events':len(events),
            'observed_self_total_ms':sum(e['observed_self_ms'] for e in ranked),
            'root_inclusive_total_ms':sum((events[i]['end']-events[i]['start'])*1000 for i in range(len(events)) if i not in parents),
            'largest_observed_self':sorted(ranked,key=lambda e:e['observed_self_ms'],reverse=True)[:24],
            'interpretation':'Self time subtracts observed nested children only. It includes uninstrumented work and waits; it is not CPU instruction time. Parents outside the selected interval are omitted.'}
