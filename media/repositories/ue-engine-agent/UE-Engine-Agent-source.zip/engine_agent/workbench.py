"""Local workbench over persisted Agent sessions. One UE worker at a time."""
import argparse,hashlib,json,re,secrets,sqlite3,threading,uuid
from contextlib import closing
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from .agent import Agent,images
from .mcp import Client
from .layout import snapshot

ROOT=Path(__file__).resolve().parents[1]
LOCK=threading.Lock()
JOBS={}
TOKEN=secrets.token_urlsafe(32)
ENDPOINT='http://127.0.0.1:18086/mcp'

def index():
    result={}
    for dbpath in [*(ROOT/'artifacts').glob('*/runs.sqlite'), *(ROOT/'artifacts/performance').glob('*/runs.sqlite')]:
        try:
            with closing(sqlite3.connect(dbpath,timeout=2)) as db:
                rows=db.execute('SELECT id,intent,model,turn,status FROM agent_sessions ORDER BY rowid DESC').fetchall()
                tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                modes=dict(db.execute('SELECT session,mode FROM agent_modes')) if 'agent_modes' in tables else {}
            for sid,intent,model,turn,status in rows:
                key=hashlib.sha256((str(dbpath)+sid).encode()).hexdigest()[:20]
                job=JOBS.get(key,{})
                result[key]={'updated':dbpath.stat().st_mtime,'id':key,'session':sid,'intent':intent,'model':model,'turns':turn,
                    'status':job.get('status',status if status!='active' else 'interrupted'),
                    'error':job.get('error',''),'folder':dbpath.parent,'mode':modes.get(sid,'engine')}
        except sqlite3.OperationalError: pass
    return result

def detail(key):
    item=index()[key];folder=item['folder']
    with closing(sqlite3.connect(folder/'runs.sqlite',timeout=2)) as db:
        row=db.execute('SELECT messages,pending FROM agent_sessions WHERE id=?',(item['session'],)).fetchone()
        messages=json.loads(row[0]);pending=json.loads(row[1])
        calls=[{'turn':t,**json.loads(meta)} for t,meta in db.execute('SELECT turn,metadata FROM model_calls WHERE session=? ORDER BY turn',(item['session'],))]
        # Match session boundary without LIKE wildcard ambiguity.
        events=[{'seq':seq,'time':time,'run':run,'step':step,'kind':kind,'detail':json.loads(data)} for seq,time,run,step,kind,data in db.execute('SELECT seq,time,run,step,kind,detail FROM events ORDER BY seq') if run.startswith(item['session']+'-t')]
    captures=[]
    for m in messages:
        if m.get('role')=='user' and isinstance(m.get('content'),list):
            captures += [p['artifact'] for p in m['content'] if p.get('type')=='ue_image']
    return {**{k:v for k,v in item.items() if k!='folder'},'messages':messages,'pending':pending,'calls':calls,'events':events,'captures':list(dict.fromkeys(captures))}

def start(action,payload):
    if not LOCK.acquire(blocking=False): raise ValueError('已有任务正在使用编辑器，请等待本轮完成。')
    try:
        if action=='new':
            intent=payload.get('intent','').strip()
            if not 1<=len(intent)<=12000: raise ValueError('请输入 1–12000 字的任务。')
            session='ui-'+uuid.uuid4().hex[:10];folder=ROOT/'artifacts'/session
            folder.mkdir(parents=True)
            (folder/'workbench-request.json').write_text(json.dumps({'layout':bool(payload.get('layout'))}),encoding='utf-8')
            model='deepseek-flash'
            mode=payload.get('mode','engine')
            if mode not in ('engine','performance'):raise ValueError('任务模式无效')
            # Persist the request before returning its identity to the browser.
            a=Agent(folder,None,model,performance_only=mode=='performance')
            with a.db:
                from .agent import SYSTEM,PERFORMANCE_SYSTEM
                a.db.execute('INSERT INTO agent_sessions VALUES(?,?,?,?,?,?,?)',(session,intent,model,json.dumps([{'role':'system','content':PERFORMANCE_SYSTEM if mode=='performance' else SYSTEM},{'role':'user','content':intent}],ensure_ascii=False),0,'active','null'))
                a.db.execute('INSERT INTO agent_modes VALUES(?,?)',(session,mode))
            a.db.close()
            key=hashlib.sha256((str(folder/'runs.sqlite')+session).encode()).hexdigest()[:20]
        else:
            key=payload['id'];item=index()[key]
            folder,session,intent,model=item['folder'],item['session'],item['intent'],item['model']
            mode=item['mode']
            if model!='deepseek-flash': raise ValueError('此记录为测试夹具，仅供查看。')
            if item['status']=='model_completed': raise ValueError('任务已完成，请新建后续任务。')
        JOBS[key]={'status':'running'}
        def worker():
            agent=None
            try:
                client=None
                if mode=='engine':client=Client(ENDPOINT);client.initialize()
                request_file=folder/'workbench-request.json'
                request=json.loads(request_file.read_text(encoding='utf-8')) if request_file.exists() else {}
                if mode=='engine' and request.get('layout') and not (folder/'layout-baseline.json').exists(): snapshot(folder,client)
                agent=Agent(folder,client,model,performance_only=mode=='performance')
                if action=='recover':
                    recovered=agent.recover(session)
                    if recovered['status']!='active':
                        JOBS[key]={'status':'needs_readback','error':'实际值与原请求不一致，已保留现场。'};return
                turns=agent.db.execute('SELECT turn FROM agent_sessions WHERE id=?',(session,)).fetchone()[0]
                result=agent.run(session,intent,turns+18)
                JOBS[key]={'status':result['status']}
            except Exception as exc:
                persisted='failed'
                if agent:
                    row=agent.db.execute('SELECT status FROM agent_sessions WHERE id=?',(session,)).fetchone()
                    if row and row[0]=='needs_readback': persisted='needs_readback'
                JOBS[key]={'status':persisted,'error':str(exc)[:1800]}
            finally:
                if agent: agent.db.close()
                LOCK.release()
        threading.Thread(target=worker,daemon=True).start()
        return {'id':key}
    except Exception:
        LOCK.release();raise

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def send(self,data,status=200,kind='application/json; charset=utf-8'):
        raw=json.dumps(data,ensure_ascii=False).encode() if kind.startswith('application/json') else data
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
    def allowed(self):
        return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
    def do_GET(self):
        if not self.allowed(): return self.send({'error':'无效地址'},403)
        u=urlparse(self.path);q=parse_qs(u.query)
        try:
            if u.path=='/api/performance':
                from .capture import observe
                records=[]
                for path in (ROOT/'artifacts/performance/jobs').glob('*/job.json'):
                    job=observe(path.parent.name)
                    if not job.get('experiment_variant'):
                        job['experiment_variant']=next((x.split('=',1)[1] for x in job.get('command',[]) if x.startswith('-PerfLabVariant=')),'Baseline')
                    records.append({k:job.get(k) for k in ('run_id','state','created_at','experiment_variant','result_status')})
                return self.send({'jobs':sorted(records,key=lambda j:j['created_at'],reverse=True)})
            if u.path=='/api/capture':
                from .performance_tools import read_capture
                return self.send(read_capture(q['id'][0]))
            if u.path=='/api/memory':
                from .memory_timeline import read
                return self.send(read(q['id'][0]))
            if u.path=='/api/compare':
                from .performance_tools import compare_jobs
                return self.send(compare_jobs(q['baseline'][0],q['candidate'][0]))
            if u.path=='/api/tasks':
                return self.send({'tasks':[{k:v for k,v in item.items() if k!='folder'} for item in index().values()], 'busy':LOCK.locked(),'token':TOKEN})
            if u.path=='/api/task': return self.send(detail(q['id'][0]))
            if u.path=='/api/image':
                folder=index()[q['id'][0]]['folder'];name=q['name'][0]
                if not re.fullmatch(r'[a-f0-9]{64}\.png',name): raise ValueError('无效图片')
                return self.send((folder/name).read_bytes(),kind='image/png')
            files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/performance.html':'performance.html','/performance.js':'performance.js','/performance.css':'performance.css'}
            if u.path not in files: return self.send({'error':'页面不存在'},404)
            name=files[u.path];kind={'html':'text/html','js':'text/javascript','css':'text/css'}[name.split('.')[-1]]
            self.send((ROOT/'web'/name).read_bytes(),kind=kind+'; charset=utf-8')
        except (KeyError,ValueError,FileNotFoundError) as exc: self.send({'error':str(exc)},404)
    def do_POST(self):
        origin=self.headers.get('Origin')
        if not self.allowed() or self.headers.get('X-Workbench-Token')!=TOKEN or (origin and origin not in {f'http://localhost:{self.server.server_port}',f'http://127.0.0.1:{self.server.server_port}'}): return self.send({'error':'请求来源无效'},403)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size>64000: raise ValueError('任务内容过长')
            if size<=0: raise ValueError('请求内容为空')
            payload=json.loads(self.rfile.read(size))
            if not isinstance(payload,dict): raise ValueError('请求格式错误')
            action={'/api/start':'new','/api/resume':'resume','/api/recover':'recover'}.get(self.path)
            if not action: return self.send({'error':'操作不存在'},404)
            self.send(start(action,payload),202)
        except (ValueError,KeyError) as exc:self.send({'error':str(exc)},400)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8795);a=p.parse_args()
    print(f'UE 工作台 http://127.0.0.1:{a.port}',flush=True)
    ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
