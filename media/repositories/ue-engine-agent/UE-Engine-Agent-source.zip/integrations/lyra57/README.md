# Lyra 5.7 性能适配器

本目录提供 PerformanceLab 插件源码和11个 Lyra 接口补丁。来源固定为本机 Lyra 工程提交 `5f896dee564f732b69d1ee36711c886230382bbc`，干净基线及逐文件哈希在 manifest.json 中。导出使用已提交源码，未读取或覆盖工作区未提交改动。未包含 UE 本体、Lyra 美术资产或编译产物。

## 安装到自己的工程副本

准备 UE 5.7.4 和对应 Lyra Starter Game，包括 ShooterCore、ShooterMaps 与原始 Niagara 素材。补丁要求目标接口文件匹配 manifest 中的基线；其他版本需要人工移植。

```powershell
# 先查看兼容性；默认不写入
python -m scripts.install_lyra_integration --project D:/YourLyraCopy/LyraStarterGame.uproject
# 安装到该副本，自动保存源文件和uproject备份
python -m scripts.install_lyra_integration --project D:/YourLyraCopy/LyraStarterGame.uproject --apply
& 'C:/Program Files/Epic Games/UE_5.7/Engine/Build/BatchFiles/Build.bat' LyraEditor Win64 Development '-Project=D:/YourLyraCopy/LyraStarterGame.uproject' -WaitMutex -NoHotReloadFromIDE
```

安装会启用 PerformanceLab，逐文件读回，失败时恢复原文件。已有插件文件或不同版本接口不会被覆盖。备份位于目标工程 `.engine-agent-integration/<时间戳>`。安装成功与编译成功分别记录。

## 连接 Agent

```powershell
$env:ENGINE_AGENT_LYRA_PROJECT='D:/YourLyraCopy/LyraStarterGame.uproject'
$env:ENGINE_AGENT_LYRA_EDITOR='C:/Program Files/Epic Games/UE_5.7/Engine/Binaries/Win64/UnrealEditor.exe'
python -m engine_agent.environment
python -m engine_agent.workbench --port 8796
python -m engine_agent.capture start crowd-baseline-001 --variant CrowdRenderingBaseline --view-profile mixed
python -m engine_agent.capture observe crowd-baseline-001
```

先等待基线结束，再使用同一视角采集 RayTracingLOD。模型也可通过 read_performance_environment 读取当前依赖，并调用 start_capture 启动实验。没有 Git 的工程记录为 unversioned，仍保存项目及实际 DLL 哈希。

## 场景范围

- 200角色实验使用原始 L_ShooterPerf 地图与 B_ShooterGame_Perf Experience，加上本适配器的角色策略和采集。
- Niagara 激活实验引用 Lyra 自带 NS_WallPortalEnter、NS_CharacterPortalDissolve。模型入口 start_niagara_probe。
- 旧9AI/300物体实验依赖用户的 HeroArena Experience。本包未包含该自定义资产；普通 Lyra 应先使用前两种场景。环境检查会单独报告缺失项。

当前公开记录是在 RTX4080、Windows、UE5.7.4 上取得，重新编译后的二进制身份会改变，应重新采集基线。源码安装检查不代表新设备已经复现了历史性能数值。

## 来源与分发

PerformanceLab 为用户工程中的自研插件。补丁引用 Lyra 接口，保留 Epic 原版权声明；Lyra 与 UE 资产、原始源码应从 Epic 官方渠道取得，并遵循其许可。此目录仅提供集成所需改动，不复制整个游戏工程。
