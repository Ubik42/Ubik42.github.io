const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const base=process.env.WORKBENCH_URL||'http://127.0.0.1:8796';
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE});const page=await browser.newPage({viewport:{width:1440,height:1050}});let errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(base+'/performance.html');await page.locator('#phases .phase').first().waitFor();
 await page.locator('#compare').click();await page.locator('#deltas tr').first().waitFor();
 await page.screenshot({path:'docs/images/performance-workbench.png',fullPage:true});
 console.log(JSON.stringify({errors,rows:await page.locator('#deltas tr').count(),title:await page.locator('#heading').innerText(),overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)}));
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'artifacts/performance/workbench-mobile.png',fullPage:true});console.log('mobileOverflow',await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth));
 // Exercise the real read-only model-analysis button once.
 if(process.argv.includes('--analyze')){await page.setViewportSize({width:1440,height:1050});await page.locator('#diagnose').click();await page.waitForURL(/\?task=/);console.log('task',page.url());}
 await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1});

