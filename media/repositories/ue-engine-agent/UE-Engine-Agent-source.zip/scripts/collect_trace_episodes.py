"""Collect recorded teleport/Niagara occurrences for a completed Insights export."""
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine_agent.trace_episodes import read_episodes
print(json.dumps(read_episodes(sys.argv[1]),ensure_ascii=False,indent=2))
