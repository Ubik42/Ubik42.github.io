"""Run the fixed read-only cases; preserve outputs for explicit human review."""
import argparse
import json
from pathlib import Path
from engine_agent.agent import Agent


class ReadOnlyEvaluationAgent(Agent):
    def call_tool(self, session, turn, index, name, args):
        allowed = {'read_capture', 'compare_captures', 'read_frame', 'read_engine_log', 'read_history'}
        if name not in allowed:
            return {'denied': True, 'reason': 'Evaluation uses existing evidence only; no host launches or writes.'}
        return super().call_tool(session, turn, index, name, args)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--case')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).resolve().parents[1]/'examples/performance-evaluation.json'
    suite = json.loads(source.read_text(encoding='utf-8'))
    results = []
    for case in suite['cases']:
        if args.case and args.case != case['id']:
            continue
        agent = ReadOnlyEvaluationAgent(args.output/case['id'], None, performance_only=True)
        result = agent.run(case['id'], case['prompt'], 5)
        results.append({'case': case, 'result': result, 'review_status': 'pending_human_review'})
        (args.output/'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'cases':len(results),'output':str(args.output),'grading':'Manual rubric; no automatic pass claim'},ensure_ascii=False))


if __name__ == '__main__':
    main()
