"""Generate tool schemas from the actual model registry."""
import json
from pathlib import Path
from engine_agent.agent import PERFORMANCE_TOOLS,PERFORMANCE_SYSTEM
root=Path(__file__).resolve().parents[1]
(root/'docs/performance-tools.json').write_text(json.dumps(PERFORMANCE_TOOLS,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'docs/performance-system-prompt.txt').write_text(PERFORMANCE_SYSTEM,encoding='utf-8')
print('Exported',len(PERFORMANCE_TOOLS),'registered tools and current system prompt')
