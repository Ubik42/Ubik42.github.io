"""Install the versioned PerformanceLab adapter into an explicit Lyra copy."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

PACKAGE = Path(__file__).resolve().parents[1]/'integrations/lyra57'


def digest(raw):
    return hashlib.sha256(raw.replace(b'\r\n', b'\n')).hexdigest()


def install(project, apply=False):
    project = Path(project).resolve(strict=True)
    if project.suffix.lower()!='.uproject':
        raise ValueError('Expected an explicit .uproject file')
    root = project.parent
    descriptor = json.loads(project.read_text(encoding='utf-8-sig'))
    manifest = json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))
    patch = PACKAGE/'lyra-hooks.patch'
    if hashlib.sha256(patch.read_bytes()).hexdigest() != manifest['patch_sha256']:
        raise ValueError('Integration patch hash differs')
    originals = {}
    for relative, hashes in manifest['hooks'].items():
        path = root/relative
        if not path.resolve().is_relative_to(root):
            raise ValueError('Hook points outside target project: '+relative)
        originals[path] = path.read_bytes()
        if digest(originals[path]) != hashes['before']:
            raise ValueError('Target differs from supported clean baseline: '+relative)
    for relative, expected in manifest['plugin_files'].items():
        if not (root/relative).resolve().is_relative_to(root):
            raise ValueError('Plugin destination points outside target project: '+relative)
        if digest((PACKAGE/relative).read_bytes()) != expected:
            raise ValueError('Packaged source differs: '+relative)
        if (root/relative).exists():
            raise ValueError('Existing plugin file would be overwritten: '+relative)
    command = ['git','-C',str(root),'apply','--ignore-space-change']
    environment=os.environ.copy()
    for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE'):
        environment.pop(key,None)
    environment['GIT_CEILING_DIRECTORIES']=str(root.parent)
    subprocess.run([*command,'--check',str(patch)],check=True,capture_output=True,env=environment)
    report = {'ready': True, 'applied': False, 'project':str(project),
              'hooks':len(originals),'plugin_files':len(manifest['plugin_files']),
              'engine':manifest['engine_version'], 'build_status':'not_built'}
    if not apply:
        return report
    backup = root/'.engine-agent-integration'/str(time.time_ns())
    backup.mkdir(parents=True,exist_ok=False)
    originals[project] = project.read_bytes()
    for path,raw in originals.items():
        saved = backup/path.relative_to(root)
        saved.parent.mkdir(parents=True,exist_ok=True)
        saved.write_bytes(raw)
    created = []
    try:
        subprocess.run([*command,str(patch)],check=True,capture_output=True,env=environment)
        for relative in manifest['plugin_files']:
            path = root/relative
            path.parent.mkdir(parents=True,exist_ok=True)
            created.append(path)
            shutil.copyfile(PACKAGE/relative,path)
        plugins = descriptor.setdefault('Plugins',[])
        entry = next((p for p in plugins if p['Name']=='PerformanceLab'),None)
        if entry is None:
            plugins.append({'Name':'PerformanceLab','Enabled':True})
        else:
            entry['Enabled'] = True
        project.write_text(json.dumps(descriptor,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        for relative,hashes in manifest['hooks'].items():
            if digest((root/relative).read_bytes()) != hashes['after']:
                raise ValueError('Applied hook readback differs: '+relative)
    except Exception:
        for path,raw in originals.items():
            path.write_bytes(raw)
        for path in created:
            path.unlink(missing_ok=True)
        raise
    report.update(applied=True,backup=str(backup))
    (backup/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',type=Path,required=True)
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    print(json.dumps(install(args.project,args.apply),ensure_ascii=False,indent=2))
