"""Export committed source with an embedded revision record."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
    output=args.output.resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','-C',str(root),'archive','--format=zip','--output='+str(output),revision],check=True)
    record={'revision':revision,'scope':'Committed project source and evidence; excludes artifacts and external UE/Lyra assets'}
    with zipfile.ZipFile(output,'a',compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('SOURCE_REVISION.json',json.dumps(record,ensure_ascii=False,indent=2))
        bad=archive.testzip()
        if bad:raise RuntimeError('Corrupt archive member: '+bad)
    print(json.dumps({**record,'output':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
