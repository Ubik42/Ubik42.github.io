"""Render a source-linked timeline from the recorded Lyra trace window."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
folder=ROOT/'artifacts/performance/jobs/physics-trace-20261103-001/insights'
windows=[json.loads(p.read_text(encoding='utf-8')) for p in folder.glob('window-*.json')]
data=next(w for w in windows if w['interval_seconds']==[53.141616,53.200201])
names={'UCharacterMovementComponent_TickComponent','EndScopedMovementUpdate Time',
       'USceneComponent::UpdateOverlaps','ExecuteUbergraph_B_Teleport',
       'ExecuteUbergraph_GCNL_Teleporter_Activate','UNiagaraSystem::RequestCompile',
       'NiagaraAsyncTask_DigestSystem'}
events=sorted((e for e in data['events'] if e['name'] in names and e['end']-e['start']>.0001),key=lambda e:(e['depth'],e['start']))
plt.rcParams['font.sans-serif']=['Microsoft YaHei']
plt.rcParams['axes.unicode_minus']=False
fig,ax=plt.subplots(figsize=(15,7),facecolor='#f4f7fb')
ax.set_facecolor('#f4f7fb')
origin=data['interval_seconds'][0]
for i,e in enumerate(events):
    begin=(e['start']-origin)*1000; duration=(e['end']-e['start'])*1000
    color='#dd7546' if 'Digest' in e['name'] else ('#9866c8' if 'Compile' in e['name'] else '#218d9d')
    ax.barh(i,duration,left=begin,height=.62,color=color)
    ax.text(begin+duration/2,i,f'{duration:.2f} ms',ha='center',va='center',color='white',fontsize=10)
ax.set_yticks(range(len(events)),[e['name'] for e in events],fontsize=10)
ax.invert_yaxis();ax.set_xlim(0,60);ax.set_xlabel('相对所选区间起点的时间（ms）')
ax.set_title('Lyra 传送事件：移动更新中的两次 Niagara 编译准备',loc='left',fontsize=17,pad=20)
ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
for spine in ax.spines.values():spine.set_visible(False)
fig.text(.02,.02,'真实 CPU Trace · 53.141616–53.200201 s · 嵌套包含耗时，不能相加 · 编辑器 -game 开发运行',fontsize=10,color='#526274')
fig.tight_layout(rect=(0,.05,1,1))
out=ROOT/'docs/images/teleport-trace.png';out.parent.mkdir(exist_ok=True)
fig.savefig(out,dpi=150)
print(out)
