param([switch]$BuildScene,[switch]$ProbePlatform,[ValidatePattern('^[a-zA-Z0-9_-]{1,100}$')][string]$ProbeId='legacy')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$editor='C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe'
$out=Join-Path $root 'artifacts'
New-Item -ItemType Directory -Force $out | Out-Null
$argsList=@(('"'+$root+'/Host/EngineAgentHost.uproject"'),'-RenderOffscreen','-unattended','-nosplash','-NoSound','-NoLiveCoding','-ForceRes','-ResX=1600','-ResY=900')
if($BuildScene){
    $argsList+=('-ExecutePythonScript="'+$root+'/Host/Content/Python/build_workshop.py"')
    $argsList+=('-abslog="'+$out+'/scene-build.log"')
}else{
    if(Get-NetTCPConnection -LocalPort 18086 -State Listen -ErrorAction SilentlyContinue){throw 'Port 18086 is already occupied'}
    $argsList+='-ExecCmds="ModelContextProtocol.StartServer 18086,t.MaxFPS 30"'
    $argsList+=('-abslog="'+$out+'/host.log"')
    if($ProbePlatform){
        $argsList+=('-ExecutePythonScript="'+$root+'/Host/Content/Python/probe_platform.py"')
        $argsList+=('-EngineAgentProbeId='+$ProbeId)
    }
}
$p=Start-Process $editor -ArgumentList $argsList -WindowStyle Hidden -PassThru
@{pid=$p.Id;started=$p.StartTime.ToUniversalTime().ToString('o');project="$root/Host/EngineAgentHost.uproject"} | ConvertTo-Json | Set-Content "$out/host-process.json" -Encoding utf8
Write-Output "Owned UE PID: $($p.Id)"
if($BuildScene){$p.WaitForExit();if(!(Select-String "$out/scene-build.log" -Pattern ENGINE_AGENT_WORKSHOP_READY -Quiet)){throw 'Scene build failed; see log'}}
else{
    $deadline=[datetime]::UtcNow.AddSeconds(90)
    while([datetime]::UtcNow -lt $deadline){
        if($p.HasExited){throw 'UE exited before MCP was ready'}
        $listener=Get-NetTCPConnection -LocalPort 18086 -State Listen -ErrorAction SilentlyContinue
        if($listener -and $listener.OwningProcess -eq $p.Id){Write-Output 'Owned MCP host is ready';return}
        Start-Sleep -Milliseconds 500
    }
    throw 'Owned host did not become ready; inspect artifacts/host.log'
}
