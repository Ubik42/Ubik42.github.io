$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$record=Get-Content "$root/artifacts/host-process.json" -Raw | ConvertFrom-Json
$owned=Get-Process -Id $record.pid -ErrorAction SilentlyContinue
if(!$owned){return}
if($owned.StartTime.ToUniversalTime().Ticks -ne ([datetime]$record.started).ToUniversalTime().Ticks){throw 'PID was reused; refusing to stop'}
$null=$owned.CloseMainWindow()
if(!$owned.WaitForExit(8000)){Stop-Process -Id $owned.Id; $owned.WaitForExit()}
Write-Output 'Owned UE host stopped'
