"""Visual-only HeroArena PIE evidence; no asset saves or performance claims."""
import json, os, time, traceback
from pathlib import Path
import unreal

folder=Path(os.environ['ENGINE_AGENT_RENDER_PROBE'])
crowd=os.environ.get('ENGINE_AGENT_RENDER_CROWD')=='1'
report={'state':'starting','purpose':'Visual-only PIE scene capture; separate from performance run','frames':[]}
step=0;busy=False;started=time.monotonic();capture=None;target=None

def save():
    (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
def finish(error=None):
    report['state']='failed' if error else 'completed'
    if error:report['error']=error
    save();unreal.unregister_slate_post_tick_callback(handle)
    unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_end_play()
    unreal.EditorPythonScripting.set_keep_python_script_alive(False)

def tick(delta):
    global step,busy,capture,target
    if busy:return
    busy=True
    try:
        if time.monotonic()-started>150:raise RuntimeError('Visual fixture exceeded 150 seconds')
        editor=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
        if step==0:
            actor=unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.SceneCapture2D,unreal.Vector(0,0,1000))
            actor.set_actor_label('AgentRenderingEvidence')
            component=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
            component.set_editor_property('capture_every_frame',True)
            component.set_editor_property('capture_on_movement',False)
            unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_request_begin_play()
            step=1;return
        world=editor.get_game_world()
        if not world:return
        seconds=unreal.GameplayStatics.get_time_seconds(world)
        if seconds<5:return
        camera=unreal.GameplayStatics.get_player_camera_manager(world,0)
        if not camera:return
        actors=unreal.GameplayStatics.get_all_actors_of_class(world,unreal.SceneCapture2D)
        actor=next(a for a in actors if a.get_actor_label()=='AgentRenderingEvidence')
        actor.set_actor_location_and_rotation(camera.get_camera_location(),camera.get_camera_rotation(),False,True)
        capture=actor.get_component_by_class(unreal.SceneCaptureComponent2D)
        if target is None:
            target=unreal.RenderingLibrary.create_render_target2d(world,1280,720,unreal.TextureRenderTargetFormat.RTF_RGBA8)
            capture.set_editor_property('texture_target',target)
            capture.set_editor_property('capture_source',unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR)
        capture.set_editor_property('fov_angle',camera.get_fov_angle())
        if seconds<(10+(step-1)*4 if crowd else 20+(step-1)*5):return
        capture.capture_scene()
        filename=f'frame-{step}.png'
        unreal.RenderingLibrary.export_render_target(world,target,str(folder),filename)
        characters=unreal.GameplayStatics.get_all_actors_of_class(world,unreal.Character)
        rows=[]
        for character in characters:
            for mesh in character.get_components_by_class(unreal.SkeletalMeshComponent):
                rows.append({'actor':character.get_path_name(),'component':mesh.get_name(),
                             'custom_depth':mesh.get_editor_property('render_custom_depth'),
                             'visible_in_ray_tracing':mesh.get_editor_property('visible_in_ray_tracing'),
                             'cast_shadow':mesh.get_editor_property('cast_shadow'),
                             'distance':character.get_actor_location().distance(camera.get_camera_location())})
        report['frames'].append({'file':filename,'game_time':seconds,'world':world.get_path_name(),
                                 'camera_location':str(camera.get_camera_location()),'characters':rows})
        report['state']='running';save();step+=1
        if step==4:finish()
    except Exception:finish(traceback.format_exc())
    finally:busy=False

unreal.EditorPythonScripting.set_keep_python_script_alive(True)
handle=unreal.register_slate_post_tick_callback(tick)
