---
name: ue-performance-investigation
description: 用本工程的真实 UE 采集、Trace 和持久实验任务完成性能调查、对照与归档。
---

# UE 性能调查

在 UE-Engine-Agent 根目录工作。先读 docs/PROGRESS.md 末项和任务目标；原始资料见 docs/inputs。已有 run_id 先观察状态，有活动宿主时继续同一任务。

1. 使用 read_capture 读取采集完成状态、负载、环境及指标。选择一个有数据支持的问题，写明待验证假设和唯一主要变量。
2. 卡顿用 read_frame 检查邻近记录；有 Trace 时 export_trace → read_trace → read_trace_window。GPU 用阶段计时和实际参与对象计数。内存先区分用量、预算和分配归属。
3. 选择 start_capture 已实现变体，或使用固定 Niagara 探针。所有宿主动作串行；外部工程只读。工具返回运行中后保存 run_id，结束本次模型执行，稍后读回。
4. compare_captures 检查身份及负载，再比较局部阶段、整帧和画面。没有收益就保留结果并换假设。线程时间、作用域及不同分位数不得相加证明因果。
5. archive_comparison 保存完整 CSV、摘要、比较及模型署名。失败、无效或不确定结果也可以归档，不能标成已证明收益。真实图像另附原始任务路径和场景说明。

入口：`python -m engine_agent performance-agent <提示词文件> --session <稳定ID> --output artifacts/performance/<任务目录> --max-turns 8`。暂停在轮数上限时沿用同一 ID 和原始提示词，提高上限继续。已 model_completed 的会话用新 ID 开下一项任务。

团队说明见 docs/性能工具合同.md。完整动作留在 SQLite；正文写事实、主要结论和下一步，避免堆砌限制。
