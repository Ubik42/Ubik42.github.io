"""Check preserved actor pair identity using the original spatial relationship."""
import json,math
from pathlib import Path
from engine_agent.mcp import Client,text
from engine_agent.runtime import ACTOR

client=Client('http://127.0.0.1:18086/mcp');client.initialize()
original=json.loads(Path('artifacts/layout/initial-transforms.json').read_text(encoding='utf-8'))
records=[]
for row in original:
 actor=row['actor']
 label=json.loads(text(client.call(ACTOR,'get_label',{'actor':actor})))['returnValue']
 now=json.loads(text(client.call(ACTOR,'get_actor_transform',{'actor':actor})))['returnValue']
 records.append({**row,'label':label,'current':now})
results=[]
for target in [r for r in records if r['label'].startswith('Target ')]:
 before=target['before']['location']
 bases=[r for r in records if r['label'].startswith('Pedestal ') and all(math.isclose(r['before']['location'][k],before[k],abs_tol=.001) for k in ('x','y'))]
 assert len(bases)==1,'Original pedestal is ambiguous'
 base=bases[0]
 paired=all(math.isclose(target['current']['location'][k],base['current']['location'][k],abs_tol=.001) for k in ('x','y'))
 results.append({'target':target['label'],'original_pedestal':base['label'],'pair_preserved':paired})
for row in records:
 assert row['before']['rotation']==row['current']['rotation'] and row['before']['scale']==row['current']['scale']
 assert math.isclose(row['before']['location']['z'],row['current']['location']['z'],abs_tol=.001)
report={'pairs':results,'all_pairs_preserved':all(r['pair_preserved'] for r in results),'records':records}
Path('docs/evidence/layout-readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False))
assert report['all_pairs_preserved']
