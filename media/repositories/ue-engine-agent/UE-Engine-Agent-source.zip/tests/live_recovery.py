"""Real UE fault injection: host applies a write but its client loses the reply."""
import json
from pathlib import Path
from engine_agent.agent import Agent
from engine_agent.mcp import Client
from engine_agent.runtime import MATERIAL, ASSET

class DropReply:
    def __init__(self, client): self.client=client; self.writes=0
    def tool(self,*a,**kw): return self.client.tool(*a,**kw)
    def call(self,ts,tool,args):
        result=self.client.call(ts,tool,args)
        if tool=='set_scalar_parameter':
            self.writes+=1
            raise TimeoutError('Injected reply loss AFTER real UE write')
        return result

class Fixture:
    def __init__(self): self.calls=0
    def complete(self,messages,tools):
        self.calls+=1
        if self.calls==1:
            args={'reason':'Fault recovery fixture','steps':[{'id':'roughness','toolset':MATERIAL,'tool':'set_scalar_parameter','arguments':{'instance':{'refPath':'/Game/EngineAgent/MI_Target.MI_Target'},'name':'Roughness','value':0.4},'reason':'Write then intentionally lose reply'}]}
            message={'role':'assistant','content':'Fault injection fixture, not autonomous reasoning.','tool_calls':[{'id':'fixture-call','type':'function','function':{'name':'execute','arguments':json.dumps(args)}}]}
        else: message={'role':'assistant','content':'Fixture finished after recovered receipt.'}
        return message,{'model':'explicit-test-fixture','finish_reason':'tool_calls' if self.calls==1 else 'stop'}

client=Client('http://127.0.0.1:18086/mcp');client.initialize()
wrapped=DropReply(client);provider=Fixture()
folder=Path('artifacts/recovery-live')
agent=Agent(folder,wrapped,'explicit-test-fixture',provider)
try: agent.run('lost-reply-001','Exercise an applied write with a lost reply')
except TimeoutError: pass
else: raise AssertionError('Fault not injected')
assert agent.db.execute("SELECT status FROM agent_sessions WHERE id='lost-reply-001'").fetchone()[0]=='needs_readback'
recovery=agent.recover('lost-reply-001')
assert recovery['status']=='active' and recovery['reports'][0]['matched']
resumed=agent.run('lost-reply-001','Exercise an applied write with a lost reply')
assert resumed['status']=='model_completed' and wrapped.writes==1 and provider.calls==2
result={'fixture':'real host write + deliberately discarded reply','recovery':recovery,'resume':resumed,'write_calls':wrapped.writes,'model_source':'explicit fixture; no external model used'}
Path('docs/evidence/recovery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
# Restore the ceramic demonstration after the fault experiment.
client.call(MATERIAL,'set_scalar_parameter',{'instance':{'refPath':'/Game/EngineAgent/MI_Target.MI_Target'},'name':'Roughness','value':0.25})
client.call(ASSET,'save_assets',{'asset_paths':['/Game/EngineAgent/MI_Target']})
print(json.dumps(result,ensure_ascii=False,indent=2))
