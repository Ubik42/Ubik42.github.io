import tempfile
import unittest
from engine_agent.runtime import Runtime,validate,BLUEPRINT,SCENE,encode
from engine_agent.mcp import McpError

def result(value): return {'content':[{'type':'text','text':encode({'returnValue':value})}]}

class Host:
    def __init__(self): self.writes=0; self.reads=0
    def call(self,ts,tool,args):
        if tool=='get_current_level': return result('/Game/EngineAgent/L_Workshop')
        if tool=='read_graph_dsl':
            self.reads+=1
            return result('(event EventTick)' if self.writes else '')
        if tool=='write_graph_dsl':
            self.writes+=1
            raise McpError('Compile failed after adding EventTick')
        raise AssertionError(tool)

class BlueprintTests(unittest.TestCase):
    def test_partial_graph_error_reads_state_and_never_replays(self):
        with tempfile.TemporaryDirectory() as folder:
            host=Host(); rt=Runtime(folder,host)
            rt.validate_schema=lambda s:None
            step={'id':'graph','toolset':BLUEPRINT,'tool':'write_graph_dsl','arguments':{'graph':{'refPath':'/Game/EngineAgent/BP_Test.BP_Test:EventGraph'},'code':'bad'},'reason':'exercise partial compile failure'}
            plan={'run_id':'partial','intent':'failure recovery','planner':'test fixture','steps':[step]}
            first=rt.execute(plan)
            self.assertEqual(first['steps'][0]['state'],'failed')
            self.assertTrue(first['steps'][0]['result']['partial_write_possible'])
            self.assertIn('EventTick',encode(first))
            self.assertEqual(rt.execute(plan),first)
            self.assertEqual((host.writes,host.reads),(1,2))
            rt.db.close()

    def test_create_path_boundaries(self):
        for folder,name in [('/Game/EngineAgentElse','BP_Test'),('/Game/EngineAgent/../Other','BP_Test'),('/Game/EngineAgent','../Escape')]:
            with self.assertRaises(ValueError):
                validate({'id':'create','toolset':BLUEPRINT,'tool':'create','arguments':{'folder_path':folder,'asset_name':name,'asset_type':{'refPath':'/Script/Engine.Actor'}},'reason':'path boundary'})

if __name__=='__main__': unittest.main()
