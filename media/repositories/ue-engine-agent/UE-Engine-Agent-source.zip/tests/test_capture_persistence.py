import concurrent.futures,json,tempfile,unittest
from pathlib import Path
from engine_agent.capture import write

class CapturePersistence(unittest.TestCase):
    def test_concurrent_observers_keep_complete_job(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'job.json'
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                list(pool.map(lambda n:write(path,{'observation':n}),range(20)))
            self.assertIn(json.loads(path.read_text())['observation'],range(20))
            self.assertEqual(list(Path(folder).iterdir()),[path])

if __name__=='__main__':unittest.main()
