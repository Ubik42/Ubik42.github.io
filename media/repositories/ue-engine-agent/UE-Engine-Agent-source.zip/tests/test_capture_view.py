"""A resumed model action must preserve the original view, without launching UE."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from engine_agent import performance_tools as tools
import hashlib


class CaptureViewTest(unittest.TestCase):
    def test_resume_rejects_changed_view_before_execution(self):
        run = 'agent-' + hashlib.sha256(b's:1:0').hexdigest()[:20]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            folder = root / 'artifacts/performance/jobs' / run
            folder.mkdir(parents=True)
            (folder/'job.json').write_text(json.dumps({
                'experiment_variant': 'RayTracingLOD', 'view_profile': 'mixed',
                'trace_enabled': False,
            }), encoding='utf-8')
            with patch.object(tools, 'ROOT', root), patch.object(tools, 'start') as start:
                with self.assertRaisesRegex(ValueError, 'Frozen view profile differs'):
                    tools.start_capture('s', 1, 0, 'RayTracingLOD', view_profile='overview')
                start.assert_not_called()


if __name__ == '__main__':
    unittest.main()
