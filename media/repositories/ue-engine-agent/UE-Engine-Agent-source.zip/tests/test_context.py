import unittest
from engine_agent.context import request_context

class ContextWindow(unittest.TestCase):
    def test_preserves_tool_pairs_and_durable_input(self):
        messages=[{'role':'system','content':'rules'},{'role':'user','content':'intent'}]
        for n in range(8):
            messages += [{'role':'assistant','content':None,'tool_calls':[{'id':str(n),'type':'function','function':{'name':'read_capture','arguments':'{}'}}]},
                         {'role':'tool','tool_call_id':str(n),'content':'x'*2000}]
        result,meta=request_context(messages,[],max_chars=6000)
        self.assertGreater(meta['omitted_messages'],0)
        self.assertEqual(len(messages),18)
        self.assertEqual(result[0:2],messages[0:2])
        ids={c['id'] for m in result for c in m.get('tool_calls',[])}
        self.assertTrue(all(m['tool_call_id'] in ids for m in result if m['role']=='tool'))
        self.assertEqual(result[-1],messages[-1])
        self.assertLessEqual(meta['request_chars'],6000)
    def test_oversized_current_turn_has_explicit_error(self):
        messages=[{'role':'system','content':'s'},{'role':'user','content':'u'},
                  {'role':'assistant','content':'x'*2000}]
        with self.assertRaisesRegex(ValueError,'Latest complete tool turn'):
            request_context(messages,[],max_chars=1000)

if __name__=='__main__':unittest.main()
