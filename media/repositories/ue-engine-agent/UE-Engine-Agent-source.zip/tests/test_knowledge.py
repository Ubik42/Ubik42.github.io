import unittest
from unittest.mock import patch
from engine_agent.knowledge import search,read,identity
class KnowledgeTests(unittest.TestCase):
    def test_retrieval_and_missing_coverage(self):
        self.assertEqual(search('BaseColor 颜色参数不存在')['results'][0]['id'],'material-parameters')
        self.assertEqual(search('蓝图节点引脚编译')['results'][0]['id'],'blueprint-native')
        self.assertEqual(search('qzxyunknown')['results'],[])
    def test_changed_source_and_invalid_card(self):
        card=read('write-recovery');card['sources'][0]['sha256']='0'*64
        self.assertEqual(identity(card)['sources'][0]['local_status'],'changed_or_unavailable')
        with self.assertRaises(ValueError):read('../runtime.py')
        card['content']='tampered'
        with patch('engine_agent.knowledge.cards',return_value=[card]):
            with self.assertRaises(ValueError):read(card['id'])
if __name__=='__main__':unittest.main()
