import tempfile
import unittest
from pathlib import Path
from engine_agent.memory_timeline import analyze


class MemoryTimelineTest(unittest.TestCase):
    def test_pressure_uses_paired_budget_and_preserves_record_addresses(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'capture.csv'
            path.write_text('FrameTime,GPUMem/LocalUsedMB,GPUMem/LocalBudgetMB\n10,80,100\n10,90,200\n10,50,0\nmetadata,x,y\n',encoding='utf-8')
            r=analyze(path)
            self.assertEqual(r['sample_count'],3)
            self.assertEqual(r['budget_pressure']['local']['peak_ratio'],.8)
            self.assertEqual(r['budget_pressure']['local']['peak_csv_line'],2)
            self.assertEqual(r['budget_pressure']['local']['paired_samples'],2)
            self.assertEqual(r['budget_pressure']['local']['zero_budget_samples'],1)
            self.assertEqual(r['budget_pressure']['local']['paired_used_net_change_mib'],10)
            release=r['metrics']['gpu_local_used_mb']['largest_release']
            self.assertEqual((release['from_csv_line'],release['to_csv_line'],release['delta_mib']),(3,4,-40))


if __name__=='__main__':unittest.main()
