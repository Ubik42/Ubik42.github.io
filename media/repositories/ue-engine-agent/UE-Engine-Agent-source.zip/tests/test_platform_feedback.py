import unittest
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
from engine_agent.platform import summarize,run

class FeedbackTests(unittest.TestCase):
    def test_old_success_cannot_verify_new_graph(self):
        report={'graph_sha256':'old','passed':True,'count':66}
        stale=summarize(report,'new')
        self.assertFalse(stale['fresh'])
        self.assertFalse(stale['verified_current_graph'])
        self.assertTrue(summarize(report,'old')['verified_current_graph'])

    def test_current_failure_stays_failed(self):
        report={'graph_sha256':'same','passed':False}
        self.assertTrue(summarize(report,'same')['fresh'])
        self.assertFalse(summarize(report,'same')['verified_current_graph'])

    def test_pending_observation_never_restarts_host(self):
        with tempfile.TemporaryDirectory() as root:
            probes=Path(root)/'artifacts/platform-probes'
            probes.mkdir(parents=True)
            (probes/'active.json').write_text(json.dumps({'probe_id':'previous'}),encoding='utf-8')
            with patch('engine_agent.platform.ROOT',Path(root)),patch('engine_agent.platform.subprocess.run') as process:
                result=run(None,'new',{'center':180,'amplitude':55,'angular_speed':1,'duration':10})
                self.assertEqual(result['status'],'pending')
                self.assertEqual(result['probe_id'],'previous')
                process.assert_not_called()

if __name__=='__main__':unittest.main()
