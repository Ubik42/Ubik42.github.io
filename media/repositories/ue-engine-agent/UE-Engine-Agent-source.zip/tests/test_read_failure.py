import tempfile,unittest,json
from pathlib import Path
from engine_agent.runtime import Runtime,MATERIAL,SCENE
from engine_agent.mcp import McpError
class FakeClient:
    def __init__(self):self.writes=0;self.reads=0
    def call(self,ts,tool,args):
        if ts==SCENE:return {'content':[{'type':'text','text':json.dumps({'returnValue':'/Game/EngineAgent/L_Workshop'})}]}
        if tool.startswith('set_'):self.writes+=1;return {}
        self.reads+=1;raise McpError('Parameter does not exist')
class ReadFailure(unittest.TestCase):
    def test_failed_read_stops_dependent_write_and_replays_error(self):
        with tempfile.TemporaryDirectory() as directory:
            client=FakeClient();runtime=Runtime(Path(directory),client);runtime.validate_schema=lambda step:None
            base={'toolset':MATERIAL,'reason':'fixture','arguments':{'instance':{'refPath':'/Game/EngineAgent/MI_Target.MI_Target'},'name':'missing'}}
            read={**base,'id':'read','tool':'get_scalar_parameter'}
            write={**base,'id':'write','tool':'set_scalar_parameter','arguments':{**base['arguments'],'value':1}}
            plan={'run_id':'fixture','intent':'Read before write','planner':'test fixture','steps':[read,write]}
            first=runtime.execute(plan);second=runtime.execute(plan)
            self.assertEqual(first['steps'][0]['state'],'failed');self.assertEqual(len(second['steps']),1)
            self.assertEqual(client.writes,0);self.assertEqual(client.reads,1)
            runtime.db.close()
if __name__=='__main__':unittest.main()
