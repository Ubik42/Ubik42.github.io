# UE Engine Agent 案例短片

32 秒，1920×1080，30 fps，无配音。Remotion 编排五段：任务、实际 DSL 的结构示意、旧采样失效、真实 UE 运行复现、原始模型任务结果。

素材来源：
- 模型任务：docs/evidence/platform-feedback，13 轮实际独立 API 调用与 82 个原始采样点。
- 运行画面：artifacts/platform-probes/video-001。已保存蓝图重新进入 SIE，采集 82 张真实画面和 83 个位置点。该次复现没有重新调用模型。
- 图示按实际 EventGraph DSL 概括，片中明确标注“结构示意”。

画面依据截图请求的游戏时间选帧，位置曲线依据同时采集的样本；截图在后续渲染帧完成，画面与读数存在帧级时差。采集与编码不用于帧率或性能测评。源帧保留在本地 artifacts，避免将整套临时图像加入源码仓。

## 重新录制与导出

1. 在 artifacts/platform-probes/video-001/request.json 写入 center=180、amplitude=55、angular_speed=1、duration=10、record_frames=true。新录制应使用独立目录并相应调整 render.cjs 的输入。
2. 运行 `scripts/start_host.ps1 -ProbePlatform -ProbeId video-001`，等待该目录 readback.json 出现并检查 passed。
3. 运行 `node video/render.cjs --stills` 核对关键帧，再运行 `node video/render.cjs` 输出 MP4。

默认复用 D:/work/_tools/ue-client-portfolio-lab/showcase-video 已安装的 Remotion 4.0.536。可通过 REMOTION_RUNTIME 指向另一个安装了 remotion、@remotion/bundler、@remotion/renderer 与 React 的工程。源码、原始素材和输出均留在 UE-Engine-Agent 工程内。

输出：artifacts/video/UE-Engine-Agent.mp4。最终 MP4 另随个人主页发布。
