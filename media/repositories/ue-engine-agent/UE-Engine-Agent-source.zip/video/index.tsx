import React from 'react';
import {AbsoluteFill,Composition,Img,interpolate,registerRoot,staticFile,useCurrentFrame} from 'remotion';

const ink='#eef3fa',cyan='#63e1ca',gold='#efc477',muted='#aebed0';
const label:React.CSSProperties={fontSize:29,color:muted,letterSpacing:2};
const title:React.CSSProperties={fontSize:72,fontWeight:750,lineHeight:1.25,margin:0};
const Panel:React.FC<{children:React.ReactNode}>=({children})=><div style={{padding:38,border:'1px solid #2c4057',background:'#112033',borderRadius:20}}>{children}</div>;
const Node=({name,value,x,y,w=330}:{name:string,value:string,x:number,y:number,w?:number})=><div style={{position:'absolute',left:x,top:y,width:w,background:'#172b40',border:'2px solid #3b5975',borderRadius:14,overflow:'hidden'}}><div style={{background:'#244763',padding:'12px 20px',fontSize:26,color:cyan}}>{name}</div><div style={{padding:22,fontSize:34}}>{value}</div></div>;

const Film=({capture,task}:any)=>{
 const frame=useCurrentFrame(),t=frame/30;
 const stage=t<5?0:t<12?1:t<17?2:t<27?3:4;
 const starts=[0,5,12,17,27],local=t-starts[stage];
 const opacity=interpolate(local,[0,.35],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const shot=[...capture.capture_frames].reverse().find((x:any)=>x.requested_game_time<=local)??capture.capture_frames[0];
 const points=capture.samples.filter((x:any)=>x.time<=local).map((x:any)=>`${30+x.time*29},${230-(x.z-120)*1.6}`).join(' ');
 return <AbsoluteFill style={{background:'#091321',color:ink,fontFamily:'Microsoft YaHei, sans-serif'}}>
  <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at 80% 10%,#18374a 0%,transparent 65%)'}}/>
  <div style={{position:'relative',padding:'56px 80px',height:'100%',boxSizing:'border-box',display:'flex',flexDirection:'column',gap:28}}>
   <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',...label}}><span style={{color:cyan}}>UE ENGINE AGENT</span><span>真实调用记录 · UE 5.8</span></div>
   <div style={{flex:1,position:'relative',opacity,display:'flex',flexDirection:'column',justifyContent:'center',gap:36}}>
   {stage===0&&<><div style={{...label,color:gold}}>从修改蓝图，到运行反馈</div><h1 style={{...title,fontSize:100}}>让 Agent 完成<br/>一次可追溯的玩法迭代</h1><div style={{fontSize:40,color:muted}}>目标：升降平台高度 180 ± 55 cm</div><div style={{display:'flex',gap:22,marginTop:15}}>{['读取旧结果','修改与保存','运行并读回'].map((x,i)=><Panel key={x}><span style={{color:cyan,marginRight:20,fontSize:34}}>0{i+1}</span><span style={{fontSize:34}}>{x}</span></Panel>)}</div><p style={{...label,letterSpacing:0}}>操作展示依据已保存的独立模型调用记录</p></>}
   {stage===1&&<><h1 style={title}>模型查询节点与引脚，再连接蓝图</h1><div style={{...label,letterSpacing:0}}>实际生成的 EventGraph 结构示意</div><div style={{position:'relative',height:480}}>
    <svg width="1760" height="480" style={{position:'absolute'}}><g stroke={cyan} strokeWidth="5" fill="none"><path d="M330 85 H1330 V105"/><path d="M330 330 H435"/><path d="M765 330 H870"/><path d="M1200 330 H1320 V210 H1470"/></g></svg>
    <Node x={0} y={10} name="事件" value="Event Tick"/>
    <Node x={0} y={255} name="时间" value="Game Time → t"/>
    <Node x={435} y={255} name="周期计算" value="sin(t) × 55"/>
    <Node x={870} y={255} name="高度偏移" value="+ 180 cm"/>
    <Node x={1320} y={115} w={430} name="位置写入" value="SetActorLocation"/>
   </div><div style={{fontSize:37,color:muted}}>游戏时间直接求值 → 编译 → 保存 → 图结构读回</div></>}
   {stage===2&&<><h1 style={title}>蓝图改了，旧的成功结果就过期</h1><div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:36}}><Panel><div style={label}>旧采样 · 65 个位置点</div><div style={{fontSize:60,margin:'32px 0'}}>120 ± 80 cm</div><div style={{fontSize:32,color:gold}}>图摘要 b9b5ed…</div></Panel><Panel><div style={label}>当前蓝图</div><div style={{fontSize:60,margin:'32px 0'}}>180 ± 55 cm</div><div style={{fontSize:32,color:cyan}}>图摘要 1a360b…</div></Panel></div><div style={{fontSize:42,color:gold}}>fresh = false → 重新运行，获取当前图的结果</div></>}
   {stage===3&&<><h1 style={{...title,fontSize:60}}>已保存蓝图 · 真实 UE 运行复现</h1><div style={{display:'grid',gridTemplateColumns:'1280px 1fr',gap:28,alignItems:'center'}}><Img src={staticFile('frames/'+shot.file)} style={{width:1280,height:720,objectFit:'contain',borderRadius:16}}/><div style={{display:'flex',flexDirection:'column',gap:25}}><div style={label}>采样高度</div><div style={{fontSize:64,color:cyan}}>{shot.sample_z.toFixed(1)}<span style={{fontSize:29}}> cm</span></div><div style={{fontSize:30,color:muted}}>目标 125–235 cm</div><svg width="350" height="270"><path d="M30 20 V245 H330" fill="none" stroke="#45617a" strokeWidth="2"/><polyline points={points} fill="none" stroke={gold} strokeWidth="5"/></svg><div style={{fontSize:27,color:muted}}>按游戏时间重放<br/>采集帧与位置数据</div></div></div></>}
   {stage===4&&<><div style={{...label,color:cyan}}>模型任务的原始验证结果</div><h1 style={title}>修改、运行、反馈连接起来</h1><div style={{display:'flex',gap:90,margin:'30px 0'}}>{[['13','轮模型调用'],[String(task.count),'个位置点'],['10 s','模拟采样']].map(([v,k])=><div key={k}><div style={{fontSize:108,color:cyan,fontWeight:750}}>{v}</div><div style={{fontSize:34,color:muted}}>{k}</div></div>)}</div><div style={{fontSize:42}}>高度 {task.z_range[0].toFixed(3)}–{task.z_range[1].toFixed(3)} cm</div><div style={{fontSize:32,color:muted}}>保存图身份、原始数据、错误记录和真实截图</div><div style={{fontSize:27,color:muted}}>固定运动案例；碰撞、玩家搭乘与联网另行验证</div></>}
   </div>
   <div style={{display:'flex',justifyContent:'space-between',...label,fontSize:25,letterSpacing:0}}><span>UE 引擎 Agent · 独立 DeepSeek API 规划 / 原生 MCP 执行</span><span>{['任务','图逻辑','结果版本','运行复现','验证记录'][stage]}</span></div>
  </div>
  <div style={{position:'absolute',bottom:0,height:5,width:`${t/32*100}%`,background:cyan}}/>
 </AbsoluteFill>;
};
registerRoot(()=> <Composition id="EngineAgent" component={Film} durationInFrames={960} fps={30} width={1920} height={1080} defaultProps={{capture:{capture_frames:[],samples:[]},task:{}}}/>);



