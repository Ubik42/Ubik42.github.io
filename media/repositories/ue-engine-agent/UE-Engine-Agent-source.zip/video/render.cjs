// Reuse the installed Remotion runtime; all source and output stay in this project.
const fs=require('fs'),path=require('path'),{createRequire}=require('module');
const root=path.resolve(__dirname,'..');
const runtime=process.env.REMOTION_RUNTIME||'D:/work/_tools/ue-client-portfolio-lab/showcase-video';
const load=createRequire(path.join(runtime,'package.json'));
const {bundle}=load('@remotion/bundler');
const {selectComposition,renderMedia,renderStill}=load('@remotion/renderer');
(async()=>{
 const probe=path.join(root,'artifacts/platform-probes/video-001');
 const capture=JSON.parse(fs.readFileSync(path.join(probe,'readback.json'),'utf8'));
 const task=JSON.parse(fs.readFileSync(path.join(root,'docs/evidence/platform-feedback/runtime.json'),'utf8'));
 if(!capture.passed||capture.graph_sha256!==task.graph_sha256)throw Error('Recording does not match the verified Blueprint');
 for(const frame of capture.capture_frames)if(!fs.existsSync(path.join(probe,'frames',frame.file)))throw Error('Missing capture '+frame.file);
 const serveUrl=await bundle({entryPoint:path.join(__dirname,'index.tsx'),publicDir:probe,outDir:path.join(root,'artifacts/video-bundle'),webpackOverride:c=>({...c,resolve:{...c.resolve,modules:[path.join(runtime,'node_modules'),...(c.resolve.modules||[])]},resolveLoader:{...c.resolveLoader,modules:[path.join(runtime,'node_modules'),'node_modules']}})});
 const inputProps={capture,task};
 const composition=await selectComposition({serveUrl,id:'EngineAgent',inputProps});
 const output=path.join(root,'artifacts/video');fs.mkdirSync(output,{recursive:true});
 if(process.argv.includes('--stills')){
   for(const frame of [60,240,420,660,870])await renderStill({composition,serveUrl,inputProps,frame,output:path.join(output,`frame-${frame}.png`)});
 }else{
   await renderMedia({composition,serveUrl,inputProps,codec:'h264',outputLocation:path.join(output,'UE-Engine-Agent.mp4'),concurrency:4,onProgress:({progress})=>{if(Math.round(progress*100)%10===0)process.stdout.write('.')}});
 }
 console.log('\n'+output);
})().catch(e=>{console.error(e);process.exit(1)});
