param([ValidateSet('Individual','Instanced')][string]$Variant='Instanced',[string]$Label='pilot',[ValidateSet('Desktop','MobilePreview')][string]$Renderer='Desktop',[switch]$MobileMap,[ValidateSet('Default','FullRange','CourtyardBudget')][string]$ShadowProfile='Default')
$ErrorActionPreference='Stop'
$output=Join-Path $PSScriptRoot ('Saved/Experiments/runtime-'+$Label+'-'+$Variant+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $output -Force | Out-Null
$image=(Join-Path $output 'runtime.png').Replace('\','/')
$commands='850:HighResShot 1600x900 filename='+$image
$argsList=@(('"'+$PSScriptRoot+'\MobileSceneLab.uproject"'),('/Game/Lab/L_Courtyard_'+$Variant),'-game','-unattended','-nosplash','-RenderOffscreen','-NoSound','-NoLiveCoding','-windowed','-ResX=1600','-ResY=900','-csvCaptureFrames=900','-csvCompression=0','-ExecCmds="r.VSync 0,t.MaxFPS 0,r.GPUCsvStatsEnabled 1,CsvProfile EXITONCOMPLETION"',('-csvExecCmds="'+$commands+'"'),('-abslog="'+$output+'\runtime.log"'))
if($MobileMap){$argsList[1]='/Game/Lab/L_Courtyard_Mobile'+$Variant}
$mapFile=Join-Path $PSScriptRoot ('Content/'+$argsList[1].Substring(6)+'.umap')
if(!(Test-Path -LiteralPath $mapFile)){throw "Map not built: $mapFile"}
if($Renderer -eq 'MobilePreview'){$argsList+=@('-featureleveles31','-dx11')}
$shadowCommands=@{Default='';FullRange='r.Shadow.MaxCSMResolution 2048,r.Shadow.CSM.MaxCascades 4,r.Shadow.DistanceScale 1';CourtyardBudget='r.Shadow.MaxCSMResolution 1024,r.Shadow.CSM.MaxCascades 2,r.Shadow.DistanceScale 0.3'}[$ShadowProfile]
if($shadowCommands){
    for($i=0;$i -lt $argsList.Count;$i++){if($argsList[$i].StartsWith('-ExecCmds=')){$argsList[$i]=$argsList[$i].TrimEnd('"')+','+$shadowCommands+'"'}}
}
$process=Start-Process -FilePath 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe' -ArgumentList $argsList -WindowStyle Hidden -PassThru
@{pid=$process.Id;variant=$Variant;output=$output;arguments=$argsList;renderer=$Renderer;shadowProfile=$ShadowProfile;shadowCommands=$shadowCommands;platform=$(if($Renderer -eq 'MobilePreview'){'Windows D3D11 ES3_1 mobile preview on desktop GPU'}else{'Windows D3D12 SM5 standalone -game'})} | ConvertTo-Json -Depth 4 | Set-Content "$output/run.json" -Encoding utf8
Write-Output "Runtime PID $($process.Id): $output"
$process.WaitForExit()
$match=Select-String -LiteralPath "$output/runtime.log" -Pattern 'Writing CSV to file : (.+)' | Select-Object -Last 1
if(!$match){throw "No completed CSV in $output/runtime.log"}
$csvPath=$match.Matches[0].Groups[1].Value.Trim()
if(![IO.Path]::IsPathRooted($csvPath)){$csvPath=[IO.Path]::GetFullPath((Join-Path 'C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64' $csvPath))}
Copy-Item -LiteralPath $csvPath -Destination "$output/profile.csv"
Write-Output $output
