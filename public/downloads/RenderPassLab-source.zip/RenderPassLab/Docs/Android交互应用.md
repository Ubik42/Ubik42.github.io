# Android交互应用

## 本轮实现

新增Java Activity和JNI入口，复用原生Lab类完成网格、深度、HDR附件和后处理链。用户选择独立Pass或Subpass路径，后台串行执行Vulkan渲染，读回PPM后转换为Bitmap显示。运行期间禁用两个按钮，完成后恢复；错误显示在状态区。Activity关闭后停止接收界面更新，并回收图片。

Shader从APK assets复制到应用私有目录。两个路径分别保存frame.png和result.json，便于核对输出。JNI串行锁保护共享Vulkan函数指针及Shader目录；每次运行由Lab析构释放资源。当前为按需离屏渲染显示，尚未实现连续Swapchain呈现。

## 构建与运行

运行`scripts/build-android-app.py`，使用本机NDK27、Android SDK35和JDK17构建。无需Gradle或网络依赖。输出为`build/android-app/RenderPassLab-debug.apk`，ABI为x86_64，适用于本次模拟器。调试签名仅保存在build目录，不进入公开源码包；应用没有网络和外部存储权限。

安装APK后打开“渲染Pass实验”，点击任一路径按钮即可。自动检查入口：

```powershell
python scripts/verify-android-app.py --serial emulator-5568 --record
```

此脚本检查目标为模拟器，安装APK并传入显式verify参数。Activity内部调用同一按钮的performClick，依次完成split和subpass。录像属于自动按钮场景，未冒充手动触屏操作。

## 实测

批次`android-app-20261031-225446`：Android15/API35，x86_64，Vulkan后端RTX4080。两条路径输出960×540，RGB逐像素一致。实际界面可见两种按钮、完成状态、设备名称及RenderPass数量。3.414秒屏幕录像包含启动与切换过程；H.264，1280×576。

APK SHA256：`343f1fc2047f1719d521a43161be5dd6701395c70a9e8cbf0ea9f8ebef433ef1`。

界面单帧GPU耗时用于诊断。录屏、资源初始化、CPU读回、Bitmap上传和显示都不在该GPU计时范围内；本次没有应用帧率或移动GPU加速结论。Windows六轮对照仍作为性能主证据。
