# Android 模拟器离屏渲染

## 已运行的范围

同一份 C++ 渲染器已通过 Android NDK 编译为 x86_64 ELF，并在 Android 15 模拟器内部通过 Vulkan 完成 split/subpass 网格场景。输出为 Android 进程写入的 PPM、逐帧 CSV 和运行信息，再经 adb 读回本机。

当前是 Android shell 离屏程序；APK、触屏界面和 UE 场景部署尚未实现。公开展示只将本批列为跨平台功能验证。模拟器把 Vulkan 调用交给宿主 RTX 4080，计时不能用于推断 Mali/Adreno 的带宽、功耗或性能。

## 环境与证据

| 项目 | 本轮实测 |
| --- | --- |
| Android Emulator | 37.2.13，WHPX |
| 系统镜像 | Android 15 / API 35，Google APIs x86_64 revision 9 |
| NDK / 编译目标 | 27.0.12077973 / x86_64 Android API 26 |
| 虚拟设备 | RenderPassLab_API35，端口5568，ro.kernel.qemu=1 |
| 运行时 Vulkan | 1.3.0，NVIDIA GeForce RTX 4080 |
| 图像 | 960×540，12,320三角形，RGBA16F + D32 |
| 对照结果 | split/subpass 最终RGB逐像素一致 |

批次 `artifacts/android-20261031-222531`；两条路径各预热60帧、采样60帧。本批用于检查加载、资源创建、渲染、同步及读回，未作为性能收益实验。`summary.json` 保存有限的设备属性、运行参数及可执行文件哈希。发布数据位于 `Evidence/Android`。

## 移植内容

- Vulkan加载器在Windows使用LoadLibrary，在Android使用dlopen/dlsym；图形资源、Shader、同步、时间戳与读回代码共用。
- `scripts/build-android.py` 使用NDK Clang生成PIE可执行文件，静态链接C++运行库；Shader固定部署在 `/data/local/tmp/renderpass-lab/shaders`。
- `scripts/run-android.py` 必须显式指定设备序列号，检查qemu标记与启动完成状态，然后部署并运行两条路径，保存原图和差分。
- Windows版本重新构建并与移植前网格图片比较，逐像素一致。

## 复现

需要官方SDK的platform-tools、emulator及 `system-images;android-35;google_apis;x86_64`，另需NDK、JDK。遵循 [Android命令行启动说明](https://developer.android.com/studio/run/emulator-commandline) 与 [硬件加速说明](https://developer.android.com/studio/run/emulator-acceleration)。本机复用mini-effect-sdk已有SDK与JDK，新增模拟器和镜像；未修改系统环境变量。AVD与日志保存在本工程 `artifacts/android-emulator`。

```powershell
# 先执行Windows构建，生成共用SPIR-V。
.\scripts\build.ps1
python scripts/build-android.py --ndk <Android-NDK目录>
# 使用已启动的独立模拟器，当前实验序列号为emulator-5568。
python scripts/run-android.py --serial emulator-5568 --sdk <Android-SDK目录>
```

本机启动参数为 `-avd RenderPassLab_API35 -port 5568 -no-window -no-audio -no-snapshot -gpu host -memory 4096 -cores 4`，进程局部 `ANDROID_AVD_HOME` 指向本工程的AVD目录。实验完成后仅关闭这个虚拟设备。

UE 5.8 当前安装中未找到 `Engine/Binaries/Android` 游戏运行库，已安装的平台代码不等于可打包的完整Android目标。该项继续单独处理。
