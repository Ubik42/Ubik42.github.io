# 渲染 Pass 与中间缓冲实验

原生 Vulkan 渲染实验，包含三条逐像素合成路径、同核 Bloom 分离卷积、GPU 测量和交互展示。直接打开 `exhibit/index.html` 可查看对照与16秒真实渲染视频。

## 当前实现

- 原生 C++17 / Vulkan 1.1，Windows 离屏运行，不依赖 UE 运行时。
- 代码生成场景：SDF 球体、金属展台、环形发光物、柱廊、地砖与软阴影。直接光使用 GGX BRDF，环境是解析近似，尚未实现预积分 IBL。
- 同一组 Shader 执行 HDR 场景、距离雾、调色和 tone mapping 四阶段。
- `split` 使用四个 Render Pass，阶段间保存中间图；`subpass` 使用一个 Render Pass 中的四个 Subpass，中间附件消费后丢弃。后处理均通过 input attachment 读取同位置像素，两条路径的着色逻辑一致。
- 三张 RGBA16F 中间图和一张 RGBA8 输出图；每个阶段完整覆盖画面。Subpass 路径声明 transient usage，当前分配 device-local 内存，尚未选择移动 GPU 的 lazily allocated memory。
- `inline` 将场景、雾、调色和 tone mapping 放入同一个 fragment shader，只分配最终输出图，只绘制一次；通过 pack/unpack 显式保留三个 half 精度边界。所有路径共用 `post.glsl` 的后处理公式。
- `bloom` 为9×9高亮卷积参考；`bloom-separable` 拆成水平与垂直9 tap，增加一张HDR中间图，保留原图到最终合成。使用 sampled image 和跨像素依赖，两者均为全分辨率。
- Vulkan GPU timestamp 记录渲染区间；原始 CSV、图像、设备与源码指纹保存在 `artifacts/`。
- 支持 RGBA32F / RGBA16F HDR 附件对照，记录逻辑字节数、驱动分配需求、像素差分与整链时间。当前场景中分配需求 135→67.5 MiB，最终最大通道差 1/255；具体条件见 `Docs/HDR附件格式对照.md`。
- 新增常规网格场景：12,320 三角形、顶点缓冲、D32 深度测试与 GGX 材质。split/subpass 六轮最终图像逐像素一致；逐轮耗时范围重叠，保留实际数值。源码、捕获与命令见 `Docs/常规几何路径.md`。
- Android NDK x86_64版本及交互APK已在Android15模拟器运行。Activity通过JNI调用同一套Vulkan代码，按钮切换split/subpass，输出实时读回为Bitmap；两条路径图片一致。提供自动按钮场景录像和源码。渲染后端为宿主RTX4080，单次计时仅作诊断。见 `Docs/Android模拟器部署.md`、`Docs/Android交互应用.md`。

## 构建和运行

依赖 Visual Studio 2022 C++、CMake、Vulkan 驱动、Vulkan-Headers 和 glslangValidator。CMake 默认指向本机 UE 5.8 的 Vulkan 头文件及 RenderDoc 附带编译器；换机可以通过 `VULKAN_HEADERS` 和 `GLSLANG` 指定路径。只读取这些依赖，没有复制引擎资产。

```powershell
.\scripts\build.ps1
.\build\Release\renderpass-lab.exe split artifacts\manual-split 1920 1080 120 40
.\build\Release\renderpass-lab.exe subpass artifacts\manual-subpass 1920 1080 120 40
python .\scripts\benchmark.py --width 1920 --height 1080
python .\scripts\benchmark.py --include-inline --samples 240 --warmup 120
.\build\Release\renderpass-lab.exe bloom artifacts\bloom-example 1920 1080 120 40
python scripts/benchmark-bloom.py
python scripts/render-sequence.py
```

Python 汇总脚本需要 Pillow。默认交错运行六批，每条路径三批，保存逐帧统计和像素误差。

指定 `--include-inline` 后使用三种轮换顺序，共九批。早期单样本场景 `artifacts/20261031-three-path` 的批次P50中位数为 split 0.62760 ms、subpass 0.62272 ms、inline 0.59656 ms。该历史结果不适用于当前四子像素采样画面；第一批 split 存在较高耗时，未采集 GPU 时钟解释波动。

split/subpass 图像逐像素一致。inline 最大通道差 1/255、平均绝对通道差约 0.051/255，未达到逐位相同；公式相同且保留 half 边界，仍需分析编译器运算与格式舍入的差别。Bloom 改变画面，不混入这组三路径等价对照。

## 三种执行结构

| 路径 | Render Pass | Draw | HDR 中间图 | 像素访问范围 |
| --- | --- | --- | --- | --- |
| split | 4 | 4 | 3 张，阶段间 STORE/LOAD | 当前像素 |
| subpass | 1 | 4 | 3 张，最后消费后 DONT_CARE | 当前像素 |
| inline | 1 | 1 | 0 张，Shader 内保留 half 边界 | 当前像素 |
| bloom 参考 | 4 | 4 | 3 张，最后一张可采样 | 当前像素及周围 12 像素范围 |

inline 消除了中间图和后三次绘制，但也把后处理放进场景 Shader 的执行路径。更复杂的真实材质可能增加寄存器压力和代码重复，需要另外比较。Bloom 的数据依赖跨越像素；当前通过独立阶段和全局依赖确保相邻像素可读，没有套用 framebuffer-local 的同步范围。

### RenderDoc 捕获

`scripts/capture.ps1 -Mode split` 或 `-Mode subpass` 保存一帧 `.rdc`。本机已用 RenderDoc 官方命令注册其 Vulkan 捕获层；脚本临时设置进程环境并恢复。捕获运行只核对调用结构，其耗时不参与性能比较。

导出及检查：

```powershell
renderdoccmd convert -f <capture.rdc> -o <capture.xml> -c xml
python scripts/inspect-capture.py <capture.xml>
```

2026-10-31 捕获已确认：split 有四次 Begin/EndRenderPass，subpass 有一次 Begin/EndRenderPass 和三次 NextSubpass，两者各绘制四次。该记录证明 API 提交结构；硬件是否合并仍取决于驱动。

inline 捕获另确认一次 Begin/EndRenderPass、一次 Draw、仅一张 RGBA8 输出附件；记录在 `artifacts/capture-inline-20261031-133420`。Bloom 捕获在 `artifacts/capture-bloom-20261031-133532`。

## 计量范围

运行 `python scripts/benchmark-bloom.py`。当前四子像素场景的六批桌面测量中，整链 GPU P50 中位数为3.02627→2.93016 ms，下降约3.18%，最大输出差1/255；代价为额外HDR中间图与一次Pass。旧单样本场景的10.5%结果保留在 [Bloom 分离卷积对照](Docs/Bloom分离卷积对照.md)，不与当前展示画面混用。

GPU 时间包含当前模式的完整场景与后处理链，排除 CPU 等待、资源初始化、图片读回和屏幕显示；按帧提交并等待，不代表实时应用帧率。逻辑附件存储量由分辨率和格式计算，不能当作实测 DRAM 流量。当前桌面 RTX 结果不能外推到手机。

`exhibit` 已提供交互对照、阶段示意与原生镜头视频。后续可扩展真实网格输入、附件格式和移动GPU设备验证。

## 技术来源

- Khronos Subpasses：https://docs.vulkan.org/samples/latest/samples/performance/subpasses/README.html
- Khronos render pass attachments：https://docs.vulkan.org/samples/latest/samples/performance/render_passes/README.html
- Android 模拟器图形加速：https://developer.android.com/studio/run/emulator-acceleration

本工程为独立实现；未复制上述示例的场景或源码，未使用逆向工程中的角色模型和贴图。
