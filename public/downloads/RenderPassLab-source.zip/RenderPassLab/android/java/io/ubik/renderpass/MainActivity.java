package io.ubik.renderpass;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static {System.loadLibrary("renderpass");}
    private static native String render(String directory,String mode);
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status,details;
    private Button split,subpass;
    private ImageView image;
    private boolean closed=false,busy=false,verify=false;
    private int verifyStep=0;
    private Bitmap displayed;

    private TextView text(String value,int size,int color) {
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);return v;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        verify=getIntent().getBooleanExtra("verify",false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,24,28,16);root.setBackgroundColor(Color.rgb(16,28,40));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(28+insets.getSystemWindowInsetLeft(),24+insets.getSystemWindowInsetTop(),28+insets.getSystemWindowInsetRight(),16+insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.addView(text("Vulkan 渲染 Pass 实验",25,Color.WHITE));
        root.addView(text("原创几何场景 · Android 应用内调用同一套 C++ 渲染路径",14,Color.rgb(166,195,211)));
        LinearLayout controls=new LinearLayout(this);
        split=new Button(this);split.setText("独立 Pass · 4 次");controls.addView(split);
        subpass=new Button(this);subpass.setText("Subpass 合并 · 1 次");controls.addView(subpass);
        status=text("选择路径，执行渲染",15,Color.rgb(126,220,233));controls.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(controls);
        image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription("Vulkan 实际渲染结果");root.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        details=text("输出 960 × 540 · GPU 渲染后读回为 Bitmap；切换时重新执行，无预存截图。",13,Color.rgb(190,208,222));root.addView(details);
        root.addView(text("模拟器使用宿主 GPU。单次耗时仅作诊断，性能对照见桌面六轮实验。",12,Color.rgb(239,195,130)));
        setContentView(root);
        split.setOnClickListener(v->start("split"));subpass.setOnClickListener(v->start("subpass"));
        if(verify)split.post(()->split.performClick());
    }
    private void start(String mode) {
        if(busy||closed)return;
        busy=true;split.setEnabled(false);subpass.setEnabled(false);status.setText("正在渲染 "+mode+"…");
        worker.execute(()->{
            Bitmap bitmap=null;
            try {
                File folder=getFilesDir(),shaderDir=new File(folder,"shaders");
                if(!shaderDir.isDirectory()&&!shaderDir.mkdirs())throw new IOException("无法创建Shader目录");
                for(String file:getAssets().list("shaders")) {
                    try(InputStream in=getAssets().open("shaders/"+file);OutputStream out=new FileOutputStream(new File(shaderDir,file))){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}
                }
                String result=render(folder.getAbsolutePath(),mode);
                bitmap=readPpm(new File(folder,mode+"/frame.ppm"));
                try(OutputStream out=new FileOutputStream(new File(folder,mode+"/frame.png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}
                JSONObject data=new JSONObject(result);
                String caption=data.getString("device")+" · "+data.getInt("render_passes")+" Render Pass · 4 Draw · 单帧GPU "+data.getDouble("gpu_single_frame_ms")+" ms";
                Bitmap ready=bitmap;
                runOnUiThread(()->finish(mode,ready,caption,null));
            } catch(Exception error) {
                if(bitmap!=null)bitmap.recycle();
                runOnUiThread(()->finish(mode,null,null,error.getMessage()));
            }
        });
    }
    private void finish(String mode,Bitmap ready,String caption,String error) {
        if(closed){if(ready!=null)ready.recycle();return;}
        busy=false;split.setEnabled(true);subpass.setEnabled(true);
        if(error!=null){status.setText("运行失败："+error);return;}
        Bitmap old=displayed;displayed=ready;image.setImageBitmap(ready);if(old!=null)old.recycle();
        details.setText(caption);status.setText(mode+" 渲染完成");
        if(verify&&verifyStep++==0)subpass.postDelayed(()->subpass.performClick(),1000);
        else if(verify){status.setText("自动交互检查完成：split → subpass");try{new File(getFilesDir(),"ui-verification-ok").createNewFile();}catch(IOException ignored){}}
    }
    private static String token(InputStream in)throws IOException {
        StringBuilder s=new StringBuilder();int c;
        do{c=in.read();if(c<0)throw new EOFException();}while(Character.isWhitespace(c));
        while(c>=0&&!Character.isWhitespace(c)){s.append((char)c);c=in.read();}return s.toString();
    }
    private static Bitmap readPpm(File file)throws IOException {
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){
            if(!token(in).equals("P6"))throw new IOException("PPM格式错误");
            int w=Integer.parseInt(token(in)),h=Integer.parseInt(token(in));
            if(w!=960||h!=540||!token(in).equals("255"))throw new IOException("输出尺寸错误");
            int[] colors=new int[w*h];for(int i=0;i<colors.length;i++){int r=in.read(),g=in.read(),b=in.read();if(b<0)throw new EOFException();colors[i]=Color.rgb(r,g,b);}
            return Bitmap.createBitmap(colors,w,h,Bitmap.Config.ARGB_8888);
        }
    }
    @Override public void onDestroy(){closed=true;worker.shutdown();if(displayed!=null)displayed.recycle();super.onDestroy();}
}
