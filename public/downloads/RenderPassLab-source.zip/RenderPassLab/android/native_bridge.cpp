#include <jni.h>
#include <mutex>
#include <string>
static std::string appShaderDir;
static std::mutex renderMutex;
#define SHADER_DIR appShaderDir
#define main renderpass_cli_main
#include "../src/main.cpp"
#undef main

extern "C" JNIEXPORT jstring JNICALL
Java_io_ubik_renderpass_MainActivity_render(JNIEnv* env,jclass,jstring folder,jstring selection) {
    std::lock_guard<std::mutex> lock(renderMutex);
    const char* f=env->GetStringUTFChars(folder,nullptr);
    const char* m=env->GetStringUTFChars(selection,nullptr);
    std::string base=f,mode=m;
    env->ReleaseStringUTFChars(folder,f);env->ReleaseStringUTFChars(selection,m);
    try {
        if(mode!="split"&&mode!="subpass")throw std::runtime_error("Unsupported path");
        appShaderDir=base+"/shaders";
        Lab lab;lab.meshScene=true;lab.fused=mode=="subpass";lab.width=960;lab.height=540;
        lab.init();lab.frame(false);double ms=lab.frame(true);
        std::filesystem::path out=base+"/"+mode;std::filesystem::create_directories(out);
        lab.save(out/"frame.ppm");
        std::string result="{\"mode\":\""+mode+"\",\"device\":\""+lab.properties.deviceName+
          "\",\"width\":960,\"height\":540,\"render_passes\":"+std::to_string(lab.passes.size())+
          ",\"draws\":4,\"gpu_single_frame_ms\":"+std::to_string(ms)+
          ",\"scope\":\"Interactive offscreen render and Bitmap display. One GPU sample; not a benchmark or mobile GPU claim.\"}";
        std::ofstream(out/"result.json")<<result;
        return env->NewStringUTF(result.c_str());
    } catch(const std::exception& error) {
        env->ThrowNew(env->FindClass("java/lang/RuntimeException"),error.what());
        return nullptr;
    }
}
