"""Build a small Android UI around the existing Vulkan renderer; SDK tools only."""
import hashlib,json,os,shutil,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sdk=Path(r'D:\3D\_tools\mini-effect-sdk\build\android-sdk')
jdk=Path(r'D:\3D\_tools\mini-effect-sdk\build\tools\jdk17\jdk-17.0.20.1+1')
bt=sdk/'build-tools/35.0.0';jar=sdk/'platforms/android-35/android.jar'
ndk=sdk/'ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64'
out=root/'build/android-app';out.mkdir(parents=True,exist_ok=True)
for d in ['classes','dex','assets/shaders','lib/x86_64']:(out/d).mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env['JAVA_HOME']=str(jdk);env['PATH']=str(jdk/'bin')+os.pathsep+env['PATH']
def run(cmd):subprocess.run([str(x) for x in cmd],check=True,env=env)
run([ndk/'bin/clang++.exe','--target=x86_64-none-linux-android26','--sysroot='+str(ndk/'sysroot'),'-std=c++17','-O2','-shared','-fPIC','-static-libstdc++','-DVK_NO_PROTOTYPES',root/'android/native_bridge.cpp','-ldl','-o',out/'lib/x86_64/librenderpass.so'])
sources=sorted((root/'android/java').rglob('*.java'))
run([jdk/'bin/javac.exe','-encoding','UTF-8','--release','8','-classpath',jar,'-d',out/'classes',*sources])
run([bt/'d8.bat','--lib',jar,'--min-api','26','--output',out/'dex',*sorted((out/'classes').rglob('*.class'))])
shaders=list((root/'build/shaders').glob('*.spv'))
if not shaders:raise RuntimeError('Build desktop SPIR-V shaders first')
for shader in shaders:shutil.copy2(shader,out/'assets/shaders'/shader.name)
run([bt/'aapt.exe','package','-f','-M',root/'android/AndroidManifest.xml','-I',jar,'-A',out/'assets','-F',out/'unsigned.apk'])
with zipfile.ZipFile(out/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
    z.write(out/'dex/classes.dex','classes.dex')
    z.write(out/'lib/x86_64/librenderpass.so','lib/x86_64/librenderpass.so')
run([bt/'zipalign.exe','-f','4',out/'unsigned.apk',out/'aligned.apk'])
key=out/'local-debug.keystore'
if not key.exists():run([jdk/'bin/keytool.exe','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-dname','CN=Local RenderPassLab Debug','-keyalg','RSA','-keysize','2048','-validity','3650'])
run([bt/'apksigner.bat','sign','--ks',key,'--ks-pass','pass:android','--key-pass','pass:android','--out',out/'RenderPassLab-debug.apk',out/'aligned.apk'])
run([bt/'apksigner.bat','verify',out/'RenderPassLab-debug.apk'])
record={'apk_sha256':hashlib.sha256((out/'RenderPassLab-debug.apk').read_bytes()).hexdigest(),'abi':'x86_64','min_api':26,'target_api':35,'scope':'Debug APK, interactive offscreen Vulkan rendering, no network permission; emulator testing only.'}
(out/'build.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2));print(out/'RenderPassLab-debug.apk')
