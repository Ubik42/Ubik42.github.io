"""Build the same offscreen renderer as an Android x86_64 executable."""
import argparse, hashlib, json, subprocess
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--ndk',type=Path,default=Path(r'D:\3D\_tools\mini-effect-sdk\build\android-sdk\ndk\27.0.12077973'))
args=p.parse_args()
root=Path(__file__).resolve().parents[1]
toolchain=args.ndk/'toolchains/llvm/prebuilt/windows-x86_64'
out=root/'build/android-x86_64';out.mkdir(parents=True,exist_ok=True)
command=[str(toolchain/'bin/clang++.exe'),'--target=x86_64-none-linux-android26',
    '--sysroot='+str(toolchain/'sysroot'),'-std=c++17','-O2','-fPIE','-pie','-static-libstdc++',
    '-DVK_NO_PROTOTYPES','-DSHADER_DIR="/data/local/tmp/renderpass-lab/shaders"',
    str(root/'src/main.cpp'),'-ldl','-o',str(out/'renderpass-lab')]
subprocess.run(command,check=True)
(out/'build.json').write_text(json.dumps({'abi':'x86_64','api':26,'ndk':args.ndk.name,
    'executable_sha256':hashlib.sha256((out/'renderpass-lab').read_bytes()).hexdigest(),
    'scope':'Android shell executable, not an APK or UE deployment'},indent=2),encoding='utf-8')
print(out/'renderpass-lab')
