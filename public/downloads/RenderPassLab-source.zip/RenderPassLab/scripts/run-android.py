"""Deploy the offscreen renderer to an explicitly selected Android emulator."""
import argparse, hashlib, json, subprocess
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

p=argparse.ArgumentParser()
p.add_argument('--serial',required=True)
p.add_argument('--sdk',type=Path,default=Path(r'D:\3D\_tools\mini-effect-sdk\build\android-sdk'))
args=p.parse_args()
root=Path(__file__).resolve().parents[1]
adb=args.sdk/'platform-tools/adb.exe'
def call(*parts):
    return subprocess.run([str(adb),'-s',args.serial,*parts],check=True,capture_output=True,text=True,encoding='utf-8',timeout=120).stdout.strip()
if call('shell','getprop','ro.kernel.qemu')!='1':
    raise SystemExit('This workflow targets an emulator; refusing a hardware device')
if call('shell','getprop','sys.boot_completed')!='1':
    raise SystemExit('Emulator has not completed boot')
out=root/'artifacts'/('android-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
out.mkdir(parents=True)
remote='/data/local/tmp/renderpass-lab'
call('shell','mkdir','-p',remote+'/shaders')
call('push',str(root/'build/android-x86_64/renderpass-lab'),remote+'/renderpass-lab')
for shader in (root/'build/shaders').glob('*.spv'):
    call('push',str(shader),remote+'/shaders/'+shader.name)
call('shell','chmod','755',remote+'/renderpass-lab')
runs=[]
for mode in ['split','subpass']:
    output=call('shell',remote+'/renderpass-lab',mode,remote+'/'+mode,'960','540','60','60','benchmark','rgba16f','mesh')
    print(output,flush=True)
    call('pull',remote+'/'+mode,str(out/mode))
    runs.append(json.loads((out/mode/'run.json').read_text()))
    Image.open(out/mode/'frame.ppm').save(out/(mode+'.png'))
diff=ImageChops.difference(Image.open(out/'split.png'),Image.open(out/'subpass.png'))
diff.point(lambda v:min(255,v*32)).save(out/'difference-x32.png')
summary={'scope':'Android emulator functional deployment; timings are not mobile GPU performance',
    'device':{key:call('shell','getprop',key) for key in ['ro.kernel.qemu','ro.product.model','ro.product.cpu.abi','ro.build.version.release','ro.build.version.sdk']},
    'runs':runs,'image_error_8bit':{'mean':ImageStat.Stat(diff).mean,'max':[v[1] for v in diff.getextrema()]},
    'executable_sha256':hashlib.sha256((root/'build/android-x86_64/renderpass-lab').read_bytes()).hexdigest()}
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(out)
print(json.dumps(summary,indent=2))
