"""Run the APK's explicit automatic button scenario on a selected emulator."""
import argparse,hashlib,json,subprocess,time
from pathlib import Path
from datetime import datetime
from PIL import Image,ImageChops,ImageStat
p=argparse.ArgumentParser();p.add_argument('--serial',required=True);p.add_argument('--record',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parents[1]
adb=Path(r'D:\3D\_tools\mini-effect-sdk\build\android-sdk\platform-tools\adb.exe')
def call(*parts,binary=False):
    r=subprocess.run([str(adb),'-s',args.serial,*parts],check=True,capture_output=True,timeout=90)
    return r.stdout if binary else r.stdout.decode('utf-8',errors='replace').strip()
if call('shell','getprop','ro.kernel.qemu')!='1':raise RuntimeError('Emulator required')
deadline=time.monotonic()+60
while call('shell','getprop','sys.boot_completed')!='1':
    if time.monotonic()>deadline:raise RuntimeError('Boot incomplete')
    time.sleep(1)
out=root/'artifacts'/('android-app-'+datetime.now().strftime('%Y%m%d-%H%M%S'));out.mkdir(parents=True)
apk=root/'build/android-app/RenderPassLab-debug.apk'
print(call('install','-r',str(apk)),flush=True)
package='io.ubik.renderpass'
call('shell','am','force-stop',package)
call('shell','run-as',package,'rm','-f','files/ui-verification-ok')
recorder=None
if args.record:
    recorder=subprocess.Popen([str(adb),'-s',args.serial,'shell','screenrecord','--time-limit','10','--size','1280x576','/sdcard/renderpass-app-demo.mp4'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    time.sleep(1)
print(call('shell','am','start','-n',package+'/.MainActivity','--ez','verify','true'),flush=True)
deadline=time.monotonic()+60
while True:
    check=subprocess.run([str(adb),'-s',args.serial,'shell','run-as',package,'test','-f','files/ui-verification-ok'],capture_output=True)
    if check.returncode==0:break
    if time.monotonic()>deadline:
        (out/'logcat.txt').write_text(call('logcat','-d','-t','500'),encoding='utf-8')
        raise RuntimeError('UI sequence did not complete; '+str(out))
    time.sleep(1)
records=[]
for mode in ['split','subpass']:
    for file in ['result.json','frame.png']:
        (out/(mode+'-'+file)).write_bytes(call('exec-out','run-as',package,'cat','files/'+mode+'/'+file,binary=True))
    records.append(json.loads((out/(mode+'-result.json')).read_text()))
(out/'app-screen.png').write_bytes(call('exec-out','screencap','-p',binary=True))
diff=ImageChops.difference(Image.open(out/'split-frame.png').convert('RGB'),Image.open(out/'subpass-frame.png').convert('RGB'))
record={'test':'App internal automatic button scenario split -> subpass; not manual touch recording','apk_sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'device':call('shell','getprop','ro.product.model'),'android':call('shell','getprop','ro.build.version.release'),'runs':records,'image_error_8bit':{'mean':ImageStat.Stat(diff).mean,'max':[v[1] for v in diff.getextrema()]}}
(out/'summary.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
if recorder:
    recorder.communicate(timeout=20)
    if recorder.returncode:raise RuntimeError('Screen recording failed')
    call('pull','/sdcard/renderpass-app-demo.mp4',str(out/'automatic-button-demo.mp4'))
print(json.dumps(record,ensure_ascii=False,indent=2));print(out)
