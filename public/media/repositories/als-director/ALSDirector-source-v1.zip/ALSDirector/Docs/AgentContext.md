# 动作请求的上下文与回传记录

新增 `Tools/agent_session.py`，把当前指令、实时角色状态和最近三次执行结果打包给模型。上下文带内容摘要，回复关联会话及请求编号；SQLite 记录准备、提交和观察结果。

2026-11-01 的两次实际请求均由当前 Codex 对话生成计划，再通过本地桥接传入 UE。

1. “保持站姿，抱着箱子慢慢走到红色目标，目光看向门口。”执行后角色进入 Box Overlay，以步行速度向红柱移动。
2. “继续去原来的目标，保持抱箱，改为蹲着走。”生成上下文时角色仍在移动，速度约 175 cm/s，剩余一步；提交回复时角色已到达。执行器应用蹲姿，保持抱箱和注视，不重新启动已经结束的移动。

这次运行直接展示了异步控制中的状态变化：模型收到的场景和回复到达时的场景可能不同。记录同时保留准备与执行后的状态，便于判断修改实际发生的时机。

![回传后角色在红柱附近保持抱箱并蹲伏](Media/agent-context.png)

## 使用

先运行 UE 场景并提交自然语言指令，再执行：

```powershell
python Tools/agent_session.py prepare --context context.json
# 将上下文交给当前模型，生成包含 plan、reason、source 的 answer.json
python Tools/agent_session.py submit --context context.json --answer answer.json
python Tools/agent_session.py observe --context context.json
```

`ALS_DIRECTOR_BRIDGE` 可指定桥接目录。模块校验会话、请求、上下文摘要和有限动作集合，并在发送前记录提交状态。独立模型 API 调用仍由后续接入层负责。
