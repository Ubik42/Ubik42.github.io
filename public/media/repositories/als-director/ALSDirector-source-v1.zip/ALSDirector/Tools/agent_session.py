"""Prepare current game context, submit a correlated model plan, and record its outcome."""
import argparse
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from bridge import ROOT, read, write

FIELDS = ['session_id', 'pending_request', 'status', 'gait', 'style', 'stance', 'move_target',
          'look_at', 'moving', 'phase', 'accepted_count', 'rejected_count', 'remaining_steps',
          'world_seconds', 'speed', 'x', 'y', 'z', 'actual_stance', 'actual_gait', 'overlay', 'animation_loaded']
ENUMS = {'action': ['move_to', 'adjust', 'stop'], 'target': ['blue_box', 'red_target', 'door'],
         'look_at': ['blue_box', 'red_target', 'door', 'none'], 'gait': ['walk', 'run', 'sprint'],
         'style': ['normal', 'alert', 'carrying', 'injured'], 'stance': ['stand', 'crouch']}


def fresh():
    state = read('state.json')
    if time.time() - (ROOT / 'state.json').stat().st_mtime > 5 or not state.get('running'):
        raise RuntimeError('A running game with fresh state is required')
    return {key: state.get(key) for key in FIELDS}


def store():
    db = sqlite3.connect(ROOT / 'agent-sessions.sqlite')
    db.execute('CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, time REAL, session TEXT, request TEXT, kind TEXT, payload TEXT)')
    return db


def event(db, context, kind, payload):
    with db:
        db.execute('INSERT INTO events(time,session,request,kind,payload) VALUES(?,?,?,?,?)',
                   (time.time(), context['session_id'], context['request_id'], kind, json.dumps(payload, ensure_ascii=False)))


def prepare(db):
    state = fresh()
    request = read('request.json')
    after = fresh()
    if request['session_id'] != state['session_id'] or request['request_id'] != state['pending_request']:
        raise RuntimeError('No matching pending request')
    if (after['session_id'], after['pending_request']) != (state['session_id'], state['pending_request']):
        raise RuntimeError('Request changed during observation; prepare again')
    history = [json.loads(row[0]) for row in db.execute(
        "SELECT payload FROM events WHERE session=? AND kind='observed' ORDER BY id DESC LIMIT 3", (state['session_id'],))]
    context = {'version': 1, 'session_id': state['session_id'], 'request_id': request['request_id'],
               'request': request, 'observed_at': time.time(), 'state': after, 'recent_outcomes': history,
               'available_values': ENUMS, 'rules': [
                   'adjust preserves the current route; use it for an in-motion performance change.',
                   'Only move_to waits for arrival. The runtime uses straight-line movement, without navigation.',
                   'stop cancels the route. Unknown or out-of-range plans are rejected by the game.',
                   'Use only supported existing ALS overlays; this interface does not generate animations.']}
    digest = hashlib.sha256(json.dumps(context, sort_keys=True).encode()).hexdigest()
    context['context_hash'] = digest
    event(db, context, 'prepared', context)
    return context


def submit(db, context, answer):
    state = fresh()
    if (state['session_id'], state['pending_request']) != (context['session_id'], context['request_id']):
        raise RuntimeError('Request was cancelled or replaced; response was not sent')
    if set(answer) != {'plan', 'reason', 'source'} or answer['source'] not in ('codex', 'test', 'replay'):
        raise ValueError('Answer requires plan, reason and explicit source')
    steps = answer['plan'].get('steps')
    if set(answer['plan']) != {'steps'} or not isinstance(steps, list) or not 1 <= len(steps) <= 8:
        raise ValueError('Plan requires 1–8 steps')
    for step in steps:
        if not isinstance(step, dict) or step.get('action') not in ENUMS['action']:
            raise ValueError('Invalid action')
        if any(key not in ENUMS or value not in ENUMS[key] for key, value in step.items()):
            raise ValueError('Unsupported parameter')
        if step['action'] == 'move_to' and 'target' not in step:
            raise ValueError('move_to requires target')
        if step['action'] != 'move_to' and 'target' in step:
            raise ValueError('Only move_to can specify target')
    if any(s['action'] in ('adjust', 'stop') for s in steps[:-1]):
        raise ValueError('adjust/stop must be the last step')
    original = dict(context)
    original.pop('context_hash')
    if hashlib.sha256(json.dumps(original, sort_keys=True).encode()).hexdigest() != context['context_hash']:
        raise ValueError('Prepared context was modified')
    db.execute('BEGIN IMMEDIATE')
    if not db.execute("SELECT 1 FROM events WHERE session=? AND request=? AND kind='prepared' AND payload=?",
                      (context['session_id'], context['request_id'], json.dumps(context, ensure_ascii=False))).fetchone():
        raise ValueError('Context was not prepared by this session')
    if db.execute("SELECT 1 FROM events WHERE session=? AND request=? AND kind='submitted'",
                  (context['session_id'], context['request_id'])).fetchone():
        raise RuntimeError('Already submitted; inspect actual game outcome before resubmission')
    # Persist intent before transport: a crash must not silently trigger another send.
    event(db, context, 'submitted', {'answer': answer, 'state_before': state, 'context_hash': context['context_hash']})
    write(context['request_id'] + '.response.json', {'session_id': context['session_id'],
          'request_id': context['request_id'], 'plan': answer['plan'], 'source': answer['source']})
    changed = {key: {'observed': context['state'].get(key), 'at_submit': state.get(key)}
               for key in ['moving', 'move_target', 'stance', 'style', 'remaining_steps']
               if context['state'].get(key) != state.get(key)}
    return {'submitted': True, 'request_id': context['request_id'], 'state_changes_while_planning': changed}


def observe(db, context):
    state = fresh()
    if state['session_id'] != context['session_id']:
        raise RuntimeError('Game session changed')
    result = {'request_id': context['request_id'], 'before': context['state'], 'after': state,
              'accepted_delta': state['accepted_count'] - context['state']['accepted_count'],
              'rejected_delta': state['rejected_count'] - context['state']['rejected_count'],
              'still_pending': state['pending_request'] == context['request_id'],
              'scope': 'Observed current game state; counters may include later requests in the same session.'}
    event(db, context, 'observed', result)
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['prepare', 'submit', 'observe'])
    p.add_argument('--context', type=Path, required=True)
    p.add_argument('--answer', type=Path)
    a = p.parse_args()
    db = store()
    if a.command == 'prepare':
        result = prepare(db)
        a.context.parent.mkdir(parents=True, exist_ok=True)
        a.context.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        context = json.loads(a.context.read_text(encoding='utf-8'))
        result = submit(db, context, json.loads(a.answer.read_text(encoding='utf-8'))) if a.command == 'submit' else observe(db, context)
    print(json.dumps(result, ensure_ascii=False, indent=2))
