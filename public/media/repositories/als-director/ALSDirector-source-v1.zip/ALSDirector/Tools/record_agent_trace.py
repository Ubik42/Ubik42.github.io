"""Record real host state transitions; never submit plans or change the game."""
import argparse
import json
import time
from pathlib import Path
from agent_session import fresh
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("--seconds",type=float,default=60)
p.add_argument("--output",type=Path,required=True)
a=p.parse_args()
if not 0 < a.seconds <= 300: raise ValueError("Duration must be within 300 seconds")
a.output.parent.mkdir(parents=True,exist_ok=True)
started=time.monotonic()
result={"source":"Live UE state observation; no plans emitted", "started_at_unix":time.time(), "samples":[], "status":"recording"}
try:
    while time.monotonic()-started < a.seconds:
        state=fresh()
        if result["samples"] and state["session_id"] != result["samples"][0]["state"]["session_id"]:
            raise RuntimeError("Host session changed")
        result["samples"].append({"elapsed_seconds":round(time.monotonic()-started,4),"observed_at_unix":time.time(),"state":state})
        time.sleep(.1)
    result["status"]="completed"
except Exception as error:
    result["status"]="interrupted";result["error"]=str(error)
    raise
finally:
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"status":result["status"],"samples":len(result["samples"]),"output":str(a.output)}))
