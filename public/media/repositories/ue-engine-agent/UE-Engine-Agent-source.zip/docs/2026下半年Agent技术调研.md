# UE Agent：2026年下半年技术调研与实施取舍

调研日期：2026-11-01（America/Denver）。截至该日可公开核验的资料；论文结论、厂商说明、社区经验和本工程决策分别记录。检索“最新”后回到原始来源，不用搜索排名代替技术判断。

## 1. 结论与项目定位

值得落地的中心是模型与实际软件之间的运行系统：选上下文、发现工具、保存任务状态、处理外部副作用、获取真实反馈。UE已有大量工具，作品深度来自在一个具体任务中合理选择这些工具，并处理编辑器的异步编译、资产状态和结果检查。

新工程 UE-Engine-Agent 面向跨模块引擎工作流。Unreal-Toolsmith已有中文需求到C++/Slate插件Patch与构建能力；ArtFlow已有生成结果回流UE的成熟事件系统；Levelwright拥有设计知识与确定性灰盒；ALSDirector负责现有角色表演。新工程负责当前工程观察、按需工具发现、跨模块步骤、失败后恢复和结果解释，与四者通过接口集成。

## 2. 下半年可核验的新材料

| 时间与来源 | 原始材料支持的判断 | 对本工程的意义 |
| --- | --- | --- |
| 2026-08-20，[Epic UEFN MCP发布](https://www.fortnite.com/news/unreal-mcp-is-now-available-in-uefn) | UEFN工具沿用UE5.8 Toolset Registry；原生工具进入正式引擎产品工作流 | 接官方MCP，避免另造一套远程编辑器协议 |
| 2026-09-26，[Beyond the Model](https://arxiv.org/abs/2609.32459) | 比较工具注册、压缩、显式规划、子代理与延迟Skill；效果依赖模型与任务，压缩和通用子代理可能损害部分任务 | 先用单协调循环，按任务加载schema；保留原始结果，不让摘要覆盖真实状态。论文的百分比不迁移为本作品收益 |
| 2026-10-26，[Toward Evidence-Based Agentic Software Engineering](https://arxiv.org/abs/2610.35348) | 指出论文常缺运行系统版本与执行轨迹，模型与harness同时改变会混淆因果；该稿为在审预印本 | 固定任务、记录模型/引擎/工具版本与结果；只在有对比问题时做小规模消融 |
| 2026-10-28，[Microsoft Copilot harness](https://blogs.microsoft.com/blog/2026/10/28/introducing-the-microsoft-copilot-harness-unlocking-the-potential-of-truly-multi-model-agentic-work/) | 官方发布多模型harness与SDK路线，统一指令、工具、上下文和执行环境 | 模型Provider应可替换，业务状态保持模型外部；“best-in-class”等厂商表述不作为独立评测结论 |
| 2026.10资料截点，[Agent Harness综述](https://github.com/Gloriaameng/Awesome-Agent-Harness) | 汇集执行、工具、上下文、状态、生命周期与评估；仓库v4、DOI v3、v5尚在修订 | 用作查找原始资料的索引，不能把收录等同成熟度 |

更早基础：[Anthropic Managed Agents](https://www.anthropic.com/research/managed-agents)（2026-04-08）明确区分session、harness和sandbox；[Context engineering cookbook](https://platform.claude.com/cookbook/tool-use-context-engineering-context-engineering-tools)（2026-03-20）讨论记忆与工具结果清理。它们是基础来源，不标为下半年新发明。

## 3. GitHub与本地源码对照

| 实现 | 查看的内容 | 采用与限制 |
| --- | --- | --- |
| [Deep Agents](https://github.com/langchain-ai/deepagents) / [Changelog](https://github.com/langchain-ai/deepagents/blob/main/libs/deepagents/CHANGELOG.md) | 长任务harness、上下文/子代理、持续版本维护；记录存在0.7.5（2026-08-06） | 后续可作为模型循环候选。首轮不引入整套运行时，避免与UE执行账本形成两个状态源 |
| [UEBox](https://github.com/ueboxai/uebox) | 本地有85556add快照；工具与UE插件分离，材质/Blueprint整图操作、焦点上下文、PCG/动画测量 | 借鉴语义对象与批量操作。工具实现需按目标UE版本核对；不声称所有工具已在本机启用 |
| [VibeUE](https://github.com/kevinpbuckley/VibeUE/tree/5-8) | 面向UE5.8官方MCP扩展；本地已有参考仓 | 动画/图工具的补充来源，官方覆盖不足才引入对应模块 |
| 官方EditorToolset | 本机MaterialInstanceTools、SceneTools、ActorTools、ProgrammaticToolset源码 | 直接使用已发布工具schema；标量修改后独立读取，以规避底层setter返回值与实际状态不一致 |
| 本机AnimBlueprintToolset | 已有真实UE5.8状态机写入/编译/保存记录 | 第二条动画工作流候选；不复制插件，不重建桥接层 |

## 4. Reddit讨论与可靠性

[长任务编排讨论](https://www.reddit.com/r/aiagents/comments/1x8he64/what_you_guys_actually_using_to_orchestrate_ai/)提出上下文漂移、多个角色声称完成但缺少检查、恢复时停滞等问题。[软件工程基础讨论](https://www.reddit.com/r/aiagents/comments/1x6jzc5/is_anyone_else_noticing_that_people_building_ai/)强调状态结构和输入验证。它们属于开发者自述，不能证明框架优劣。搜索索引显示10月日期，但正文相对时间与索引不一致，本报告不把帖子日期作为精确的时间线证据。

社区中“长记忆”“多Agent”出现频率很高，但本项目首先需要回答：要记住哪个工程、哪个资产、哪次执行，以及这个状态何时过期。无范围的聊天历史不能替代引擎读回。

## 5. 技术落地设计

### 按需工具发现

UE5.8默认只公开list_toolsets、describe_toolset、call_tool。先用简短目录定位功能域，再读取相关schema，避免一次注入所有工具。本地索引保存引擎版本及来源；连接新宿主后重新发现。官方文档明确工具在Game Thread串行执行，因此编辑器写入保持串行。

来源：[Unreal MCP官方文档](https://dev.epicgames.com/documentation/unreal-engine/unreal-mcp-in-unreal-editor)。本机已核对默认三个入口及Toolsmith历史发现结果。

### 上下文与检索

分四层：任务目标；当前选中对象/地图与可见状态；按需工具schema；可检索知识证据。返回内容较长时保存原件并只向模型提供路径、摘要和内容哈希。最初使用本地词法检索和来源卡，待出现实际召回缺口再加入向量库。

源文档和工具结果都是数据，不允许其中的自然语言改写执行范围。知识卡记录版本、出处与适用条件。执行前刷新引擎事实，避免过期记忆驱动写入。

### 持久任务与恢复

SQLite保存run和step。每步记录请求、开始、结果或不确定状态，计划用哈希固定。断线后的写操作进入uncertain，重新读回再决定继续；已完成步骤恢复时跳过。暂不承诺exactly-once，因为HTTP与编辑器资产保存之间没有分布式事务。

模型负责提出下一步，执行器负责传递和记录，UE读回负责判断资产事实。执行允许范围限定为本工程隔离宿主。事务Undo只用于当前编辑器会话；跨进程恢复依赖资产副本与持久记录。

### 视觉反馈

场景对象、参数、编译结果与截图共同组成结果。首轮材质任务使用参数读取+同机位截图；第二轮动画任务加入真实状态机与角色观察。截图由引擎产生，不让模型把“预期画面”写成实际结果。

### 测试取舍

先完成真实宿主纵切，再测一个断线/恢复场景和关键输入范围。每条新任务保存少量明确案例，不建立上百条Mock门禁。只有提出成功率/成本收益时，才冻结任务集并比较相同模型与不同运行策略。

## 6. 近期实施顺序

1. 新Agent：官方MCP连接、按需schema、SQLite执行记录、真实材质调整及图像。
2. 新Agent：模型循环与工程检索，第二条动画/场景任务及失败恢复。
3. ALSDirector：让动作计划利用当前角色反馈，展示执行中修正，不以固定夹具代替模型决策。
4. Levelwright：把现有知识卡与真实路线反馈接入Agent修订，保留设计理由与实际变更。
5. ArtFlow：该仓M61活动且有未提交工作，先只读核对；选择无冲突的集成接口，不覆盖现场。
6. 网站：新项目中文入口、实际截图与工作流短片；同步旧项目已完成能力。

本报告给出工程决策，不宣称任何单一中间件是所有任务的SOTA。使用的外部技术与本人实现分别注明；尚未运行的功能在进度中标记待实现。


## 2026-11-01：独立模型与视觉反馈落地

官方 DeepSeek 当前模型接口列出 deepseek-flash 与 deepseek-v4-pro；本机实际 /models 查询一致。本项目选择支持图像输入和工具调用的 Flash，使用非思考模式，保存输出动作和用量。13 轮实际调用完成材质检查、编辑、保存与视口观察。具体模型响应按运行记录保留，避免将滚动模型别名永久等同于固定版本。

工具目录按纯文本读取，目标工具集按 JSON Schema 读取。模型只看到已实现能力的参数定义。截图以本地摘要引用保存，请求模型时转换为图像输入。首轮解析错误表明：工具协议一致不代表所有工具内容都是 JSON，接入层必须区分目录文本与结构化结果。

来源：[工具调用](https://api-docs.deepseek.com/guides/tool_calls/)、[Chat API](https://api-docs.deepseek.com/api/create-chat-completion/)、[模型说明](https://api-docs.deepseek.com/quick_start/pricing/)。


## 增量核验：资料版本与具体宿主（2026-11-01）

MCP 官方架构页现跳转至 2026-07-28，描述 server/discover 并标出 sampling 弃用。当前 UE 接入使用实际验证过的 initialize 流程。本工程将规范版本与宿主实现分开记录，不将官网更新直接等同于本机支持。

知识检索已经落地为 6 张带源码/内容摘要的资料卡，词项搜索后按需读全文。它解决小范围工程操作说明的可追溯引用；尚不是全量引擎文档语义检索。实际材质任务仍因缺少资产定位工具发生路径尝试，说明文档检索需要配合足够的宿主观察能力，不能替代对象发现。

来源：https://modelcontextprotocol.io/docs/2026-07-28/learn/architecture 与 https://dev.epicgames.com/documentation/en-us/unreal-engine/unreal-mcp-in-unreal-editor 。
