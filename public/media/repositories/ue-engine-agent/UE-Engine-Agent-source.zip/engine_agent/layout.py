"""Scene-specific invariant checks for the original demonstration workshop."""
import json
import math
from .mcp import text
from .runtime import ACTOR,SCENE,PREFIX

def value(client,toolset,tool,args):
    return json.loads(text(client.call(toolset,tool,args)))['returnValue']

def snapshot(folder,client):
    path=folder/'layout-baseline.json'
    if path.exists(): raise ValueError('Baseline exists; use a fresh execution folder for another task')
    level=value(client,SCENE,'get_current_level',{})
    if not level.startswith(PREFIX): raise ValueError('Not in EngineAgent work area')
    actors=value(client,SCENE,'find_actors',{'name':'','tag':'','collision_channels':[]})
    records=[]
    for actor in actors:
        label=value(client,ACTOR,'get_label',{'actor':actor})
        if label.startswith(('Target ','Pedestal ','Trim ')):
            records.append({'actor':actor,'label':label,'before':value(client,ACTOR,'get_actor_transform',{'actor':actor})})
    pairs=[]
    for target in [r for r in records if r['label'].startswith('Target ')]:
        for role in ('Pedestal ','Trim '):
            candidates=[r for r in records if r['label'].startswith(role) and all(math.isclose(r['before']['location'][k],target['before']['location'][k],abs_tol=.001) for k in ('x','y'))]
            if len(candidates)!=1: raise ValueError('Initial spatial pairing is ambiguous')
            pairs.append({'target':target['actor'],'base':candidates[0]['actor']})
    if not pairs: raise ValueError('No workshop pairs found')
    baseline={'level':level,'records':records,'pairs':pairs}
    path.write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8')
    return baseline

def verify(folder,client):
    baseline=json.loads((folder/'layout-baseline.json').read_text(encoding='utf-8'))
    if value(client,SCENE,'get_current_level',{}).split('.',1)[0] != baseline['level'].split('.',1)[0]: raise ValueError('Current map differs from baseline')
    records=[];lookup={}
    for row in baseline['records']:
        current=value(client,ACTOR,'get_actor_transform',{'actor':row['actor']})
        r={**row,'current':current};records.append(r);lookup[row['actor']['refPath']]=r
    checks=[]
    for pair in baseline['pairs']:
        target=lookup[pair['target']['refPath']];base=lookup[pair['base']['refPath']]
        checks.append({'target':target['label'],'original_support':base['label'],'passed':all(math.isclose(target['current']['location'][k],base['current']['location'][k],abs_tol=.001) for k in ('x','y'))})
    for row in records:
        before,current=row['before'],row['current']
        checks.append({'actor':row['label'],'rule':'height_rotation_scale_preserved','passed':math.isclose(before['location']['z'],current['location']['z'],abs_tol=.001) and before['rotation']==current['rotation'] and before['scale']==current['scale']})
    return {'passed':all(c['passed'] for c in checks),'checks':checks,'records':records,'scope':'Original workshop pairing and unchanged Z/rotation/scale; not a general scene quality judgment'}
