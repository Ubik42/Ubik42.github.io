"""Independent model transport. Credentials stay in environment variables."""
import base64
import copy
import json
import os
from pathlib import Path
import urllib.request


class DeepSeek:
    def __init__(self, model='deepseek-flash', artifact_root=None):
        self.model = model
        self.root = Path(artifact_root).resolve()

    def complete(self, messages, tools):
        expanded = copy.deepcopy(messages)
        for message in expanded:
            if isinstance(message.get('content'), list):
                for part in message['content']:
                    if part.get('type') == 'ue_image':
                        path = (self.root / part['artifact']).resolve()
                        if path.parent != self.root or path.suffix != '.png':
                            raise ValueError('Image is outside current execution artifacts')
                        data = base64.b64encode(path.read_bytes()).decode()
                        part.clear()
                        part.update(type='image_url', image_url={'url': 'data:image/png;base64,'+data, 'detail':'high'})
        key = os.environ.get('DEEPSEEK_API_KEY')
        if not key:
            raise RuntimeError('Set DEEPSEEK_API_KEY for independent model execution')
        payload = {'model':self.model, 'messages':expanded, 'tools':tools,
                   'thinking':{'type':'disabled'}, 'max_tokens':3000, 'temperature':0.2}
        request = urllib.request.Request('https://api.deepseek.com/chat/completions',
                 json.dumps(payload).encode(), {'Content-Type':'application/json', 'Authorization':'Bearer '+key})
        with urllib.request.urlopen(request, timeout=120) as response:
            result = json.load(response)
        choice = result['choices'][0]
        if choice['finish_reason'] not in ('stop','tool_calls'):
            raise RuntimeError('Model output incomplete: '+choice['finish_reason'])
        message = {k:v for k,v in choice['message'].items() if k in ('role','content','tool_calls')}
        return message, {'model':result.get('model'), 'response_id':result.get('id'),
                         'usage':result.get('usage',{}), 'finish_reason':choice['finish_reason']}
