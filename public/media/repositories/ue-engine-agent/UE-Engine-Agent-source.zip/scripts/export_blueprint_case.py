"""Export the actual model plan and runtime trace; never synthesize success."""
import json
import sqlite3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'docs/evidence/blueprint-platform'
out.mkdir(parents=True,exist_ok=True)
db=sqlite3.connect(ROOT/'artifacts/blueprint-platform-001/runs.sqlite')
session=db.execute('SELECT id,intent,model,messages,turn,status FROM agent_sessions').fetchone()
record=dict(zip(('id','intent','model','messages','turns','status'),session))
record['messages']=json.loads(record['messages'])
record['model_calls']=[{'turn':t,'metadata':json.loads(m),'message':json.loads(s)} for t,m,s in db.execute('SELECT turn,metadata,message FROM model_calls ORDER BY turn')]
(out/'agent.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
events=[{'time':t,'run':r,'step':s,'kind':k,'detail':json.loads(d)} for t,r,s,k,d in db.execute('SELECT time,run,step,kind,detail FROM events ORDER BY seq')]
(out/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf-8')
writes=[x for x in events if x['kind']=='started' and x['detail']['tool']=='write_graph_dsl']
if writes:
    step=writes[-1]['detail']
    (out/'generated-graph.lisp').write_text(step['arguments']['code']+'\n',encoding='utf-8')
db.close()
runtime=ROOT/'artifacts/platform-runtime/readback.json'
if runtime.exists():
    (out/'runtime.json').write_bytes(runtime.read_bytes())
print(out)
