const $=id=>document.getElementById(id);let selected='',token='',busy=false,current=null,chosenImage='',signature='';
const titles={'layout-support-001':'场景组合检查与顶盘修正','layout-final-001':'布局读回与视口检查','layout-verified-001':'根据检查结果修正底座','layout-pairs-001':'原始配对关系复核','layout-001':'三组展品的三角形布局','ceramic-002':'冷蓝陶瓷材质调整','ceramic-001':'工具发现 · 调试记录'};
const taskTitle=t=>titles[t.session]||t.intent.split(/[。\n]/)[0].slice(0,32);
const statusName={model_completed:'模型已完成',running:'正在执行',active:'可继续',interrupted:'可继续',needs_readback:'等待读回',validation_blocked:'参数待修正',turn_limit:'本轮结束',failed:'执行中断'};
const names={discover:'发现编辑器工具',describe:'读取工具定义',execute:'执行引擎步骤',verify_scene:'检查场景组合',get_actor_transform:'读取对象变换',set_actor_transform:'调整对象变换',get_label:'读取对象标签',get_actor_bounds:'读取包围盒',find_actors:'查找场景对象',get_current_level:'读取当前关卡',set_scalar_parameter:'修改材质标量',set_vector_parameter:'修改材质颜色',get_scalar_parameter:'读回材质标量',get_vector_parameter:'读回材质颜色',list_parameters:'读取材质参数',save_assets:'保存资产',CaptureViewport:'捕获视口'};
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function parse(s){try{return JSON.parse(s)}catch{return {text:s}}}
async function api(url,body){const r=await fetch(url,body?{method:'POST',headers:{'Content-Type':'application/json','X-Workbench-Token':token},body:JSON.stringify(body)}:{});const d=await r.json();if(!r.ok)throw Error(d.error||'请求失败');return d}
function image(name){chosenImage=name;const exists=Boolean(name);$('viewport').hidden=!exists;$('emptyImage').hidden=exists;if(exists)$('viewport').src=`/api/image?id=${selected}&name=${name}`;$('captureInfo').textContent=exists?'已保存的真实画面':'尚未捕获';document.querySelectorAll('[data-image]').forEach(b=>b.classList.toggle('active',b.dataset.image===name))}
function render(data){current=data;const fingerprint=JSON.stringify([data.id,data.status,data.turns,data.events.length,data.messages.length,data.error]);if(fingerprint===signature)return;signature=fingerprint;
$('title').textContent=taskTitle(data);$('intent').textContent=data.intent;$('status').textContent=statusName[data.status]||data.status;$('model').textContent=data.model;$('turns').textContent=data.turns;
$('steps').textContent=data.events.filter(x=>x.kind==='completed').length;$('tokens').textContent=data.calls.reduce((n,c)=>n+(c.usage?.total_tokens||0),0).toLocaleString();
let rows=[],checks=null;for(const m of data.messages){if(m.role!=='tool')continue;const d=parse(m.content);if(d.checks)checks=d;
if(d.query&&d.results){rows.push({title:'检索工程资料',body:d.results.map(x=>x.title).join('；')||'没有找到匹配资料',raw:d,kind:'done'});}
else if(d.content_sha256&&d.content){rows.push({title:'读取资料：'+d.title,body:d.sources.some(x=>x.local_status==='changed_or_unavailable')?'部分来源已变化，需重新核对':`已记录 ${d.sources.length} 个来源 · ${d.verified_at}`,raw:d,kind:d.sources.some(x=>x.local_status==='changed_or_unavailable')?'failure':'done'});}
else if(d.steps){for(const s of d.steps){const ev=data.events.find(e=>e.step===s.id&&e.run===d.run_id&&e.kind==='started');const req=ev?.detail;rows.push({title:names[req?.tool]||req?.tool||s.id,body:s.state==='failed'?'只读调用失败，结果已交回模型修正':req?.reason||'已返回引擎结果',raw:s,kind:s.state==='failed'?'failure':'done'});}}
else if(d.checks){rows.push({title:d.passed?'场景检查通过':'发现布局问题',body:d.checks.filter(c=>!c.passed).map(c=>`${c.target||c.actor} → ${c.original_support||c.rule}`).join('；')||`${d.checks.length} 项检查通过`,raw:d,kind:d.passed?'done':'failure'});}
else if(d.available===false)rows.push({title:'当前检查未启用',body:d.reason,raw:d,kind:'failure'});
else if(d.validation_error)rows.push({title:'参数校验未通过',body:d.validation_error.slice(0,200),raw:d,kind:'failure'});
else if(d.implemented_tools)rows.push({title:'发现可用编辑器工具',body:`${d.implemented_tools.length} 项已接入能力`,raw:d,kind:'done'});
else if(d.tools)rows.push({title:'读取工具参数定义',body:`${d.tools.length} 项工具 · ${d.name?.split('.').pop()||''}`,raw:d,kind:'done'});}
$('checks').textContent=checks?`${checks.checks.filter(c=>c.passed).length}/${checks.checks.length}`:'—';
$('timeline').innerHTML=rows.map((r,i)=>`<article class="event ${r.kind}"><span class="number">${String(i+1).padStart(2,'0')}</span><h3>${esc(r.title)}</h3><p>${esc(r.body)}</p><details><summary>查看原始结果</summary><pre>${esc(JSON.stringify(r.raw,null,2))}</pre></details></article>`).join('')||'<p>等待模型返回第一步操作…</p>';
if(data.status==='running')$('timeline').scrollTop=$('timeline').scrollHeight;
$('captures').innerHTML=data.captures.map((n,i)=>`<button type="button" data-image="${esc(n)}">画面 ${i+1}</button>`).join('');if(!data.captures.includes(chosenImage))chosenImage=data.captures.at(-1)||'';image(chosenImage);
const answer=[...data.messages].reverse().find(m=>m.role==='assistant'&&m.content&&!m.tool_calls?.length);$('answerBox').hidden=!answer;$('answer').textContent=answer?.content||'';
$('error').hidden=!data.error;$('error').textContent=/10061/.test(data.error)?'无法连接 UE 编辑器。请启动本工程的 Host，然后点击继续执行。':data.error;
$('resume').hidden=!['interrupted','validation_blocked','turn_limit','failed'].includes(data.status)||data.model!=='deepseek-flash';$('recover').hidden=data.status!=='needs_readback'||data.model!=='deepseek-flash';$('resume').disabled=busy;$('recover').disabled=busy;
}
async function refresh(){try{const state=await api('/api/tasks');state.tasks.sort((a,b)=>(b.updated||0)-(a.updated||0));token=state.token;busy=state.busy;$('connection').textContent=busy?'● 任务执行中':'● 本地工作台已连接';$('submit').disabled=busy;$('total').textContent=state.tasks.filter(t=>t.model==='deepseek-flash').length;
if(!selected)selected=state.tasks.find(t=>t.session==='layout-support-001')?.id||state.tasks[0]?.id||'';
$('tasks').innerHTML=state.tasks.filter(t=>t.model==='deepseek-flash').map(t=>`<button class="task ${selected===t.id?'active':''}" data-task="${t.id}"><strong>${esc(taskTitle(t))}</strong><small><span class="dot"></span>${esc(statusName[t.status]||t.status)} · ${t.turns} 轮</small></button>`).join('');if(selected)render(await api(`/api/task?id=${selected}`));}
catch(e){$('connection').textContent='工作台连接中断';$('formError').hidden=false;$('formError').textContent=e.message}}
$('tasks').addEventListener('click',e=>{const b=e.target.closest('[data-task]');if(b){selected=b.dataset.task;chosenImage='';signature='';refresh()}});
$('captures').addEventListener('click',e=>{const b=e.target.closest('[data-image]');if(b)image(b.dataset.image)});
$('openImage').onclick=()=>{if(chosenImage){$('zoom').querySelector('img').src=$('viewport').src;$('zoom').showModal()}};$('closeZoom').onclick=()=>$('zoom').close();
$('newTask').onclick=()=>{$('composer').scrollIntoView({behavior:'smooth',block:'center'});$('prompt').focus()};
async function action(url,body){$('formError').hidden=true;try{const r=await api(url,body);selected=r.id;chosenImage='';signature='';await refresh()}catch(e){$('formError').hidden=false;$('formError').textContent=e.message}}
$('composer').onsubmit=e=>{e.preventDefault();action('/api/start',{intent:$('prompt').value,layout:$('layout').checked})};$('resume').onclick=()=>action('/api/resume',{id:selected});$('recover').onclick=()=>action('/api/recover',{id:selected});
await refresh();setInterval(refresh,1800);
